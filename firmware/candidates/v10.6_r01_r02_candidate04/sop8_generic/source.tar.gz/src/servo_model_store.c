#include "servo_model_store.h"
#include "py32f0xx_hal.h"

#include <string.h>

#define SERVO_MODEL_MAGIC       0x4D4F4453UL
#define SERVO_MODEL_VERSION     1U
#define SERVO_MODEL_SLOT_A_ADDR (FLASH_BASE + FLASH_SIZE - (3U * FLASH_PAGE_SIZE))
#define SERVO_MODEL_SLOT_B_ADDR (FLASH_BASE + FLASH_SIZE - (2U * FLASH_PAGE_SIZE))

_Static_assert((FLASH_PAGE_SIZE == 128U), "Learned-model layout expects 128-byte pages");
_Static_assert((sizeof(ServoLearnedModel) <= FLASH_PAGE_SIZE), "Learned model must fit one flash page");

static const ServoLearnedModel s_empty_model;
static const ServoLearnedModel *s_model_ptr = &s_empty_model;
static int8_t s_active_slot = -1;
static bool s_model_valid;

static uint32_t crc32_update(uint32_t crc, uint8_t byte)
{
  crc ^= byte;
  for (uint32_t bit = 0U; bit < 8U; bit++)
  {
    crc = ((crc & 1U) != 0U) ? ((crc >> 1U) ^ 0xEDB88320UL) : (crc >> 1U);
  }
  return crc;
}

static uint32_t model_crc32(const ServoLearnedModel *model)
{
  const uint8_t *bytes = (const uint8_t *)model;
  const uint32_t crc_offset = (uint32_t)((const uint8_t *)&model->crc32 - bytes);
  uint32_t crc = 0xFFFFFFFFUL;

  for (uint32_t i = 0U; i < sizeof(*model); i++)
  {
    crc = crc32_update(crc, ((i >= crc_offset) &&
                             (i < (crc_offset + sizeof(model->crc32)))) ? 0U : bytes[i]);
  }
  return ~crc;
}

bool Servo_ModelStore_Validate(const ServoLearnedModel *model)
{
  if ((model == NULL) ||
      (model->magic != SERVO_MODEL_MAGIC) ||
      (model->version != SERVO_MODEL_VERSION) ||
      (model->size != sizeof(*model)) ||
      (model->confidence_permille > SERVO_MODEL_CONFIDENCE_MAX) ||
      (model->start_duty_forward > 1000U) ||
      (model->start_duty_reverse > 1000U) ||
      (model->crc32 != model_crc32(model)))
  {
    return false;
  }
  return true;
}

static bool generation_is_newer(uint32_t a, uint32_t b)
{
  return ((int32_t)(a - b) > 0);
}

void Servo_ModelStore_Init(void)
{
  const ServoLearnedModel *slot_a = (const ServoLearnedModel *)SERVO_MODEL_SLOT_A_ADDR;
  const ServoLearnedModel *slot_b = (const ServoLearnedModel *)SERVO_MODEL_SLOT_B_ADDR;
  bool valid_a = Servo_ModelStore_Validate(slot_a);
  bool valid_b = Servo_ModelStore_Validate(slot_b);

  s_active_slot = -1;
  s_model_valid = false;
  s_model_ptr = &s_empty_model;

  if (valid_a && valid_b)
  {
    if (generation_is_newer(slot_b->generation, slot_a->generation))
    {
      s_model_ptr = slot_b;
      s_active_slot = 1;
    }
    else
    {
      s_model_ptr = slot_a;
      s_active_slot = 0;
    }
    s_model_valid = true;
  }
  else if (valid_a)
  {
    s_model_ptr = slot_a;
    s_active_slot = 0;
    s_model_valid = true;
  }
  else if (valid_b)
  {
    s_model_ptr = slot_b;
    s_active_slot = 1;
    s_model_valid = true;
  }
}

const ServoLearnedModel *Servo_ModelStore_Get(void)
{
  return s_model_ptr;
}

bool Servo_ModelStore_IsValid(void)
{
  return s_model_valid;
}

bool Servo_ModelStore_Save(const ServoLearnedModel *model,
                           bool qualified_and_stationary)
{
  if ((!qualified_and_stationary) || (model == NULL))
  {
    return false;
  }

  ServoLearnedModel checked = *model;
  uint32_t page_buffer[FLASH_PAGE_SIZE / sizeof(uint32_t)];
  uint32_t target_addr;
  int8_t target_slot;
  FLASH_EraseInitTypeDef erase = {0};
  uint32_t page_error = 0U;

  checked.magic = SERVO_MODEL_MAGIC;
  checked.version = SERVO_MODEL_VERSION;
  checked.size = sizeof(checked);
  checked.generation = s_model_valid ? (s_model_ptr->generation + 1U) : 1U;
  checked.crc32 = 0U;
  checked.crc32 = model_crc32(&checked);
  if (!Servo_ModelStore_Validate(&checked))
  {
    return false;
  }

  target_slot = (s_active_slot == 0) ? 1 : 0;
  target_addr = (target_slot == 0) ? SERVO_MODEL_SLOT_A_ADDR : SERVO_MODEL_SLOT_B_ADDR;
  for (uint32_t i = 0U; i < (FLASH_PAGE_SIZE / sizeof(uint32_t)); i++)
  {
    page_buffer[i] = 0xFFFFFFFFUL;
  }
  memcpy(page_buffer, &checked, sizeof(checked));

  erase.TypeErase = FLASH_TYPEERASE_PAGEERASE;
  erase.PageAddress = target_addr;
  erase.NbPages = 1U;

  /* Save only from a confirmed stationary state; keep the previous slot intact until verified. */
  __disable_irq();
  if (HAL_FLASH_Unlock() != HAL_OK)
  {
    __enable_irq();
    return false;
  }
  if (HAL_FLASHEx_Erase(&erase, &page_error) != HAL_OK)
  {
    (void)HAL_FLASH_Lock();
    __enable_irq();
    return false;
  }
  if (HAL_FLASH_Program(FLASH_TYPEPROGRAM_PAGE, target_addr, page_buffer) != HAL_OK)
  {
    (void)HAL_FLASH_Lock();
    __enable_irq();
    return false;
  }
  (void)HAL_FLASH_Lock();
  __enable_irq();

  if (!Servo_ModelStore_Validate((const ServoLearnedModel *)target_addr))
  {
    return false;
  }

  s_model_ptr = (const ServoLearnedModel *)target_addr;
  s_active_slot = target_slot;
  s_model_valid = true;
  return true;
}
