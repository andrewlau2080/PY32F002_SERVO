import runpy,json,base64,traceback
from unittest.mock import patch
with patch('runpy.run_module'):
    runpy.run_path('/home/andrew/.local/share/servo_swd/dq110_pyocd_hid_compat.py')
from pyocd.core.helpers import ConnectHelper
from pyocd.core.target import Target
options={'frequency':100000,'connect_mode':'attach','cache.enable_memory':False,'cache.enable_register':False,'cmsis_dap.prefer_v1':True,'cmsis_dap.limit_packets':True,'cmsis_dap.deferred_transfers':False,'pack':'/home/andrew/ARTERY/DQ110_FW/1.2.8.pack','resume_on_disconnect':False}
s=ConnectHelper.session_with_chosen_probe(target_override='py32f002ax5',blocking=False,auto_open=False,options=options)
r={};halted_by_us=False
try:
 s.open();t=s.target
 state=t.get_state();r['initial_core_state']=str(state)
 for name,addr in [('DHCSR',0xe000edf0),('ICSR',0xe000ed04),('VTOR',0xe000ed08),('SHCSR',0xe000ed24),('SYST_CSR',0xe000e010),('SYST_RVR',0xe000e014),('SYST_CVR',0xe000e018),('RCC_CSR',0x40021024)]:
  try:r[name]=hex(t.read32(addr))
  except Exception as e:r[name+'_error']=str(e)
 if state!=Target.State.HALTED:
  t.halt();halted_by_us=True
 r['registers']={}
 for name in ['r0','r1','r2','r3','r4','r5','r6','r7','r8','r9','r10','r11','r12','sp','lr','pc','xpsr','msp','psp','primask','control']:
  try:r['registers'][name]=hex(t.read_core_register(name))
  except Exception as e:r['registers'][name]=str(e)
 r['ram_base64']=base64.b64encode(bytes(t.read_memory_block8(0x20000000,3072))).decode()
 r['code_at_pc_base64']=base64.b64encode(bytes(t.read_memory_block8(int(r['registers']['pc'],16)&~1,48))).decode()
except Exception:
 r['error']=traceback.format_exc()
finally:
 try:
  if halted_by_us:s.target.resume();r['resumed_after_snapshot']=True
  r['final_core_state']=str(s.target.get_state())
 except Exception as e:r['resume_error']=str(e)
 try:s.close()
 except Exception as e:r['close_error']=str(e)
 print(json.dumps(r))
