import runpy,json,base64,time
from unittest.mock import patch
with patch('runpy.run_module'):runpy.run_path('/home/andrew/.local/share/servo_swd/dq110_pyocd_hid_compat.py')
from pyocd.core.helpers import ConnectHelper
from pyocd.core.target import Target
s=ConnectHelper.session_with_chosen_probe(target_override='py32f002ax5',blocking=False,auto_open=False,options={'frequency':1000000,'connect_mode':'attach','pack':'/home/andrew/ARTERY/DQ110_FW/1.2.8.pack','resume_on_disconnect':False,'cache.enable_memory':False,'cache.enable_register':False,'cmsis_dap.prefer_v1':True,'cmsis_dap.limit_packets':True,'cmsis_dap.deferred_transfers':False})
s.open();t=s.target
try:
 for i in range(4):
  was=t.get_state();t.halt()
  try:
   r={'sample':i,'before':str(was),'registers':{n:hex(t.read_core_register(n)) for n in ['pc','lr','sp','xpsr','primask']},'uart_sr':hex(t.read32(0x40013800)),'ram':base64.b64encode(bytes(t.read_memory_block8(0x20000000,3072))).decode()}
   print(json.dumps(r),flush=True)
  finally:
   if was!=Target.State.HALTED:t.resume()
  time.sleep(.3)
finally:s.close()
