int sub_8003555(void)
{
    unsigned short *v0;  // r4
    unsigned short v1;  // r5

    v0[7] = v1;
    v0[18] = 0xfffe;
}
