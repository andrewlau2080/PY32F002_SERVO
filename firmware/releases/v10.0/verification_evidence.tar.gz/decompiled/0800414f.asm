0800414f ldr      r3, [r4]
08004151 lsls     r1, r3, #0x18
08004153 bmi      #0x800415b
08004155 lsls     r1, r3, #0x19
08004157 bpl      #0x800415b
08004159 b        #0x80042d3
0800415b ldr      r1, [r2]
0800415d adds     r0, r1, #4
0800415f str      r0, [r2]
08004161 ldr      r2, [r1]
08004163 movs     r6, r2
08004165 cmp      r2, #0
08004167 blt      #0x8004255
08004169 ldr      r3, [pc, #0x184]
0800416b mov      fp, r3
0800416d movs     r3, #0xa
0800416f mov      sl, r3
08004171 b        #0x800420f
0800420f ldr      r3, [r4, #4]
08004211 str      r3, [r4, #8]
08004213 cmp      r3, #0
08004215 blt      #0x80042a9
08004217 movs     r2, #4
08004219 ldr      r1, [r4]
0800421b bics     r1, r2
0800421d str      r1, [r4]
0800421f cmp      r6, #0
08004221 bne      #0x8004273
08004223 cmp      r3, #0
08004225 bne      #0x80042ad
08004227 ldr      r5, [sp, #0xc]
08004229 mov      r3, sl
0800422b cmp      r3, #8
0800422d beq      #0x8004293
0800422f ldr      r3, [sp, #0xc]
08004231 subs     r3, r3, r5
08004233 str      r3, [r4, #0x10]
08004235 b        #0x80040c9
08004255 movs     r2, #0x43
08004257 movs     r1, #0x2d
08004259 strb     r1, [r4, r2]
0800425b ldr      r2, [r4, #4]
0800425d rsbs     r6, r6, #0
0800425f str      r2, [r4, #8]
08004261 cmp      r2, #0
08004263 blt      #0x800426b
08004265 movs     r2, #4
08004267 bics     r3, r2
08004269 str      r3, [r4]
0800426b ldr      r3, [pc, #0x84]
0800426d mov      fp, r3
0800426f movs     r3, #0xa
08004271 mov      sl, r3
08004273 ldr      r5, [sp, #0xc]
08004275 movs     r0, r6
08004277 mov      r1, sl
08004279 bl       #0x800477d
0800427d mov      r3, fp
0800427f ldrb     r3, [r3, r1]
08004281 subs     r5, #1
08004283 strb     r3, [r5]
08004285 movs     r3, r6
08004287 movs     r6, r0
08004289 cmp      r3, sl
0800428b bhs      #0x8004275
0800428d mov      r3, sl
0800428f cmp      r3, #8
08004291 bne      #0x800422f
08004293 ldr      r3, [r4]
08004295 lsls     r3, r3, #0x1f
08004297 bpl      #0x800422f
08004299 ldr      r3, [r4, #4]
0800429b ldr      r2, [r4, #0x10]
0800429d cmp      r3, r2
0800429f bgt      #0x800422f
080042a1 movs     r3, #0x30
080042a3 subs     r5, #1
080042a5 strb     r3, [r5]
080042a7 b        #0x800422f
080042a9 cmp      r6, #0
080042ab bne      #0x8004273
080042ad mov      r3, fp
080042af movs     r5, r4
080042b1 ldrb     r2, [r3]
080042b3 movs     r3, #0x42
080042b5 adds     r5, #0x42
080042b7 strb     r2, [r4, r3]
080042b9 b        #0x8004229
080042d3 ldr      r1, [r2]
080042d5 adds     r0, r1, #4
080042d7 str      r0, [r2]
080042d9 movs     r2, #0
080042db ldrsh    r6, [r1, r2]
080042dd movs     r2, r6
080042df b        #0x8004165
