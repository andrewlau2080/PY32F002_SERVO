080007b9 cpsid    i
080007bb ldr      r3, [pc, #0x28]
080007bd movs     r2, #0
080007bf movs     r1, r3
080007c1 adds     r1, #0x3a
080007c3 strh     r2, [r3, #0x38]
080007c5 strb     r2, [r1]
080007c7 strh     r2, [r3, #0x3c]
080007c9 cpsie    i
080007cb movs     r3, #0xa0
080007cd lsls     r3, r3, #0x17
080007cf adds     r2, #2
080007d1 str      r2, [r3, #0x28]
080007d3 adds     r2, #2
080007d5 str      r2, [r3, #0x28]
080007d7 adds     r2, #0x3c
080007d9 str      r2, [r3, #0x28]
080007db ldr      r3, [pc, #0xc]
080007dd subs     r2, #0x3f
080007df str      r2, [r3, #0x28]
080007e1 bx       lr
