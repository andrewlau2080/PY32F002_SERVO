int sub_80034a1(void)
{
}
