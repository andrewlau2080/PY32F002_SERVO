080026dd push     {r3, r4, r5, r6, r7, lr}
080026df movs     r5, r0
080026e1 ldr      r0, [pc, #0x38]
080026e3 movs     r6, r2
080026e5 movs     r4, r3
080026e7 movs     r7, r1
080026e9 bl       #0x80021d5
080026ed cmp      r6, r4
080026ef beq      #0x8002703
080026f1 cmp      r6, r7
080026f3 bhs      #0x8002703
080026f5 movs     r1, #0x18
080026f7 muls     r1, r6, r1
080026f9 movs     r2, #0
080026fb movs     r0, r6
080026fd adds     r1, r5, r1
080026ff bl       #0x800240d
08002703 cmp      r4, r7
08002705 bhs      #0x8002715
08002707 movs     r1, #0x18
08002709 muls     r1, r4, r1
0800270b movs     r2, #1
0800270d movs     r0, r4
0800270f adds     r1, r5, r1
08002711 bl       #0x800240d
08002715 ldr      r0, [pc, #8]
08002717 bl       #0x80021d5
0800271b pop      {r3, r4, r5, r6, r7, pc}
