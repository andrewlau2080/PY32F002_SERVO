void* sub_80038f9(void* a0, unsigned int a1, unsigned int a2)
{
    unsigned int v0;  // r4
    void* iter;  // r5
    void* j;  // r2
    void* node;  // r3
    void* iter1;  // r3
    unsigned int v3;  // r4
    unsigned int v4;  // r4
    unsigned int v5;  // r5
    unsigned int v6;  // r7
    void* iter2;  // r2
    unsigned int v8;  // r7
    unsigned int v9;  // r6

    if (a0 * 0x40000000)
    {
        v0 = a2 - 1;
        if (!a2)
            return a0;
        iter = a0;
        iter1 = a0;
        while (1)
        {
            v3 = v0;
            iter1 += 1;
            *(char *)iter = a1;
            if (!(iter1 & 0x3))
                break;
            iter += 1;
            v0 = v3 - 1;
            if (v3 < 1)
                return a0;
        }
    }
    else
    {
        iter1 = a0;
        v3 = a2;
    }
    v4 = v3;
    if (v4 > 3)
    {
        v5 = (0xff & a1) * 0x100 | 0xff & a1 | ((0xff & a1) * 0x100 | 0xff & a1) * 0x10000;
        if (v3 > 15)
        {
            v6 = v3 - 16 >> 4;
            iter2 = iter1;
            do
            {
                *(unsigned int *)iter2 = v5;
                *(unsigned int *)&iter2[4] = v5;
                *(unsigned int *)&iter2[8] = v5;
                *(unsigned int *)&iter2[12] = v5;
                iter2 += 16;
            } while (iter2 != iter1 + v6 * 16 + 16);
            iter1 += (v6 + 1) * 16;
            v8 = 15 & v3;
            v4 = v8;
            if (!(12 & v3))
                goto LABEL_8003983;
        }
        else
        {
            v8 = v3;
        }
        v9 = v8 - 4 >> 2;
        j = iter1;
        do
        {
            *(unsigned int *)(j & 0xfffffffc) = v5;
            j += 4;
        } while (j != iter1 + v9 * 4 + 4);
        iter1 += (v9 + 1) * 4;
        v4 = 3 & v8;
    }
LABEL_8003983:
    if (!v4)
        return a0;
    node = iter1;
    do
    {
        *(char *)node = a1;
        node += 1;
    } while (iter1 + v4 != node);
    return a0;
}
