extern unsigned short g_2000002c;
extern unsigned short g_2000002e;
extern unsigned short g_20000030;
extern unsigned short g_20000032;
extern unsigned int g_20000384;
extern char g_20000388;
extern char g_20000389;
extern unsigned short g_2000038a;
extern unsigned int g_2000038c;
extern char g_20000390;
extern char g_20000391;
extern unsigned short g_20000392;
extern unsigned int g_20000394;
extern unsigned int g_20000398;
extern unsigned int g_40012c10;
extern unsigned int g_40012c20;

int sub_80003f5(unsigned int a0, unsigned int a1)
{
    unsigned int v1;  // r2
    unsigned int v0;  // [bp-0x1c]

    v0 = a1;
    v0 = *(int *)0x20000340;
    if (!(g_40012c10 & 2))
        return a0;
    g_40012c10 = g_40012c10 & ~2;
    g_20000384 = g_20000384 + 1;
    if (!g_20000388)
    {
        if (g_20000389)
            g_2000038c = (*(int *)0x40012c34 & 0xffff) - g_2000038a & 0xffff;
        g_2000038a = *(int *)0x40012c34;
        g_20000389 = 1;
        g_20000388 = 1;
        g_40012c20 = 2 | g_40012c20;
        return a0;
    }
    else
    {
        g_20000388 = 0;
        v1 = (*(int *)0x40012c34 & 0xffff) - g_2000038a & 0xffff;
        g_40012c20 = g_40012c20 & ~2;
        if (2400 < (unsigned short)v1 - 300)
        {
            return a0;
        }
        else if (g_2000038c <= v1)
        {
            return a0;
        }
        else if (g_2000038c < 500)
        {
            return a0;
        }
        else if (30000 < g_2000038c)
        {
            return a0;
        }
        else
        {
            g_2000002c = v1;
            if (!g_20000390 || (v1 < g_2000002e ? (unsigned short)(g_2000038a + g_2000002e - *(int *)0x40012c34) : (unsigned short)(v1 - g_2000002e)) <= 8 || g_20000391 && 8 >= (v1 < g_20000030 ? (unsigned short)(g_2000038a + g_20000030 - *(int *)0x40012c34) : (unsigned short)(v1 - g_20000030)))
            {
                if (g_20000032 > v1)
                    g_20000032 = v1;
                if (v1 > g_20000392)
                    g_20000392 = v1;
            }
            if (g_2000038c <= 2999 || 30000 < g_2000038c)
                return a0;
            g_2000002e = v1;
            g_20000030 = v1;
            g_20000391 = 0;
            g_20000390 = 1;
            g_20000032 = v1;
            g_20000392 = v1;
            g_20000394 = v0;
            g_20000398 = g_20000398 + 1;
            return a0;
        }
    }
}
