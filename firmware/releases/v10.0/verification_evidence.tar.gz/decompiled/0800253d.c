void sub_800253d(unsigned int a0, unsigned int a1, unsigned int a2, unsigned int a3, unsigned int a4, unsigned int a5, unsigned int a6, unsigned int a7, unsigned int a8, unsigned int a9, unsigned int a10, unsigned int a11, unsigned int a12, unsigned int a13, unsigned int a14, unsigned int a15)
{
    sub_80002ed();
    sub_80021d5("ref_star");
    sub_80021d5("sendxy=1");
    sub_8000155();
    return;
}
