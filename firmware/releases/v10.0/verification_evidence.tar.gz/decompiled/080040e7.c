typedef struct st_80040e7_0 {
    unsigned int field_0;
    char padding_4[8];
    int field_c;
} st_80040e7_0;

int sub_80040e7(unsigned int a0, unsigned int a1, unsigned int a2, unsigned int a3, unsigned int a4, unsigned int a5, unsigned int a6, unsigned int a7, unsigned int a8, int a9)
{
    st_80040e7_0 *v0;  // r4
    int v1;  // r3
    unsigned int *v2;  // r9

    if (a0 == 0xffffffff)
        goto LABEL_0x800411d;
    if ((int)(v0->field_0 * 0x40000000) < 0)
    {
        v1 = v0->field_c;
        if (v0->field_c - a9 > 0)
            v2();
    }
    else
    {
        v1 = v0->field_c;
    }
    if (v1 <= a9)
        goto LABEL_0x8004121;
}
