08002725 push     {r4, lr}
08002727 movs     r4, #0xe1
08002729 sub      sp, #0x18
0800272b bl       #0x8001ea9
0800272f lsls     r4, r4, #0xa
08002731 ldr      r0, [pc, #0x30]
08002733 bl       #0x80021d5
08002737 movs     r3, r4
08002739 movs     r1, #0x18
0800273b ldr      r2, [pc, #0x2c]
0800273d mov      r0, sp
0800273f bl       #0x8003a1d
