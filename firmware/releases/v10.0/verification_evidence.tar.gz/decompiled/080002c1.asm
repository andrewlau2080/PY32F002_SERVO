080002c1 ldr      r3, [pc, #0x10]
080002c3 movs     r2, #0
080002c5 movs     r1, r3
080002c7 str      r2, [r3, #0x30]
080002c9 adds     r1, #0x2c
080002cb adds     r3, #0x34
080002cd strb     r2, [r1]
080002cf strb     r2, [r3]
080002d1 bx       lr
