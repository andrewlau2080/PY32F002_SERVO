08004de9 lsls     r0, r1, #3
08004deb movs     r0, r0
08004ded movs     r4, r0
08004def movs     r0, r0
08004df1 ldr      r4, [pc, #0x8c]
08004df3 lsrs     r0, r0, #0x20
08004df5 ldr      r4, [pc, #0x9c]
08004df7 lsrs     r0, r0, #0x20
08004df9 movs     r0, r2
08004dfb movs     r0, r0
08004dfd movs     r6, r0
08004dff movs     r0, r0
08004e01 lsls     r0, r2, #1
08004e03 movs     r0, r0
08004e05 movs     r1, r0
08004e07 movs     r0, r0
08004e09 ldr      r4, [pc, #0xac]
08004e0b lsrs     r0, r0, #0x20
08004e0d ldr      r4, [pc, #0xc0]
08004e0f lsrs     r0, r0, #0x20
08004e11 movs     r4, r3
08004e13 movs     r0, r0
08004e15 movs     r0, r0
08004e17 movs     r0, r0
08004e19 lsls     r0, r7, #1
08004e1b movs     r0, r0
