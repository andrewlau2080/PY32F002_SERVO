08002221 push     {r4, lr}
08002223 sub      sp, #0x40
08002225 add      r4, sp, #0x48
08002227 ldrh     r4, [r4]
08002229 str      r3, [sp, #8]
0800222b str      r2, [sp, #4]
0800222d movs     r3, r0
0800222f ldr      r2, [pc, #0x18]
08002231 str      r1, [sp]
08002233 str      r4, [sp, #0xc]
08002235 movs     r1, #0x30
08002237 add      r0, sp, #0x10
08002239 bl       #0x8003a1d
