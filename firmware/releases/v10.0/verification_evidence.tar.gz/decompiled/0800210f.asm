0800210f push     {r4, r5, lr}
08002111 movs     r4, #1
08002113 movs     r1, #0x80
08002115 sub      sp, #0x24
08002117 str      r3, [sp, #0x14]
08002119 ldr      r3, [pc, #0x94]
0800211b lsls     r1, r1, #4
0800211d ldr      r5, [r3, #0x38]
0800211f ldr      r3, [pc, #0x94]
08002121 movs     r0, #0xa0
08002123 ldr      r2, [r3, #0x34]
08002125 lsls     r0, r0, #0x17
08002127 orrs     r2, r4
08002129 str      r2, [r3, #0x34]
0800212b ldr      r2, [r3, #0x34]
0800212d ands     r2, r4
0800212f str      r2, [sp, #4]
08002131 ldr      r2, [sp, #4]
08002133 ldr      r2, [r3, #0x40]
08002135 orrs     r2, r1
08002137 str      r2, [r3, #0x40]
08002139 ldr      r3, [r3, #0x40]
0800213b ands     r3, r1
0800213d str      r3, [sp, #8]
0800213f ldr      r3, [sp, #8]
08002141 movs     r3, #8
08002143 str      r3, [sp, #0xc]
08002145 subs     r3, #6
08002147 str      r3, [sp, #0x10]
08002149 str      r3, [sp, #0x18]
0800214b add      r1, sp, #0xc
0800214d adds     r3, #0xb
0800214f str      r3, [sp, #0x1c]
08002151 bl       #0x8000925
08002155 ldr      r3, [pc, #0x60]
08002157 cmp      r5, r3
08002159 bls      #0x8002165
0800215b movs     r0, r5
0800215d ldr      r1, [pc, #0x5c]
0800215f bl       #0x8004671
08002163 movs     r4, r0
08002165 movs     r2, #0
08002167 ldr      r3, [pc, #0x58]
08002169 ldr      r1, [pc, #0x58]
0800216b subs     r4, #1
0800216d str      r2, [r3]
0800216f movs     r0, #2
08002171 str      r2, [r3, #0xc]
08002173 str      r4, [r3, #0x28]
08002175 str      r1, [r3, #0x2c]
08002177 movs     r1, #1
08002179 str      r2, [r3, #0x24]
0800217b str      r1, [r3, #0x18]
0800217d str      r1, [r3, #0x20]
0800217f str      r1, [r3, #0x14]
08002181 str      r2, [r3, #0x10]
08002183 str      r0, [r3, #0xc]
08002185 str      r1, [r3]
08002187 ldr      r3, [pc, #0x40]
08002189 ldr      r0, [pc, #0x40]
0800218b movs     r1, r3
0800218d adds     r1, #0x68
0800218f strb     r2, [r1]
08002191 movs     r1, #0xc3
08002193 adds     r3, #0x69
08002195 strb     r2, [r3]
08002197 ldr      r3, [pc, #0x38]
08002199 lsls     r1, r1, #2
0800219b ldr      r2, [r3, r1]
0800219d ands     r2, r0
0800219f str      r2, [r3, r1]
080021a1 movs     r2, #0x80
080021a3 subs     r1, #0x8d
080021a5 lsls     r2, r2, #7
080021a7 subs     r1, #0xff
080021a9 str      r2, [r3, r1]
080021ab str      r2, [r3]
080021ad add      sp, #0x24
080021af pop      {r4, r5, pc}
