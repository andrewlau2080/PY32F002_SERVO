int sub_8003653(void)
{
}
