extern unsigned int g_20000014;
extern unsigned short g_20000018;
extern unsigned short g_2000001a;
extern unsigned short g_2000001c;
extern unsigned short g_20000020;
extern unsigned short g_2000002a;
extern unsigned short g_200001a8;
extern char g_20000338;
extern char g_2000034c;
extern unsigned int g_20000350;
extern char g_20000354;
extern char g_20000355;
extern char g_20000356;
extern unsigned short g_20000358;
extern unsigned short g_2000035a;
extern char g_2000035c;
extern unsigned short g_2000035e;
extern unsigned short g_20000360;
extern unsigned short g_20000362;
extern char g_20000364;
extern unsigned short g_20000366;
extern unsigned int g_20000368;
extern char g_2000036c;
extern char g_2000036d;
extern unsigned short g_2000036e;
extern unsigned short g_20000370;
extern char g_20000372;
extern char g_20000373;
extern char g_20000374;
extern char g_20000375;
extern char g_20000376;
extern char g_20000377;
extern unsigned int g_20000378;
extern unsigned int g_2000037c;
extern char g_20000380;
extern unsigned short g_200003d8;
extern char g_200003da;
extern unsigned short g_200003dc;
extern unsigned short g_2000041c;
extern char g_2000041e;
extern unsigned int g_50000018;

int sub_80010cf(unsigned int a0, unsigned int a1, unsigned int a2, unsigned int a3, unsigned int a4, unsigned int a5, unsigned int a6, unsigned int a7, unsigned int a8, unsigned int a9, unsigned int a10, unsigned int a11, unsigned int a12, unsigned int a13, unsigned int a14, unsigned int a15, unsigned int a16, unsigned int a17, unsigned int a18, unsigned int a19, unsigned int a20, unsigned int a21, unsigned int a22, unsigned int a23, unsigned int a24, unsigned int a25, unsigned int a26, unsigned int a27, unsigned int a28, unsigned int a29, unsigned int a30, unsigned int a31, unsigned int a32, unsigned int a33, unsigned int a34, unsigned int a35, unsigned int a36, unsigned int a37, unsigned int a38, unsigned short a39, unsigned int a40, unsigned int a41, unsigned int a42, unsigned int a43, unsigned int a44)
{
    unsigned int v2;  // r0
    unsigned int v3;  // r5
    int v12;  // r0
    unsigned int v13;  // r3
    unsigned int v14;  // r6
    unsigned short v15;  // r3
    unsigned int v16;  // r3
    unsigned int v18;  // r0
    unsigned int v19;  // r3
    unsigned int v20;  // r5
    unsigned short v21;  // r4
    unsigned int v4;  // r1
    int v22;  // r3
    int v23;  // r7
    unsigned int v24;  // r5
    unsigned int v25;  // r2
    unsigned int v26;  // r2
    unsigned int v27;  // r3
    char v28;  // r2
    unsigned int v29;  // r3
    int v30;  // r2
    int v31;  // r1
    unsigned int v5;  // r1
    int v32;  // r3
    unsigned int v33;  // r3
    unsigned int v34;  // r0
    unsigned int v35;  // r4
    int v36;  // r1
    int v37;  // r2
    int v38;  // r3
    unsigned int v39;  // r3
    unsigned short v40;  // r0
    unsigned int v41;  // r2
    unsigned short v42;  // r3
    unsigned int v43;  // r3
    unsigned int v44;  // r0
    unsigned int v45;  // r2
    unsigned int v46;  // r1
    unsigned int v47;  // r3
    unsigned short v48;  // r3
    unsigned int iter;  // r3
    unsigned int v50;  // r2
    unsigned short v51;  // r2
    char v7;  // r2
    unsigned int v52;  // r5
    unsigned int v53;  // r2
    unsigned int v54;  // r2
    unsigned int v55;  // r0
    unsigned int v56;  // r1
    unsigned int v57;  // r2
    char v58;  // r1
    unsigned int v59;  // r2
    unsigned short v60;  // r3
    unsigned int v61;  // r4
    unsigned int v8;  // r4
    char v62;  // r3
    unsigned int v63;  // r1
    unsigned int v64;  // r4
    unsigned int v65;  // r0
    unsigned short v67;  // r2
    unsigned int v68;  // r0
    unsigned int v69;  // r3
    unsigned int v70;  // r2
    unsigned int v71;  // r3
    unsigned int v9;  // r6
    short v72;  // r4
    char v73;  // r3
    unsigned short v74;  // r3
    unsigned int v75;  // r2
    unsigned int v76;  // r0
    unsigned int v77;  // r3
    unsigned int v78;  // r3
    unsigned int v79;  // r2
    unsigned int v80;  // r2
    char v81;  // r2
    int v10;  // r4
    char v82;  // r2
    unsigned int v83;  // r2
    unsigned short v84;  // r3
    int v11;  // r7
    unsigned int v0;  // [bp+0x18]
    char v1;  // [bp+0xa5]

    if (*(int *)0x20000424 != a3)
    {
        v2 = sub_800053d(&a39, a1);
        g_50000018 = 1;
        if (*0x2000041b)
            v2 = (unsigned int)sub_80001d1(&a39);
        a16 = 0;
        if (v1)
            a16 = 0 + (*(int *)0x20000340 - a42 <= *(short *)0x2000075e);
        v3 = *(int *)0x200001e4 & 0xffff;
        a23 = *0x20000048;
        if (*0x20000048 < *0x2000004c || *0x20000048 > *0x20000050)
            a23 = 416;
        a22 = *0x20000090;
        if (a22 < *0x20000094 || a22 > *0x20000098)
            a22 = 3;
        a18 = *(int *)0x20000078;
        if (a18 >= 0x10000)
            a18 = 120;
        a24 = *(int *)0x200000d8;
        if ((unsigned int)*(int *)0x200000d8 >= 0x10000)
            a24 = 3;
        a21 = *(int *)0x200000c0;
        if ((unsigned int)*(int *)0x200000c0 >= 0x10000)
            a21 = 160;
        a25 = *(int *)0x200000f0;
        if (a25 >= 0x10000)
            a25 = 620;
        a19 = *0x20000108;
        if ((unsigned int)*(int *)0x20000108 >= 0x10000)
            a19 = 32;
        a32 = *(int *)0x20000120;
        if (a32 >= 0x10000)
            a32 = 0x44;
        a29 = *(int *)0x20000138;
        if ((unsigned int)*(int *)0x20000138 >= 0x10000)
            a29 = 16;
        a20 = *0x20000150;
        if ((unsigned int)*(int *)0x20000150 >= 0x10000)
            a20 = 28;
        a33 = *(int *)0x20000168;
        v4 = a33;
        if (v4 >= 0x10000)
        {
            v4 = 16;
            a33 = 16;
        }
        a34 = *(int *)0x20000198;
        if ((unsigned int)*(int *)0x20000198 >= 0x10000)
            a34 = 930;
        a26 = *(int *)0x20000180;
        if (a26 >= 0x10000)
            a26 = 224;
        a31 = *(int *)0x20000340;
        a14 = sub_8000ea5(v2, v4);
        if (g_2000041c == v3)
            goto LABEL_0x800124b;
        if (v3 > 20000)
        {
            v5 = 20000;
        }
        else
        {
            v5 = v3;
            if (100 > (unsigned short)v5)
                v5 = 100;
        }
        g_200001a8 = sub_8004671(1000000, v5 & 0xffff);
        g_200003dc = 0;
        g_2000041c = v3;
        if ((unsigned short)((short)a14 - 31) > 4033)
        {
            sub_80007b9();
            g_20000358 = 0;
            sub_80002c1();
            g_20000362 = 0;
            g_20000364 = 0;
            g_2000036d = 0;
            g_2000035e = 0xfffe;
            g_20000360 = 0xfffe;
            g_20000375 = 0;
            g_20000376 = 0;
            g_20000377 = 0;
            g_2000035a = 0;
            g_20000380 = 0;
            sub_80002d9();
            if (5 >= g_20000374)
            {
                v7 = 1;
                g_20000374 = g_20000374 + 1;
                if (g_20000374 == 6)
                    v7 = 8;
            }
            else
            {
                v7 = 8;
            }
            g_2000035c = v7;
            return sub_80012b7();
        }
        g_20000374 = 0;
        v8 = a14 * 16;
        if (!g_20000380)
        {
            g_2000037c = 0;
            g_20000378 = v8;
            g_2000002a = a14;
            g_20000380 = 1;
        }
        else
        {
            a9 = g_2000037c;
            v9 = g_2000037c + g_20000378;
            v10 = v8 - v9;
            if (!g_20000358 && g_20000377 - 2 > 3)
                v11 = 12;
            else
                v11 = 7;
            g_20000378 = sub_8004785(v10) + v9;
            v12 = sub_8004785(v10, v11) + a9;
            v13 = 0x200;
            if (v12 > 0x200 || (v13 = 0xfffffe00, v12 < -0x200))
                g_2000037c = v13;
            else
                g_2000037c = v12;
        }
        v14 = (int)(g_20000378) >> 4 & 0xffff;
        a13 = g_2000037c;
        g_2000035a = (int)(((int)(g_2000037c) >> 31 & 15) + a13) >> 4;
        g_20000366 = v14;
        g_2000036d = 1;
        if (g_20000020 > v14)
            g_20000020 = v14;
        if (v14 > g_2000036e)
            g_2000036e = v14;
        if (!a16)
        {
            sub_80007b9();
            g_20000358 = a16;
            sub_80002c1();
            v15 = a16;
            g_2000035a = v15;
            if (a43)
                v15 = 3;
            g_2000035c = v15;
            g_20000375 = 0;
            g_20000376 = 0;
            g_20000377 = 0;
            return sub_80012b7(sub_80002d9());
        }
        a9 = a39;
        if (!g_2000036c)
        {
            g_20000368 = a44;
            g_2000036c = 1;
            g_2000001c = a9;
        }
        else if (a44 == g_20000368)
        {
            v16 = g_2000001c;
            goto LABEL_80014cf;
        }
        else
        {
            g_20000368 = a44;
            if (sub_8000239(a9))
            {
                g_2000001c = a9;
            }
            else
            {
                if (g_2000001c < a9 || a9 != g_2000001c)
                    g_2000001c = a9;
                v16 = g_2000001c;
LABEL_80014cf:
                a9 = v16;
            }
        }
        v18 = sub_8004671(sub_8000255(a9) * 0xfff + 1650, 3300);
        if (v18 >= 0x1000)
            v18 = 0xfff;
        v19 = g_2000001a;
        v20 = 0;
        v21 = v18;
        if (v19 != 0xffff)
            v20 = (a9 <= v19 ? (unsigned short)(v19 - a9) : (unsigned short)(a9 - v19));
        if (g_20000018 == 0xffff)
        {
            g_2000002a = v21;
            return sub_800146f();
        }
        a12 = 0;
        if (v20)
        {
            g_2000002a = v21;
            if (v20 > 2)
                sub_8001e09(); /* do not return */
            a12 = a17;
        }
        g_20000018 = v21;
        g_2000001a = a9;
        a11 = g_2000002a;
        v22 = g_2000002a - v14;
        v23 = (short)v22;
        a10 = v22 & 0xffff;
        v0 = a10;
        if (v22 * 0x10000 < 0)
            v0 = v14 - a11 & 0xffff;
        v24 = (unsigned short)a13;
        if (0 > a13)
            v24 = -v24 & 0xffff;
        v25 = g_20000372;
        if (0 < (int)v25)
        {
            if (v14 > a11)
            {
                v26 = v14 - a11 & 0xffff;
                if (v26 > g_20000370)
                    g_20000370 = v26;
            }
        }
        else
        {
            if (v25 && v14 < a11 && g_20000370 < a10)
                g_20000370 = a10;
        }
        v27 = *(int *)0x200001fc & 0xffff;
        if (v27 > 1000)
            v27 = 1000;
        a15 = v27 & 0xffff;
        if (!g_20000373)
        {
            v28 = 1;
            if (0 >= v23)
                v28 = -(v23 - (v23 - 1) - (1 > (unsigned int)v23));
            g_20000373 = v28;
        }
        if (0 < g_20000373)
        {
            v29 = (unsigned int)(v23) >> 31;
        }
        else
        {
            a27 = g_20000373;
            if (!g_20000373)
                goto LABEL_80015af;
            v29 = (unsigned int)((v23 >> 31) - v23) >> 31;
        }
        a27 = v29;
LABEL_80015af:
        a37 = (unsigned short)a19;
        if (0 < v23)
        {
            v30 = a13;
            v31 = a19;
        }
        else
        {
            a28 = v23;
            if (!v23)
                goto LABEL_80015c9;
            v31 = a13;
            v30 = -a19;
        }
        v32 = 1;
        if (v31 >= v30)
            v32 = 0;
        a28 = v32;
LABEL_80015c9:
        a36 = (unsigned short)a21;
        a30 = (unsigned short)a29;
        a21 = (unsigned short)a20;
        a29 = (unsigned short)a33;
        v33 = (unsigned short)a25;
        v34 = a36 + (sub_8004671(a24 * v24, 3, 116, a29) & 0xffff) & 0xffff;
        if (v33 > v34)
            v33 = v34;
        a19 = v33 & 0xffff;
        v35 = a29 + 14 * a30 & 0xffff;
        if (v23 > 0)
        {
            v36 = a13;
            v37 = -a20;
        }
        else
        {
            a25 = v23;
            if (!v23)
                goto LABEL_8001633;
            v37 = a13;
            v36 = a20;
        }
        v38 = 1;
        if (v36 >= v37)
            v38 = 0;
        a25 = v38;
LABEL_8001633:
        if (16 > a23)
            a23 = 16;
        if (v0 >= a19)
        {
            v39 = a23 & 0xffff;
        }
        else
        {
            v40 = sub_8004671(a23 * v0, a19);
            if (a21 > v40)
                v40 = a21;
            v39 = v40;
        }
        a33 = v39;
        a20 = (unsigned short)a32;
        a32 = 0;
        if (a28)
            a32 = -(-(v24 > (a33 + a20 & 0xffff)));
        a23 = (unsigned short)a34;
        if (!a12)
        {
            v41 = g_20000377;
            switch (v41)
            {
            case 1:
                if (v0 > v35)
                {
                    if (7 >= g_20000375 && (g_20000375 = g_20000375 + 1, g_20000375 != 8))
                        goto LABEL_8001dd7;
LABEL_8001747:
                    if (!g_2000041e)
                    {
                        if (!g_20000338)
                            sub_8000189(*(int *)0x20000340);
                        g_2000041e = 1;
                    }
                    g_20000377 = 6;
                    v42 = a15;
                    if (a15 > a23)
                        v42 = a23;
                    a15 = v42;
                    a12 = a17;
                    if (a29 >= v0)
                        goto LABEL_8001def;
                    goto LABEL_8001795;
                }
                break;
            case 6:
                if (v35 < v0)
                    goto LABEL_8001747;
                break;
            default:
                break;
            }
        }
        a16 = 0;
        g_20000375 = 0;
LABEL_8001dd7:
        if (a29 < v0)
        {
            if (!a12)
                goto LABEL_8001795;
            a12 = 0;
        }
        else
        {
            g_2000041e = 0;
            if (a12)
            {
                a12 = 0;
            }
            else
            {
LABEL_8001def:
                if (v24 <= a21)
                {
LABEL_8001df7:
                    a4 = v23;
                    sub_8000f29(a9, a14, a11, v14);
                    sub_80012b7();
                }
LABEL_8001795:
                v43 = g_20000377;
                if ((v43 == 1 || v43 == 6) && !a12 && v35 >= v0 && (a20 + 32 & 0xffff) >= v24 || (a16 || a27) && !a12 && (a29 + (a30 & 0xffff) & 0xffff) >= v0 && (a21 + 16 & 0xffff) >= v24 || g_20000370 && 240 >= v0 && (a20 + 32 & 0xffff) >= v24)
                    goto LABEL_8001df7;
            }
        }
        if (g_20000355)
        {
            v44 = a31 - *(int *)0x20000420;
            if (42 < v44 || v0 <= a30 || (v45 = g_20000356, !g_20000356))
            {
                sub_80002d9();
                goto LABEL_8001833;
            }
            else
            {
                g_20000376 = 0;
                if (11 >= v44)
                {
                    g_20000377 = 2;
                    v46 = 930;
                    a13 = 12;
LABEL_8001981:
                    v48 = v46;
                    if (v46 > a15)
                        v48 = a15;
                }
                else
                {
                    v45 = -g_20000356;
                    if (v44 > 15)
                    {
                        v46 = 220;
                        v47 = 0x11;
                    }
                    else
                    {
                        v47 = 14;
                        v46 = 360;
                    }
                    a13 = v47;
                    g_20000377 = 4;
                    if (v44 <= 18)
                        goto LABEL_8001981;
                    a13 = 3;
                    v48 = 0;
                }
                iter = v48;
                if (0 >= (int)v45)
                    iter = -iter;
                if (!a12)
                {
                    v50 = a17;
                    goto LABEL_80019f9;
                }
            }
        }
        else
        {
LABEL_8001833:
            v51 = a26;
            if (!a12)
            {
                if (a27)
                {
                    if (!a25 && v35 >= v0 && (a20 + 16 & 0xffff) >= v24)
                        goto LABEL_8001df7;
                    v52 = 3 * v0 + (v24 >> 2) & 0xffff;
                    if (v0 <= v35 || (iter = 80, v52 > 79))
                    {
                        if (v52 > 360)
                            v52 = 360;
                        iter = v52 & 0xffff;
                    }
                    if (0 > v23)
                        iter = -iter;
                    g_20000377 = 4;
                    g_20000376 = 0;
                    v53 = 18;
                    goto LABEL_800189f;
                }
                if (a32)
                {
                    v54 = v24 + (v0 >> 3) & 0xffff;
                    if (a36 >= v0 && v24 > (a21 + 16 & 0xffff))
                        v54 = v54 + (v24 >> 1) + ((unsigned short)a18 >> 1) & 0xffff;
                    if (v54 > 360)
                        v54 = 360;
                    if (80 > (unsigned short)v54)
                        v54 = 80;
                    iter = v54 & 0xffff;
                    if (a13 > 0)
                        iter = -iter;
                    g_20000377 = 4;
                    g_20000376 = 0;
                    v53 = 14;
                    goto LABEL_800189f;
                }
                else
                {
                    if (0 > v23)
                        a33 = -a33;
                    if (0 >= a22)
                        a22 = 1;
                    iter = ((int)((v23 >> 31 & 3) + v23) >> 2) + (a33 - a13) * a22 - a24 * a13;
                    if ((int)a33 > 24)
                    {
                        iter += a18;
                    }
                    else if ((int)a33 < -0x18)
                    {
                        iter -= a18;
                    }
                    if (v0 > a19)
                    {
                        v55 = ((int)(v0 - a19) >> 1) + a26 + a18;
                        v56 = a15;
                        if ((int)v56 > (int)v55)
                            v56 = v55;
                        if (v23 > 0)
                        {
                            if ((int)v56 > (int)iter)
                                goto LABEL_8001acd;
                        }
                        else
                        {
                            if (v23 && !(v56 = -v56, (int)v56 >= (int)iter))
                            {
LABEL_8001acd:
                                iter = v56;
                            }
                        }
                    }
                    if (!a28 && v0 > a30 && a37 >= v24)
                    {
                        if (g_20000376 > 29 || (g_20000376 = g_20000376 + 1, g_20000376 == 30))
                        {
                            v57 = v51 + v0 * 2 & 0xffff;
                            if (v57 > a15)
                                v57 = (unsigned short)a15;
                            iter = v57 & 0xffff;
                            if (0 > v23)
                                iter = -iter;
                            g_20000377 = 6;
                            v53 = 16;
                        }
                        else
                        {
                            g_20000377 = 2;
                            v53 = 12;
                        }
LABEL_800189f:
                        a13 = v53;
                    }
                    else
                    {
                        g_20000376 = 0;
                        if (v0 > a19)
                        {
                            v58 = 2;
                            a13 = 12;
                        }
                        else
                        {
                            v58 = 3;
                            a13 = 13;
                        }
                        g_20000377 = v58;
                    }
                }
            }
            else
            {
                v59 = v51 + v0 * 8 & 0xffff;
                v60 = a23;
                if (a23 > v59)
                    v60 = v59;
                iter = v60;
                if (0 > v23)
                    iter = -iter;
                g_20000377 = 6;
                a13 = 16;
                v50 = 0;
LABEL_80019f9:
                a12 = v50;
            }
        }
        v61 = a15;
        if ((int)v61 >= (int)iter)
        {
            v61 = -v61;
            if ((int)iter > (int)v61)
                v61 = iter;
        }
        v62 = 1;
        if (0 >= v23)
            v62 = -(v23 - (v23 - 1) - (1 > (unsigned int)v23));
        g_20000372 = v62;
        v63 = *(int *)0x200001b4;
        if (*(int *)0x200001b4)
            v61 = -v61;
        v64 = (short)v61;
        if (!a12)
        {
            v65 = 1;
            a12 = v64 & 0xffff;
            if (0 >= (int)v64)
            {
                v65 = -(v64 - (v64 - 1) - (1 > v64));
                if (v64)
                    a12 = -(v64 & 0xffff) & 0xffff;
            }
            if (g_20000354)
            {
                if ((int)(a31 - g_20000350) >= 0)
                {
                    g_20000354 = 0;
                    g_2000034c = 0;
                }
                else
                {
                    sub_80007b9();
                    g_20000358 = 0;
                    g_2000035c = 9;
                    a6 = 3;
                    a5 = 0;
                    goto LABEL_8001b7d;
                }
            }
            if (g_2000034c && v65 && g_2000034c != v65)
            {
                sub_80007b9();
                g_20000358 = 0;
                g_2000035c = 9;
                if (179 >= a12)
                    goto LABEL_8001b8f;
                g_20000350 = a31 + 8;
                g_20000354 = 1;
            }
            else
            {
                v67 = *(int *)0x200000a8;
                if ((unsigned int)*(int *)0x200000a8 >= 0x10000)
                    v67 = 80;
                v68 = v67;
                v69 = g_20000358;
                v70 = v67;
                if (0 < (int)v69)
                {
                    if (0 > (int)v64)
                    {
                        v71 = v69 - v68;
                        v72 = v71;
                        if ((int)(v71 * 0x10000) >= 0)
                            goto LABEL_8001bdb;
                        goto LABEL_8001d81;
                    }
                    else
                    {
                        if ((int)v69 >= (int)v64)
                            goto LABEL_8001bdd;
                        goto LABEL_8001d99;
                    }
                }
                while (1)
                {
                    if (v69)
                    {
                        if ((int)v64 <= 0)
                            goto LABEL_8001c69;
                        v72 = (unsigned short)v68 + (unsigned short)v69;
                        if (v72 > 0)
                        {
LABEL_8001d81:
                            v72 = 0;
                        }
LABEL_8001bdb:
                        v64 = v72;
                        goto LABEL_8001bdd;
                    }
                    if (0 >= (int)v64)
                    {
LABEL_8001c69:
                        if ((int)v69 <= (int)v64)
                            goto LABEL_8001bdd;
                        if ((int)(v69 - v64) > (int)v70)
                        {
                            v74 = v69 - v68;
                            goto LABEL_8001da3;
                        }
LABEL_8001be1:
                        v75 = v64 & 0xffff;
                        if (0 > (int)v64)
                            v75 = -v75 & 0xffff;
                        if (v63 != g_20000014)
                        {
                            g_20000362 = 0;
                            g_20000364 = 0;
                            g_2000035e = v14;
                            g_20000360 = a11;
                            g_20000014 = v63;
                            break;
                        }
                        if (!*(int *)0x200001cc)
                        {
                            g_20000362 = 0;
                            g_2000035e = v14;
                            g_20000364 = 0;
                            goto LABEL_8001c8d;
                        }
                        if (g_20000360 != 0xffff && (a11 <= g_20000360 ? (unsigned short)(g_20000360 - a11) : (unsigned short)(a11 - g_20000360)) > 60)
                        {
                            g_20000362 = 0;
                            g_20000364 = 0;
                        }
                        v76 = g_2000035e;
                        g_2000035e = v14;
                        if (v76 == 0xffff)
                        {
LABEL_8001c8d:
                            g_20000360 = a11;
                            break;
                        }
                        g_20000360 = a11;
                        if (v0 <= 59 || 179 >= v75)
                        {
                            v79 = g_20000362;
                            if (v79)
                            {
                                g_20000362 = v79 - 1;
                                goto LABEL_8001d27;
                            }
                        }
                        v77 = (short)(v14 - v76);
                        if (v23 <= 0)
                        {
                            if (!v23 || 0 >= (int)v77)
                                goto LABEL_8001d33;
LABEL_8001d0f:
                            if (8 >= (unsigned short)v77)
                            {
                                v78 = g_20000362;
                                if (v78 > 79 || (g_20000362 = (unsigned short)v78 + 1, g_20000362 == 80))
                                {
                                    g_20000364 = 1;
                                    goto LABEL_8001d27;
                                }
                            }
                        }
                        else if (0 > (int)v77)
                        {
                            v77 = (short)(v76 - v14);
                            if (v77)
                                goto LABEL_8001d0f;
                        }
                        else
                        {
LABEL_8001d33:
                            if (!v77)
                                goto LABEL_8001d27;
                        }
                        g_20000362 = 0;
LABEL_8001d27:
                        if (!g_20000364)
                            break;
                        a7 = 0;
                        a6 = 8;
                        v73 = 4;
LABEL_8001bb1:
                        v70 = a11;
                        v69 = v14;
                        v63 = a14;
                        sub_8001061(a9, v63, v70, v69, v23, v73, a6);
                        v68 = sub_80012b7();
                    }
                    else
                    {
LABEL_8001d99:
                        if ((int)v70 < (int)(v64 - v69))
                        {
                            v74 = (unsigned short)v68 + (unsigned short)v69;
LABEL_8001da3:
                            v64 = v74;
                        }
                        else if (!(0 < (int)v69))
                        {
                            goto LABEL_8001c69;
                        }
LABEL_8001bdd:
                        if (!v64)
                        {
LABEL_8001b9d:
                            if (a13 != 14)
                                a13 = 3;
                            a7 = 1;
                            a6 = a13;
                            v73 = 9;
                            goto LABEL_8001bb1;
                        }
                        goto LABEL_8001be1;
                    }
                }
LABEL_8001c0b:
                v80 = v64;
                if (-0x3e8 > (int)v80)
                    v80 = 0xfffffc18;
                if ((short)v80 > 1000)
                    v80 = 1000;
                g_200003d8 = v80;
                v81 = 2;
                if (0 >= (int)v64)
                    v81 = 3;
                g_200003da = v81;
                v82 = 1;
                g_20000358 = v64;
                if (0 >= (int)v64)
                    v82 = 0xff;
                g_2000034c = v82;
                g_20000354 = 0;
                g_2000035c = 2;
                v83 = g_2000002a;
                a5 = v64;
                a6 = a13;
                a4 = v23;
                v84 = v14;
                goto LABEL_8001b83;
            }
        }
        else
        {
            sub_80002c1();
            if (!v64)
                goto LABEL_8001b9d;
            goto LABEL_8001c0b;
        }
        while (1)
        {
            a6 = 3;
            a5 = 0;
LABEL_8001b7d:
            v84 = v14;
            v83 = a11;
            a4 = v23;
LABEL_8001b83:
            sub_80005a1(a9, a14, v83, v84, a4, a5, a6);
            sub_80012b7();
LABEL_8001b8f:
            sub_80002c1();
        }
    }
}
