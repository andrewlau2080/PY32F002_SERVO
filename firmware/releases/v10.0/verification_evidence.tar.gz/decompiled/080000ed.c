extern char g_200002a0;
extern unsigned short g_200002a2;

unsigned int sub_80000ed(unsigned int a0)
{
    unsigned int v0;  // r2

    v0 = g_200002a0 + 1 & 63;
    if (*0x200002a1 != v0)
    {
        (&g_200002a0)[4 + g_200002a0] = a0;
        g_200002a0 = v0;
        return a0;
    }
    g_200002a2 = g_200002a2 + 1;
    return a0;
}
