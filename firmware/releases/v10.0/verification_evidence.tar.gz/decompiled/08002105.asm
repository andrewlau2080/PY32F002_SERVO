08002105 lsls     r0, r4, #0x10
08002107 movs     r0, #0
08002109 b        #0x800230d
0800230d ands     r4, r0
0800230f adds     r4, r4, r2
08002311 subs     r2, r5, #1
08002313 sbcs     r5, r2
08002315 ldr      r2, [pc, #0x54]
08002317 rsbs     r5, r5, #0
08002319 ands     r5, r2
0800231b movs     r2, #0xde
0800231d movs     r7, r1
0800231f movs     r0, #0x12
08002321 adds     r1, #0x28
08002323 str      r4, [sp]
08002325 lsls     r2, r2, #1
08002327 bl       #0x8002221
