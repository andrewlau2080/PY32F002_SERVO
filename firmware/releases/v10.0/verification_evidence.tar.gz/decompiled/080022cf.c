void sub_80022cf(void)
{
    unsigned short v0;  // r6
    unsigned short v1;  // r4
    int v2;  // r5

    sub_800224d(350, 3, 124, 26, v0, v1, 2, v2); /* do not return */
}
