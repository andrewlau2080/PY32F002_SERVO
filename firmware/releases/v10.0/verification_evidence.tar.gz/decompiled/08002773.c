typedef struct st_8000d69_1 {
    unsigned int field_0;
    unsigned int field_4;
} st_8000d69_1;

extern char _binary__tmp_servo_original_v96_app_bin_start;
extern char g_80049b0;
extern unsigned short g_20000000;
extern unsigned int g_20000038;
extern unsigned int g_2000003c;
extern unsigned short g_200001a8;
extern unsigned short g_200003dc;
extern unsigned int g_200003e0;
extern unsigned int g_200003e4;
extern unsigned int g_200003e8;
extern unsigned int g_200003ec;
extern unsigned int g_200003f0;
extern unsigned int g_200003f4;
extern unsigned short g_200003f8;
extern unsigned int g_200003fc;
extern unsigned int g_20000400;
extern unsigned int g_20000404;
extern unsigned int g_20000408;
extern char g_2000040c;
extern unsigned int g_20000410;
extern unsigned int g_20000414;
extern char g_2000041a;
extern unsigned int g_20000424;
extern unsigned short g_2000042e;
extern unsigned int g_20000728;
extern unsigned int g_2000072c;
extern unsigned int g_20000730;
extern unsigned int g_20000734;
extern unsigned int g_20000738;
extern unsigned int g_2000073c;
extern unsigned int g_20000740;
extern unsigned int g_20000744;
extern unsigned int g_20000748;
extern unsigned int g_2000074c;
extern unsigned int g_20000750;
extern unsigned int g_20000754;
extern unsigned int g_20000758;
extern unsigned int g_2000075c;
extern unsigned int g_20000760;
extern unsigned int g_20000764;
extern unsigned int g_20000768;
extern unsigned int g_2000076c;
extern unsigned int g_20000770;
extern unsigned int g_20000774;
extern unsigned int g_20000778;
extern unsigned int g_2000077c;
extern unsigned int g_20000780;
extern unsigned int g_20000788;
extern unsigned int g_2000078c;
extern unsigned int g_20000790;
extern unsigned int g_20000794;
extern unsigned int g_20000798;
extern unsigned int g_2000079c;
extern unsigned int g_200007a0;
extern unsigned int g_200007a4;
extern unsigned int g_40012408;
extern unsigned int g_4001240c;
extern unsigned int g_40012410;
extern unsigned int g_40012414;
extern unsigned int g_40014400;
extern unsigned int g_4001440c;
extern unsigned int g_40014410;
extern unsigned int g_40014414;
extern unsigned int g_40014424;
extern unsigned int g_40014428;
extern unsigned int g_4001442c;
extern unsigned int g_40021000;
extern unsigned int g_40021004;
extern unsigned int g_40021008;
extern unsigned int g_40021030;
extern unsigned int g_40021034;
extern unsigned int g_40021040;
extern unsigned int g_40022000;
extern unsigned int g_50000018;
extern unsigned int g_e000e100;
extern unsigned int g_e000e414;
extern unsigned int g_e000ed08;

void sub_8002773(void)
{
    unsigned int v19;  // r4
    unsigned int v20;  // r5
    unsigned int v30;  // r2
    unsigned int v21;  // r6
    unsigned int v22;  // r7
    unsigned int v23;  // lr
    unsigned int v24;  // r1
    unsigned int v25;  // r0
    char v26;  // r3
    unsigned int v27;  // r0
    char v28;  // r3
    unsigned int v0;  // [bp-0xd4]
    unsigned int v1;  // [bp-0xd0]
    unsigned int v2;  // [bp-0x9c]
    unsigned int v3;  // [bp-0x98]
    unsigned int v4;  // [bp-0x94]
    unsigned int v5;  // [bp-0x90]
    unsigned int v6;  // [bp-0x8c]
    unsigned int v7;  // [bp-0x88]
    unsigned int v8;  // [bp-0x84]
    st_8000d69_1 v9;  // [bp-0x80], Other Possible Types: char
    unsigned int v10;  // [bp-0x7c]
    unsigned int v11;  // [bp-0x64]
    unsigned int v12;  // [bp-0x60]
    char v13;  // [bp-0x5c]
    unsigned int v14;  // [bp-0x14]
    unsigned int v15;  // [bp-0x10]
    unsigned int v16;  // [bp-0xc]
    unsigned int v17;  // [bp-0x8]
    unsigned int v18;  // [bp-0x4]

    v14 = v19;
    v15 = v20;
    v16 = v21;
    v17 = v22;
    v18 = v23;
    g_e000ed08 = &_binary__tmp_servo_original_v96_app_bin_start;
    /* unsupported instruction */;
    /* unsupported instruction */;
    sub_80038f9();
    sub_800083d(3);
    v24 = (0x8000 | *(int *)0x1fff0f10 & 0x1fff) - 5;
    if (!(g_40021008 & 56))
    {
        g_40021004 = (g_40021004 >> 16) * 0x10000 | v24;
        while (!(g_40021000 & 0x400))
        {
            if (2 < (unsigned int)(*(int *)0x20000340 - *(int *)0x20000340))
                sub_8000a9d(); /* do not return */
        }
        g_40021000 = g_40021000 & 0xffffc7ff;
        v25 = sub_8000899();
        v26 = (char)*(int *)&(&g_80049b0)[96 + 4 * (g_40021008 * 0x100000 >> 28)] & 31;
        g_20000038 = v25 >> (v26 & 31) & (char)(v26 - 32) >> 31;
        if (sub_800083d(g_2000003c))
            sub_8000a9d(); /* do not return */
LABEL_8002801:
        g_40021008 = 0x7000 | g_40021008;
        g_40021008 = g_40021008 & 0xfffff0ff;
        if ((int)(g_40021000 * 0x200000) < 0)
        {
            g_40021008 = g_40021008 & ~7;
            do
            {
                if (!(g_40021008 & 56))
                {
                    if (!(g_40022000 & 1))
                    {
LABEL_800283f:
                        g_40021008 = g_40021008 & 0xffff8fff;
                        v27 = sub_8000899();
                        v28 = (char)*(int *)&(&g_80049b0)[96 + 4 * (g_40021008 * 0x100000 >> 28)] & 31;
                        g_20000038 = v27 >> (v28 & 31) & (char)(v28 - 32) >> 31;
                        if (!sub_800083d(g_2000003c))
                        {
                            g_40021034 = g_40021034 | 1;
                            v5 = g_40021034 & 1;
                            sub_80038f9(&v13);
                            g_40021034 = g_40021034 | 1;
                            v6 = g_40021034 & 1;
                            g_50000018 = 1;
                            v11 = 1;
                            v12 = 1;
                            sub_8000925(0x50000000, &v11);
                            sub_8000a5d();
                            while (199 >= (unsigned int)(*(int *)0x20000340 - *(int *)0x20000340))
                            {
                                sub_80003d1();
                            }
                            if (...)
                            {
                                sub_8003855(&g_20000728, 134238080, 128);
                            }
                            else
                            {
                                g_20000754 = 32768008;
                                g_20000758 = 19660804;
                                g_20000740 = 0x20000;
                                g_2000075c = 6554100;
                                g_20000764 = 327880;
                                g_20000728 = 1397904976;
                                g_20000768 = 327683;
                                g_2000076c = 262148;
                                g_20000744 = 25165832;
                                g_20000770 = 196612;
                                g_20000730 = 98304900;
                                g_20000748 = 10486610;
                                g_20000734 = 39323700;
                                g_2000074c = 65536003;
                                g_20000738 = 0xda70800;
                                g_20000750 = 0x1000100;
                                g_2000079c = 0x1000100;
                                g_20000774 = 0x40000;
                                g_20000778 = 1048578;
                                g_2000073c = 0;
                                g_2000077c = 1310728;
                                g_20000760 = 0;
                                g_20000780 = 12582936;
                                g_200007a0 = 82;
                                wcsncpy(0x20000784, L"<x", 2);
                                g_2000072c = 8388611;
                                g_20000788 = 7864640;
                                g_2000078c = 196616;
                                g_20000790 = 16387300;
                                g_20000794 = 1310800;
                                g_20000798 = 14418100;
                                g_200007a4 = 0;
                                g_200007a4 = sub_80007ed(&g_20000728);
                            }
                            sub_80038f9(&v13, 0, 12);
                            sub_80038f9(&v9, 0, 12);
                            g_40021034 = g_40021034 | 1;
                            v4 = g_40021034 & 1;
                            g_40021030 = g_40021030 | 0x100000;
                            g_40021030 = g_40021030 & 0xffefffff;
                            g_40021040 = g_40021040 | 0x100000;
                            v3 = g_40021040 & 0x100000;
                            v11 = 16;
                            v12 = 3;
                            sub_8000925(0x50000000, &v11);
                            g_200003e0 = 0x40012400;
                            if (g_2000040c != 1)
                            {
                                g_2000040c = 1;
                                if (!(g_40012408 & 1))
                                {
                                    g_20000410 = 2 | g_20000410 & 0xfffffefd;
                                    g_40012408 = 0x80000000 | g_40012408;
                                    do
                                    {
                                        if (0 <= (int)g_40012408)
                                        {
                                            v0 = &g_200003e0;
                                            g_20000410 = g_20000410 & ~2;
                                            g_200003f4 = 4;
                                            g_2000040c = 0;
                                            g_200003e4 = &g_20000000;
                                            g_200003f8 = 1;
                                            g_200003e8 = 0;
                                            *(char *)(v0 + 26) = 0;
                                            g_200003ec = 0;
                                            g_20000400 = 0;
                                            g_20000404 = 0;
                                            g_20000408 = 5;
                                            g_200003f0 = 1;
                                            g_200003fc = 449;
                                            if (!g_20000410)
                                            {
                                                g_20000414 = 0;
                                                g_40021040 = g_40021040 | 0x100000;
                                                v8 = g_40021040 & 0x100000;
                                                g_40021034 = g_40021034 | 1;
                                                v7 = 1 & g_40021034;
                                            }
                                            if ((int)(g_20000410 * 0x8000000) >= 0)
                                            {
                                                v1 = g_40012408 & 4;
                                                if (!(g_40012408 & 4))
                                                {
                                                    g_20000410 = 2 | g_20000410 & 0xfffffefd;
                                                    if (!(g_40012408 & 1))
                                                    {
                                                        g_4001240c = g_4001240c & ~24;
                                                        g_40012410 = g_40012410 & 0xfffffff | &g_20000000;
                                                    }
                                                    g_4001240c = g_4001240c & 0xfffec21b;
                                                    g_4001240c = g_4001240c | 0x5000;
                                                    g_40012414 = g_40012414 & ~7;
                                                    g_40012414 = 5 | g_40012414;
                                                    if ((g_4001240c & 0xc33fffe7) != 0x5000)
                                                    {
                                                        g_20000410 = 16 | g_20000410 & ~18;
                                                        g_20000414 = 1 | g_20000414;
                                                        sub_8000a9d(); /* do not return */
                                                    }
                                                    g_20000414 = 0;
                                                    g_20000410 = g_20000410 & ~3 | 1;
                                                    v10 = 0x1000;
                                                    v9 = (st_8000d69_1)4;
                                                    v0 = sub_8000d69(&v9);
                                                    if (v0)
                                                        sub_8000a9d(); /* do not return */
                                                    g_2000042e = sub_8000ea5(sub_8000ab1((unsigned int)sub_8000e61(12, 0x5000, 1), 0x5000), 0x5000);
                                                    sub_800210d();
                                                    sub_8000c91(0x50000000, 2);
                                                    sub_8000c91(0x50000000, 4);
                                                    sub_8000c91(0x50000000, 64);
                                                    sub_8000c91(0x50000400, 1);
                                                    sub_80007b9();
                                                    g_200001a8 = 1000;
                                                    g_200003dc = v0;
                                                    v30 = 1;
                                                    if (g_20000038 > 999999)
                                                        v30 = sub_8004671(g_20000038, 1000000, 1, 999999);
                                                    g_40021040 = g_40021040 | 0x20000;
                                                    v2 = g_40021040 & 0x20000;
                                                    g_40014400 = 0;
                                                    g_4001440c = 0;
                                                    g_40014428 = v30 - 1;
                                                    g_4001442c = 19;
                                                    g_40014424 = 0;
                                                    g_40014410 = 0;
                                                    g_4001440c = 1;
                                                    g_40014414 = 1;
                                                    g_40014400 = 1;
                                                    g_e000e414 = 0x8000 | 0xffff00ff & g_e000e414;
                                                    g_e000e100 = 0x200000;
                                                    g_20000424 = *(int *)0x20000340;
                                                    g_2000041a = 1;
                                                    sub_8001e49(500, *(int *)0x20000340);
                                                    sub_8002725(9600); /* do not return */
                                                }
                                            }
                                            g_20000410 = 16 | g_20000410;
                                            sub_8000a9d(); /* do not return */
                                        }
                                    } while (2 >= (unsigned int)(*(int *)0x20000340 - *(int *)0x20000340));
                                    g_20000410 = 16 | g_20000410 & ~18;
                                    g_2000040c = 0;
                                    break;
                                }
                                else
                                {
                                    g_20000410 = 32 | g_20000410;
                                    g_2000040c = 0;
                                    break;
                                }
                            }
                        }
                    }
                    else
                    {
                        g_40022000 = g_40022000 & ~1;
                        do
                        {
                            if (!(g_40022000 & 1))
                                goto LABEL_800283f;
                        } while ((unsigned int)(*(int *)0x20000340 - *(int *)0x20000340) <= 5000);
                    }
                }
            } while (5000 >= (unsigned int)(*(int *)0x20000340 - *(int *)0x20000340));
        }
    }
    else
    {
        g_40021000 = g_40021000 & 0xffffc7ff;
        g_40021000 = 0x100 | g_40021000;
        do
        {
            if (g_40021000 & 0x400)
            {
                g_40021004 = (g_40021004 >> 16) * 0x10000 | v24;
                goto LABEL_8002801;
            }
        } while ((unsigned int)(*(int *)0x20000340 - *(int *)0x20000340) <= 2);
    }
    sub_8000a9d(); /* do not return */
}
