int sub_8002743(void)
{
    int v1;  // r4
    char v0;  // [bp+0x0]

    sub_80021d5(&v0);
    sub_8003a1d(&v0, 24, "baud=%lu", v1); /* do not return */
}
