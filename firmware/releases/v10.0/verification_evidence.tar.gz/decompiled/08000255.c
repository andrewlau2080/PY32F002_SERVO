unsigned int sub_8000255(unsigned int a0)
{
    if (a0 <= 500)
    {
        return 250;
    }
    else if (2499 >= a0)
    {
        return (1500 < a0 ? (unsigned short)sub_8004671((a0 + 0xfffffa24) * 1400 + 500, 1000) + 1650 : (unsigned short)sub_8004671((a0 - 500) * 1400 + 500, 1000) + 250);
    }
    else
    {
        return 3050;
    }
}
