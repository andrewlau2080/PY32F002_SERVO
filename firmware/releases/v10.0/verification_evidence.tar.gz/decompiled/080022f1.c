int sub_80022f1(unsigned int a0, unsigned int a1, unsigned int a2, unsigned int a3)
{
    unsigned int v7;  // r4
    unsigned int v8;  // r5
    unsigned int v9;  // r6
    unsigned int v10;  // r7
    unsigned int v11;  // lr
    unsigned int v0;  // [bp-0x20]
    unsigned int v1;  // [bp-0x1c]
    unsigned int v2;  // [bp-0x14]
    unsigned int v3;  // [bp-0x10]
    unsigned int v4;  // [bp-0xc]
    unsigned int v5;  // [bp-0x8]
    unsigned int v6;  // [bp-0x4]

    v2 = v7;
    v3 = v8;
    v4 = v9;
    v5 = v10;
    v6 = v11;
    v1 = a3;
    v0 = a2;
}
