int sub_8000001(unsigned int a0, unsigned int a1)
{
    return sub_80000c1(0, 841482290);
}
