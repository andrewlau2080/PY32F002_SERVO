08002513 movs     r3, #0xf8
08002515 movs     r2, r5
08002517 movs     r0, #3
08002519 ldr      r1, [pc, #0x148]
0800251b str      r4, [sp]
0800251d lsls     r3, r3, #8
0800251f bl       #0x80022f1
