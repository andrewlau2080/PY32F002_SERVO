080040e7 adds     r3, r0, #1
080040e9 beq      #0x800411d
080040eb ldr      r3, [r4]
080040ed lsls     r3, r3, #0x1e
080040ef bpl      #0x800412f
080040f1 ldr      r3, [r4, #0xc]
080040f3 ldr      r0, [sp, #0x14]
080040f5 subs     r2, r3, r0
080040f7 cmp      r2, #0
080040f9 ble      #0x8004133
080040fb movs     r6, r4
080040fd movs     r5, #0
080040ff adds     r6, #0x19
08004101 b        #0x800410f
0800410f movs     r3, #1
08004111 movs     r2, r6
08004113 mov      r1, r8
08004115 movs     r0, r7
08004117 blx      sb
0800412f ldr      r3, [r4, #0xc]
08004131 ldr      r0, [sp, #0x14]
08004133 cmp      r0, r3
08004135 bge      #0x8004121
08004137 movs     r0, r3
08004139 b        #0x8004121
