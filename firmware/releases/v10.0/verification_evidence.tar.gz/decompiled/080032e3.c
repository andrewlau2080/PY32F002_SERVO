extern unsigned short g_2000000c;
extern unsigned short g_20000022;

int sub_80032e3(unsigned int a0, unsigned int a1, unsigned int a2, unsigned int a3, unsigned int a4, unsigned int a5, unsigned int a6, unsigned int a7, unsigned short a8, unsigned int a9, unsigned short a10)
{
    g_2000000c = a8;
    g_20000022 = a10;
}
