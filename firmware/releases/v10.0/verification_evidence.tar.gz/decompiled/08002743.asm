08002743 mov      r0, sp
08002745 bl       #0x80021d5
08002749 movs     r3, r4
0800274b movs     r1, #0x18
0800274d ldr      r2, [pc, #0x1c]
0800274f mov      r0, sp
08002751 bl       #0x8003a1d
