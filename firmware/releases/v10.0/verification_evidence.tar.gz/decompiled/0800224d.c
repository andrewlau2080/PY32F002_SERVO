void sub_800224d(int a0, int a1, int a2, int a3, unsigned short a4, unsigned short a5, char a6, int a7)
{
    unsigned int v6;  // r4
    unsigned int v7;  // r5
    unsigned int v8;  // r6
    unsigned int v9;  // r7
    unsigned int v10;  // lr
    char v0;  // [bp-0x158]
    unsigned int v1;  // [bp-0x14]
    unsigned int v2;  // [bp-0x10]
    unsigned int v3;  // [bp-0xc]
    unsigned int v4;  // [bp-0x8]
    unsigned int v5;  // [bp-0x4]

    v1 = v6;
    v2 = v7;
    v3 = v8;
    v4 = v9;
    v5 = v10;
    sub_8003a1d(&v0, 320, "xstr %u,%u,%u,%u,%u,%u,%u,%u,1,1,\"%s\"", a0, a1, a2, a3, 0, a4, a5, a6, a7); /* do not return */
}
