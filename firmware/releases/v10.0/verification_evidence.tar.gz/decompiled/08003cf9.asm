08003cf9 push     {r4, r5, r6, r7, lr}
08003cfb mov      lr, fp
08003cfd mov      r7, sl
08003cff mov      r5, r8
08003d01 mov      r6, sb
08003d03 push     {r5, r6, r7, lr}
08003d05 movs     r4, r3
08003d07 ldrh     r3, [r1, #0xc]
08003d09 mov      sl, r0
08003d0b mov      fp, r1
08003d0d mov      r8, r2
08003d0f sub      sp, #0x74
08003d11 lsls     r3, r3, #0x18
08003d13 bpl      #0x8003d1d
08003d15 ldr      r3, [r1, #0x10]
08003d17 cmp      r3, #0
08003d19 bne      #0x8003d1d
08003d1b b        #0x8003ef9
08003d1d movs     r3, #0
08003d1f add      r5, sp, #0x10
08003d21 str      r3, [r5, #0x14]
08003d23 adds     r3, #0x20
08003d25 strb     r3, [r5, #0x19]
08003d27 adds     r3, #0x10
08003d29 strb     r3, [r5, #0x1a]
08003d2b mov      r3, r8
08003d2d ldrb     r3, [r3]
08003d2f ldr      r6, [pc, #0x1f0]
08003d31 str      r4, [sp, #0xc]
08003d33 cmp      r3, #0
08003d35 beq      #0x8003e21
08003d37 mov      r4, r8
08003d39 b        #0x8003d45
08003d3b ldrb     r3, [r4, #1]
08003d3d adds     r4, #1
08003d3f cmp      r3, #0
08003d41 bne      #0x8003d45
08003d43 b        #0x8003e3b
08003d45 cmp      r3, #0x25
08003d47 bne      #0x8003d3b
08003d49 mov      r3, r8
08003d4b subs     r7, r4, r3
08003d4d cmp      r4, r8
08003d4f beq      #0x8003d53
08003d51 b        #0x8003e43
08003d53 ldrb     r3, [r4]
08003d55 cmp      r3, #0
08003d57 beq      #0x8003e21
08003d59 movs     r2, #1
08003d5b movs     r3, #0
08003d5d rsbs     r2, r2, #0
08003d5f str      r2, [r5, #4]
08003d61 adds     r2, #0x44
08003d63 adds     r7, r4, #1
08003d65 str      r3, [r5]
08003d67 str      r3, [r5, #0xc]
08003d69 str      r3, [r5, #8]
08003d6b strb     r3, [r5, r2]
08003d6d str      r3, [r5, #0x58]
08003d6f b        #0x8003d7f
08003d71 movs     r3, #1
08003d73 subs     r0, r0, r6
08003d75 lsls     r3, r0
08003d77 ldr      r2, [r5]
08003d79 adds     r7, #1
08003d7b orrs     r3, r2
08003d7d str      r3, [r5]
08003d7f movs     r2, #5
08003d81 movs     r0, r6
08003d83 ldrb     r1, [r7]
08003d85 bl       #0x80042f9
08003d89 cmp      r0, #0
08003d8b bne      #0x8003d71
08003d8d ldr      r3, [r5]
08003d8f lsls     r2, r3, #0x1b
08003d91 bpl      #0x8003d99
08003d93 movs     r2, #0x43
08003d95 movs     r1, #0x20
08003d97 strb     r1, [r5, r2]
08003d99 lsls     r2, r3, #0x1c
08003d9b bpl      #0x8003da3
08003d9d movs     r2, #0x43
08003d9f movs     r1, #0x2b
08003da1 strb     r1, [r5, r2]
08003da3 ldrb     r1, [r7]
08003da5 cmp      r1, #0x2a
08003da7 bne      #0x8003e5b
08003da9 ldr      r2, [sp, #0xc]
08003dab adds     r1, r2, #4
08003dad ldr      r2, [r2]
08003daf str      r1, [sp, #0xc]
08003db1 cmp      r2, #0
08003db3 bge      #0x8003db7
08003db5 b        #0x8003eb1
08003db7 str      r2, [r5, #0xc]
08003db9 ldrb     r1, [r7, #1]
08003dbb adds     r4, r7, #1
08003dbd cmp      r1, #0x2e
08003dbf beq      #0x8003e81
08003dc1 ldr      r3, [pc, #0x160]
08003dc3 movs     r2, #3
08003dc5 movs     r0, r3
08003dc7 mov      r8, r3
08003dc9 bl       #0x80042f9
08003dcd cmp      r0, #0
08003dcf beq      #0x8003de1
08003dd1 mov      r3, r8
08003dd3 subs     r0, r0, r3
08003dd5 movs     r3, #0x40
08003dd7 lsls     r3, r0
08003dd9 ldr      r2, [r5]
08003ddb adds     r4, #1
08003ddd orrs     r3, r2
08003ddf str      r3, [r5]
08003de1 ldrb     r1, [r4]
08003de3 adds     r3, r4, #1
08003de5 movs     r2, #6
08003de7 ldr      r0, [pc, #0x140]
08003de9 mov      r8, r3
08003deb strb     r1, [r5, #0x18]
08003ded bl       #0x80042f9
08003df1 cmp      r0, #0
08003df3 beq      #0x8003ebd
08003df5 ldr      r3, [pc, #0x134]
08003df7 cmp      r3, #0
08003df9 beq      #0x8003ea3
08003dfb add      r3, sp, #0xc
08003dfd str      r3, [sp]
08003dff mov      r2, fp
08003e01 movs     r1, r5
08003e03 mov      r0, sl
08003e05 ldr      r3, [pc, #0x128]
08003e07 b        #0x8003e0b
08003e0b mov      sb, r0
08003e0d mov      r3, sb
08003e0f adds     r3, #1
08003e11 beq      #0x8003e21
08003e13 ldr      r3, [r5, #0x14]
08003e15 add      r3, sb
08003e17 str      r3, [r5, #0x14]
08003e19 mov      r3, r8
08003e1b ldrb     r3, [r3]
08003e1d cmp      r3, #0
08003e1f bne      #0x8003d37
08003e21 mov      r3, fp
08003e23 ldrh     r3, [r3, #0xc]
08003e25 lsls     r3, r3, #0x19
08003e27 bpl      #0x8003e2b
08003e29 b        #0x8003f11
08003e2b ldr      r0, [r5, #0x14]
08003e2d add      sp, #0x74
08003e2f pop      {r4, r5, r6, r7}
08003e31 mov      fp, r7
08003e33 mov      sl, r6
08003e35 mov      sb, r5
08003e37 mov      r8, r4
08003e39 pop      {r4, r5, r6, r7, pc}
08003e3b mov      r3, r8
08003e3d subs     r7, r4, r3
08003e3f cmp      r4, r8
08003e41 beq      #0x8003e21
08003e43 movs     r3, r7
08003e45 mov      r2, r8
08003e47 mov      r1, fp
08003e49 mov      r0, sl
08003e4b bl       #0x8003b0d
08003e4f adds     r3, r0, #1
08003e51 beq      #0x8003e21
08003e53 ldr      r3, [r5, #0x14]
08003e55 adds     r3, r3, r7
08003e57 str      r3, [r5, #0x14]
08003e59 b        #0x8003d53
08003e5b movs     r0, r1
08003e5d subs     r0, #0x30
08003e5f cmp      r0, #9
08003e61 bhi      #0x8003e7b
08003e63 ldr      r3, [r5, #0xc]
08003e65 lsls     r2, r3, #2
08003e67 adds     r3, r2, r3
08003e69 ldrb     r1, [r7, #1]
08003e6b lsls     r3, r3, #1
08003e6d adds     r3, r3, r0
08003e6f movs     r0, r1
08003e71 subs     r0, #0x30
08003e73 adds     r7, #1
08003e75 cmp      r0, #9
08003e77 bls      #0x8003e65
08003e79 str      r3, [r5, #0xc]
08003e7b movs     r4, r7
08003e7d cmp      r1, #0x2e
08003e7f bne      #0x8003dc1
08003e81 ldrb     r1, [r4, #1]
08003e83 cmp      r1, #0x2a
08003e85 bne      #0x8003ed1
08003e87 ldr      r3, [sp, #0xc]
08003e89 adds     r0, r4, #2
08003e8b adds     r2, r3, #4
08003e8d ldr      r3, [r3]
08003e8f str      r2, [sp, #0xc]
08003e91 str      r3, [r5, #4]
08003e93 cmp      r3, #0
08003e95 bge      #0x8003e9d
08003e97 movs     r3, #1
08003e99 rsbs     r3, r3, #0
08003e9b str      r3, [r5, #4]
08003e9d ldrb     r1, [r4, #2]
08003e9f movs     r4, r0
08003ea1 b        #0x8003dc1
08003ea3 movs     r2, #7
08003ea5 ldr      r3, [sp, #0xc]
08003ea7 adds     r3, #7
08003ea9 bics     r3, r2
08003eab adds     r3, #8
08003ead str      r3, [sp, #0xc]
08003eaf b        #0x8003e13
08003eb1 rsbs     r2, r2, #0
08003eb3 str      r2, [r5, #0xc]
08003eb5 movs     r2, #2
08003eb7 orrs     r3, r2
08003eb9 str      r3, [r5]
08003ebb b        #0x8003db9
08003ebd add      r3, sp, #0xc
08003ebf str      r3, [sp]
08003ec1 mov      r2, fp
08003ec3 movs     r1, r5
08003ec5 mov      r0, sl
08003ec7 ldr      r3, [pc, #0x68]
08003ec9 bl       #0x8004071
08003ed1 movs     r0, r1
08003ed3 movs     r3, #0
08003ed5 subs     r0, #0x30
08003ed7 adds     r4, #1
08003ed9 str      r3, [r5, #4]
08003edb cmp      r0, #9
08003edd bls      #0x8003ee1
08003edf b        #0x8003dc1
08003ee1 lsls     r2, r3, #2
08003ee3 adds     r3, r2, r3
08003ee5 ldrb     r1, [r4, #1]
08003ee7 lsls     r3, r3, #1
08003ee9 adds     r3, r3, r0
08003eeb movs     r0, r1
08003eed subs     r0, #0x30
08003eef adds     r4, #1
08003ef1 cmp      r0, #9
08003ef3 bls      #0x8003ee1
08003ef5 str      r3, [r5, #4]
08003ef7 b        #0x8003dc1
08003ef9 movs     r1, #0x40
08003efb bl       #0x80044d9
08003eff mov      r3, fp
08003f01 str      r0, [r3]
08003f03 str      r0, [r3, #0x10]
08003f05 cmp      r0, #0
08003f07 beq      #0x8003f17
08003f09 movs     r3, #0x40
08003f0b mov      r2, fp
08003f0d str      r3, [r2, #0x14]
08003f0f b        #0x8003d1d
08003f11 movs     r0, #1
08003f13 rsbs     r0, r0, #0
08003f15 b        #0x8003e2d
08003f17 movs     r3, #0xc
08003f19 mov      r2, sl
08003f1b subs     r0, #1
08003f1d str      r3, [r2]
08003f1f b        #0x8003e2d
