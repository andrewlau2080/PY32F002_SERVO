08004e29 movs     r0, r2
08004e2b movs     r0, r0
08004e2d movs     r6, r0
08004e2f movs     r0, r0
08004e31 lsls     r0, r4, #2
08004e33 movs     r0, r0
08004e35 movs     r1, r0
08004e37 movs     r0, r0
08004e39 ldr      r4, [pc, #0xdc]
08004e3b lsrs     r0, r0, #0x20
08004e3d ldr      r3, [pc, #0x34]
08004e3f lsrs     r0, r0, #0x20
08004e41 lsls     r0, r4, #3
08004e43 movs     r0, r0
08004e45 movs     r0, r0
08004e47 movs     r0, r0
08004e49 lsls     r0, r4, #0xc
08004e4b movs     r0, r0
