
void sub_8002df3(unsigned int a0, unsigned int a1, unsigned int a2, unsigned int a3, unsigned int a4, unsigned int a5, unsigned int a6, unsigned int a7, unsigned int a8, unsigned int a9, unsigned int a10, unsigned int a11, unsigned int a12, unsigned int a13, unsigned int a14, unsigned int a15, unsigned int a16, unsigned int a17, unsigned int a18, unsigned int a19, unsigned int a20, unsigned int a21, unsigned int a22, unsigned int a23, unsigned int a24, unsigned int a25, unsigned int a26, unsigned int a27, unsigned short a28, unsigned int a29, unsigned int a30, unsigned int a31, unsigned int a32, unsigned int a33, char a34, char a35, unsigned int a36, unsigned int a37, unsigned int a38, unsigned int a39, unsigned int a40, unsigned int a41, unsigned int a42, char a43, unsigned short iter)
{
    unsigned int v23;  // r3
    char v2;  // [bp+0x9c]
    char v4;  // [bp+0x9d]

    v2 = a43;
    v23 = 0;
    v4 = 0;
}
