08003ecd mov      sb, r0
08003ecf b        #0x8003e0d
