080036fb movs     r1, #1
080036fd ldr      r3, [pc, #0x90]
080036ff push     {r4, r5, r6, lr}
08003701 ldr      r2, [r3, #0x10]
08003703 tst      r2, r1
08003705 beq      #0x8003787
08003707 ldr      r2, [r3, #0x10]
08003709 bics     r2, r1
0800370b str      r2, [r3, #0x10]
0800370d ldr      r3, [pc, #0x84]
0800370f movs     r2, r3
08003711 adds     r2, #0x3a
08003713 ldrh     r4, [r3, #0x38]
08003715 ldrb     r1, [r2]
08003717 ldrh     r2, [r3, #0x3c]
08003719 sxth     r4, r4
0800371b adds     r2, #0x14
0800371d uxth     r2, r2
0800371f strh     r2, [r3, #0x3c]
08003721 ldr      r2, [pc, #0x74]
08003723 uxtb     r1, r1
08003725 ldrh     r0, [r2, #0x28]
08003727 ldrh     r5, [r3, #0x3c]
08003729 uxth     r2, r0
0800372b cmp      r0, r5
0800372d bhi      #0x8003733
0800372f movs     r0, #0
08003731 strh     r0, [r3, #0x3c]
08003733 ldr      r5, [pc, #0x68]
08003735 cmp      r1, #0
08003737 beq      #0x800373d
08003739 cmp      r4, #0
0800373b bne      #0x8003753
0800373d movs     r3, #0xa0
0800373f movs     r2, #2
08003741 lsls     r3, r3, #0x17
08003743 str      r2, [r3, #0x28]
08003745 adds     r2, r2, r2
08003747 str      r2, [r3, #0x28]
08003749 movs     r2, #0x40
0800374b str      r2, [r3, #0x28]
0800374d movs     r3, #1
0800374f str      r3, [r5, #0x28]
08003751 b        #0x8003787
08003753 uxth     r0, r4
08003755 cmp      r4, #0
08003757 bge      #0x800375d
08003759 rsbs     r0, r0, #0
0800375b uxth     r0, r0
0800375d movs     r1, #0xfa
0800375f muls     r0, r2, r0
08003761 lsls     r1, r1, #2
08003763 ldrh     r6, [r3, #0x3c]
08003765 bl       #0x8004671
08003769 movs     r3, #0xa0
0800376b uxth     r6, r6
0800376d movs     r2, #2
0800376f lsls     r3, r3, #0x17
08003771 cmp      r0, r6
08003773 bls      #0x8003743
08003775 movs     r1, #4
08003777 cmp      r4, #0
08003779 ble      #0x8003789
0800377b str      r2, [r3, #0x28]
0800377d movs     r2, #0x40
0800377f str      r1, [r3, #0x28]
08003781 str      r2, [r3, #0x18]
08003783 movs     r3, #1
08003785 str      r3, [r5, #0x18]
08003787 pop      {r4, r5, r6, pc}
08003789 str      r2, [r3, #0x18]
0800378b str      r1, [r3, #0x18]
0800378d b        #0x8003749
