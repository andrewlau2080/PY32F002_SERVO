int sub_800465d(unsigned int a0, unsigned int a1)
{
    return a0;
}
