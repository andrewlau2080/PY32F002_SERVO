unsigned int sub_8000239(unsigned int a0)
{
    unsigned int v0;  // r0

    v0 = 1;
    if (a0 >= 500)
        v0 = -(-(a0 > 2500)) * 2;
    return v0;
}
