void sub_80036bf(void)
{
    unsigned int v2;  // r4
    unsigned int v3;  // lr
    unsigned int v0;  // [bp-0x8]
    unsigned int v1;  // [bp-0x4]

    v0 = v2;
    v1 = v3;
    sub_8000a9d(); /* do not return */
}
