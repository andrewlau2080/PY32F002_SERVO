void sub_8002459(void)
{
    sub_8002431(); /* do not return */
}
