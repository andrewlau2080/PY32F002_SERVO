0800331b ldr      r3, [sp, #0x14]
0800331d movs     r0, #3
0800331f asrs     r2, r3, #0x1f
08003321 ldr      r3, [pc, #0xac]
08003323 add      r1, sp, #0x7c
08003325 ands     r2, r3
08003327 adds     r2, #0x1f
08003329 bl       #0x8002371
