08000189 movs     r2, #0
0800018b ldr      r3, [pc, #0x1c]
0800018d strh     r2, [r3, #0x10]
0800018f strh     r2, [r3, #0x12]
08000191 movs     r2, #0xe1
08000193 lsls     r2, r2, #2
08000195 adds     r0, r0, r2
08000197 movs     r2, #1
08000199 strb     r2, [r3, #0x18]
0800019b strb     r2, [r3, #0x19]
0800019d ldr      r2, [r3, #0x1c]
0800019f str      r0, [r3, #0x14]
080001a1 adds     r2, #1
080001a3 str      r2, [r3, #0x1c]
080001a5 bx       lr
