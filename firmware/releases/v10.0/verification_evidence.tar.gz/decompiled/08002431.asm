08002431 movs     r3, r4
08002433 subs     r2, r3, #1
08002435 sbcs     r3, r2
08002437 ldr      r2, [pc, #0x28]
08002439 rsbs     r3, r3, #0
0800243b ands     r3, r2
0800243d movs     r0, r5
0800243f ldr      r1, [r6]
08002441 adds     r3, #0x1f
08002443 str      r4, [sp]
08002445 add      r2, sp, #0xc
08002447 bl       #0x80022f1
