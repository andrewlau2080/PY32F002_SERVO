08002df3 movs     r6, #1
08002df5 ldr      r4, [pc, #0x1f4]
08002df7 ldr      r5, [r4, #0x20]
08002df9 bl       #0x8000115
08002dfd bl       #0x8000155
08002e01 ldr      r3, [pc, #0x1ec]
08002e03 ldrb     r1, [r3, #1]
08002e05 ldrb     r2, [r3]
08002e07 cmp      r1, r2
08002e09 beq      #0x8002e1f
08002e0b mrs      r7, primask
08002e0f cpsid    i
08002e11 ldrb     r1, [r3, #1]
08002e13 ldrb     r2, [r3]
08002e15 cmp      r1, r2
08002e17 beq      #0x8002e1b
08002e19 b        #0x8003061
08002e1b msr      primask, r7
08002e1f ldr      r3, [r4, #0x20]
08002e21 cmp      r5, r3
08002e23 beq      #0x8002df9
08002e25 movs     r5, #0xfa
08002e27 movs     r1, #0xa0
08002e29 ldr      r2, [pc, #0x17c]
08002e2b movs     r0, #0x20
08002e2d ldrh     r3, [r2, #0x1a]
08002e2f lsls     r5, r5, #1
08002e31 adds     r3, #1
08002e33 uxth     r3, r3
08002e35 strh     r3, [r2, #0x1a]
08002e37 lsls     r1, r1, #0x17
08002e39 cmp      r3, r5
08002e3b blo      #0x8002e3f
08002e3d b        #0x80030bd
08002e3f cmp      r3, #0x22
08002e41 bhi      #0x8002e45
08002e43 b        #0x80030c1
08002e45 str      r0, [r1, #0x18]
08002e47 b        #0x80030c3
08002f91 cmp      r0, #0x67
08002f93 beq      #0x8002f97
08002f95 b        #0x8002df5
08002f97 strb     r6, [r2, #0xc]
08002f99 strb     r1, [r2, #0x10]
08002f9b b        #0x8002df5
08003061 movs     r4, #0x3f
08003063 ldrb     r2, [r3, #1]
08003065 adds     r2, r3, r2
08003067 ldrb     r1, [r2, #4]
08003069 ldrb     r2, [r3, #1]
0800306b uxtb     r0, r1
0800306d adds     r2, #1
0800306f ands     r2, r4
08003071 strb     r2, [r3, #1]
08003073 msr      primask, r7
08003077 ldr      r2, [pc, #0x328]
08003079 ldrb     r3, [r2, #0xc]
0800307b cmp      r3, #0
0800307d beq      #0x8002f91
0800307f adds     r0, r3, #1
08003081 uxtb     r0, r0
08003083 adds     r3, r2, r3
08003085 strb     r0, [r2, #0xc]
08003087 strb     r1, [r3, #0x10]
08003089 cmp      r0, #8
0800308b bhi      #0x800308f
0800308d b        #0x8002df5
0800308f movs     r3, #0
08003091 strb     r3, [r2, #0xc]
08003093 ldrb     r3, [r2, #0x10]
08003095 cmp      r3, #0x67
08003097 beq      #0x800309b
08003099 b        #0x8002df5
0800309b ldrb     r3, [r2, #0x17]
0800309d ldrb     r1, [r2, #0x16]
0800309f ands     r1, r3
080030a1 ldrb     r3, [r2, #0x18]
080030a3 ands     r3, r1
080030a5 cmp      r3, #0xff
080030a7 beq      #0x80030ab
080030a9 b        #0x8002df5
080030ab ldrb     r3, [r2, #0x15]
080030ad cmp      r3, #1
080030af bne      #0x80030b3
080030b1 b        #0x80033d9
080030b3 bl       #0x80010b5
080030b7 bl       #0x80003d1
080030bb b        #0x8002df3
080030bd movs     r3, #0
080030bf strh     r3, [r2, #0x1a]
080030c1 str      r0, [r1, #0x28]
080030c3 movs     r1, #0xfa
080030c5 ldr      r5, [pc, #0x2dc]
080030c7 lsls     r1, r1, #2
080030c9 ldr      r0, [r5, #0x38]
080030cb bl       #0x8004671
080030cf bl       #0x80000c1
080030d3 ldr      r3, [r4, #0x20]
080030d5 str      r3, [sp, #0x38]
080030d7 bl       #0x80010b5
080030db add      r3, sp, #0x9c
080030dd ldrb     r3, [r3]
080030df cmp      r3, #0x32
080030e1 bne      #0x80030b7
080030e3 ldr      r3, [sp, #0x38]
080030e5 ldr      r2, [sp, #0x10]
080030e7 subs     r3, r3, r2
080030e9 cmp      r3, #0x95
080030eb bls      #0x80030b7
080030ed add      r0, sp, #0x60
080030ef bl       #0x800053d
080030f3 ldr      r3, [pc, #0x2b4]
080030f5 adds     r3, #0x7b
080030f7 ldrb     r6, [r3]
080030f9 cmp      r6, #0
080030fb beq      #0x8003103
080030fd add      r0, sp, #0x60
080030ff bl       #0x80001d1
08003103 movs     r2, #0x41
08003105 ldr      r3, [sp, #0x70]
08003107 str      r3, [sp, #0x2c]
08003109 add      r3, sp, #0x38
0800310b adds     r3, r3, r2
0800310d movs     r2, #0
0800310f ldrb     r3, [r3]
08003111 str      r2, [sp, #0x30]
08003113 str      r2, [sp, #0xc]
08003115 cmp      r3, r2
08003117 beq      #0x8003137
08003119 ldr      r2, [sp, #0x6c]
0800311b ldr      r3, [r4, #0x20]
0800311d str      r2, [sp, #0x10]
0800311f subs     r3, r3, r2
08003121 ldr      r2, [pc, #0x288]
08003123 ldrh     r2, [r2, #0x36]
08003125 cmp      r3, r2
08003127 bhi      #0x8003137
08003129 add      r3, sp, #0x38
0800312b ldrh     r0, [r3, #0x28]
0800312d bl       #0x8000239
08003131 movs     r3, #1
08003133 str      r0, [sp, #0x30]
08003135 str      r3, [sp, #0xc]
08003137 movs     r3, #0
08003139 ldr      r2, [pc, #0x274]
0800313b str      r3, [sp, #0x24]
0800313d cmp      r6, r3
0800313f bne      #0x800316f
08003141 cpsid    i
08003143 ldrh     r3, [r5, #0x32]
08003145 cmp      r3, r2
08003147 beq      #0x800315f
08003149 movs     r3, r4
0800314b adds     r3, #0x72
0800314d ldrh     r0, [r3]
0800314f ldrh     r1, [r5, #0x32]
08003151 cmp      r0, r1
08003153 blo      #0x800315f
08003155 ldrh     r3, [r3]
08003157 ldrh     r1, [r5, #0x32]
08003159 subs     r3, r3, r1
0800315b uxth     r3, r3
0800315d str      r3, [sp, #0x24]
0800315f movs     r3, #1
08003161 rsbs     r3, r3, #0
08003163 strh     r3, [r5, #0x32]
08003165 movs     r3, r4
08003167 movs     r1, #0
08003169 adds     r3, #0x72
0800316b strh     r1, [r3]
0800316d cpsie    i
0800316f movs     r3, r4
08003171 adds     r3, #0x4d
08003173 ldrb     r3, [r3]
08003175 cmp      r3, #0
08003177 beq      #0x800317b
08003179 b        #0x800351b
0800317b ldr      r3, [pc, #0x224]
0800317d ldrh     r3, [r3, #0xe]
0800317f str      r3, [sp, #0x10]
08003181 ldr      r3, [pc, #0x224]
08003183 adds     r3, #0x78
08003185 ldrh     r3, [r3]
08003187 str      r3, [sp, #0x3c]
08003189 ldr      r3, [pc, #0x218]
0800318b ldrh     r1, [r3, #0x20]
0800318d movs     r3, #0
0800318f str      r3, [sp, #0x18]
08003191 cmp      r1, r2
08003193 beq      #0x80031a5
08003195 ldr      r3, [pc, #0x21c]
08003197 adds     r3, #0x4e
08003199 ldrh     r3, [r3]
0800319b cmp      r1, r3
0800319d bhi      #0x80031a5
0800319f subs     r3, r3, r1
080031a1 uxth     r3, r3
080031a3 str      r3, [sp, #0x18]
080031a5 movs     r3, #1
080031a7 movs     r0, #0
080031a9 ldr      r1, [pc, #0x1f8]
080031ab rsbs     r3, r3, #0
080031ad strh     r3, [r1, #0x20]
080031af ldr      r3, [pc, #0x204]
080031b1 ldrh     r7, [r1, #0x1a]
080031b3 adds     r3, #0x4e
080031b5 strh     r0, [r3]
080031b7 cmp      r7, r2
080031b9 bne      #0x80031bf
080031bb add      r3, sp, #0x60
080031bd ldrh     r7, [r3]
080031bf ldr      r5, [sp, #0xc]
080031c1 subs     r4, r5, #0
080031c3 str      r5, [sp, #0x14]
080031c5 beq      #0x80031f1
080031c7 movs     r0, r7
080031c9 bl       #0x8000255
080031cd movs     r5, r0
080031cf ldr      r3, [pc, #0x1e8]
080031d1 lsls     r0, r0, #0xc
080031d3 subs     r0, r0, r5
080031d5 adds     r0, r0, r3
080031d7 ldr      r1, [pc, #0x1e4]
080031d9 bl       #0x8004671
080031dd movs     r3, #0x80
080031df lsls     r3, r3, #5
080031e1 cmp      r0, r3
080031e3 blo      #0x80031e7
080031e5 ldr      r0, [pc, #0x1d8]
080031e7 ldr      r3, [sp, #0x10]
080031e9 uxth     r4, r0
080031eb subs     r6, r4, r3
080031ed sxth     r3, r6
080031ef str      r3, [sp, #0x14]
080031f1 ldr      r3, [pc, #0x1c0]
080031f3 movs     r2, #0x38
080031f5 ldrsh    r6, [r3, r2]
080031f7 movs     r2, #0x3a
080031f9 ldrsh    r3, [r3, r2]
080031fb str      r3, [sp, #0x20]
080031fd ldr      r3, [pc, #0x1a8]
080031ff adds     r3, #0x31
08003201 ldrb     r3, [r3]
08003203 uxtb     r3, r3
08003205 str      r3, [sp, #0x28]
08003207 uxth     r3, r6
08003209 str      r3, [sp, #0x34]
0800320b movs     r3, #1
0800320d str      r3, [sp, #0x1c]
0800320f cmp      r6, #0
08003211 bgt      #0x8003229
08003213 movs     r3, r6
08003215 subs     r2, r3, #1
08003217 sbcs     r3, r2
08003219 rsbs     r3, r3, #0
0800321b str      r3, [sp, #0x1c]
0800321d cmp      r6, #0
0800321f beq      #0x8003229
08003221 uxth     r3, r6
08003223 rsbs     r3, r3, #0
08003225 uxth     r3, r3
08003227 str      r3, [sp, #0x34]
08003229 ldr      r3, [sp, #0x2c]
0800322b cmp      r3, #0
0800322d beq      #0x800327f
0800322f ldr      r3, [pc, #0x174]
08003231 add      r1, sp, #0x60
08003233 ldrh     r0, [r3, #2]
08003235 ldrh     r2, [r1, #2]
08003237 cmp      r0, r7
08003239 bne      #0x8003251
0800323b ldrh     r0, [r3]
0800323d cmp      r0, r2
0800323f bne      #0x8003251
08003241 ldr      r1, [sp, #0x68]
08003243 ldr      r0, [r3, #4]
08003245 cmp      r1, r0
08003247 bne      #0x8003251
08003249 ldrh     r3, [r3, #0x1e]
0800324b ldr      r1, [sp, #0x24]
0800324d cmp      r3, r1
0800324f beq      #0x800327f
08003251 ldr      r3, [sp, #0x24]
08003253 movs     r1, #0x20
08003255 str      r3, [sp, #4]
08003257 str      r2, [sp]
08003259 movs     r3, r7
0800325b ldr      r2, [pc, #0x168]
0800325d add      r0, sp, #0x7c
0800325f bl       #0x8003a1d
0800327f ldr      r3, [sp, #0xc]
08003281 ldr      r7, [pc, #0x120]
08003283 cmp      r3, #0
08003285 bne      #0x8003289
08003287 b        #0x8003521
08003289 ldrh     r3, [r7, #0xa]
0800328b cmp      r3, r5
0800328d bne      #0x8003295
0800328f ldrh     r3, [r7, #8]
08003291 cmp      r3, r4
08003293 beq      #0x80032b3
08003295 movs     r3, r4
08003297 movs     r1, #0x20
08003299 ldr      r2, [pc, #0x12c]
0800329b str      r5, [sp]
0800329d add      r0, sp, #0x7c
0800329f bl       #0x8003a1d
080032b3 ldr      r3, [pc, #0xf0]
080032b5 ldr      r1, [sp, #0x10]
080032b7 ldrh     r2, [r3, #0xc]
080032b9 cmp      r2, r1
080032bb bne      #0x80032c5
080032bd ldrh     r3, [r3, #0x22]
080032bf ldr      r2, [sp, #0x18]
080032c1 cmp      r3, r2
080032c3 beq      #0x80032ed
080032c5 ldr      r3, [sp, #0x18]
080032c7 movs     r1, #0x20
080032c9 str      r3, [sp, #4]
080032cb ldr      r3, [sp, #0x10]
080032cd ldr      r2, [pc, #0xf4]
080032cf str      r3, [sp]
080032d1 add      r0, sp, #0x7c
080032d3 ldr      r3, [sp, #0x3c]
080032d5 bl       #0x8003a1d
080032ed ldr      r4, [pc, #0xb4]
080032ef movs     r3, #0xe
080032f1 ldrsh    r2, [r4, r3]
080032f3 ldr      r3, [sp, #0xc]
080032f5 cmp      r3, #0
080032f7 bne      #0x80032fb
080032f9 b        #0x8003541
080032fb ldr      r3, [pc, #0xb8]
080032fd ldr      r1, [sp, #0x14]
080032ff adds     r3, #0x50
08003301 ldrh     r3, [r3]
08003303 cmp      r2, r1
08003305 bne      #0x800330d
08003307 ldrh     r2, [r4, #0x24]
08003309 cmp      r2, r3
0800330b beq      #0x800333b
0800330d movs     r1, #0x20
0800330f ldr      r2, [pc, #0xbc]
08003311 str      r3, [sp]
08003313 add      r0, sp, #0x7c
08003315 ldr      r3, [sp, #0x14]
08003317 bl       #0x8003a1d
0800333b movs     r2, #0x12
0800333d ldr      r3, [pc, #0x64]
0800333f ldr      r1, [sp, #0x1c]
08003341 ldrsb    r2, [r3, r2]
08003343 cmp      r2, r1
08003345 beq      #0x800334d
08003347 ldr      r2, [pc, #0x8c]
08003349 strb     r1, [r3, #0x12]
0800334b strh     r2, [r3, #0x10]
0800334d ldr      r3, [sp, #0xc]
0800334f cmp      r3, #0
08003351 bne      #0x8003355
08003353 b        #0x8003577
08003355 ldr      r3, [pc, #0x5c]
08003357 adds     r3, #0x3c
08003359 ldrb     r4, [r3]
0800335b ldr      r3, [sp, #0x30]
0800335d cmp      r3, #1
0800335f beq      #0x8003363
08003361 b        #0x800355f
08003363 movs     r2, #0xfb
08003365 subs     r3, r4, #4
08003367 tst      r3, r2
08003369 beq      #0x800336d
0800336b b        #0x8003585
0800336d ldr      r3, [pc, #0x34]
0800336f ldrb     r2, [r3, #0x13]
08003371 cmp      r2, r4
08003373 beq      #0x8003377
08003375 b        #0x8003637
08003377 movs     r1, #0x10
08003379 ldrsh    r2, [r3, r1]
0800337b cmp      r2, r6
0800337d beq      #0x8003381
0800337f b        #0x8003637
08003381 movs     r1, #0x26
08003383 ldrsh    r2, [r3, r1]
08003385 ldr      r1, [sp, #0x20]
08003387 cmp      r2, r1
08003389 beq      #0x800338d
0800338b b        #0x8003637
0800338d adds     r3, #0x28
0800338f ldrb     r3, [r3]
08003391 ldr      r2, [sp, #0x28]
08003393 cmp      r3, r2
08003395 beq      #0x8003399
08003397 b        #0x8003637
08003399 ldr      r3, [sp, #0x38]
0800339b str      r3, [sp, #0x10]
0800339d b        #0x80030b7
080033d9 ldrb     r3, [r2, #0x12]
080033db ldrb     r0, [r2, #0x11]
080033dd lsls     r3, r3, #8
080033df orrs     r3, r0
080033e1 rev16    r3, r3
080033e3 uxth     r1, r3
080033e5 ldrb     r0, [r2, #0x14]
080033e7 str      r1, [sp, #0xc]
080033e9 ldrb     r1, [r2, #0x13]
080033eb add      r4, sp, #0x9c
080033ed lsls     r0, r0, #8
080033ef orrs     r0, r1
080033f1 ldrh     r1, [r4, #4]
080033f3 strh     r3, [r4, #6]
080033f5 ldrb     r3, [r4]
080033f7 rev16    r0, r0
080033f9 adds     r1, #1
080033fb uxth     r2, r0
080033fd strh     r1, [r4, #4]
080033ff strh     r0, [r4, #8]
08003401 cmp      r3, #0x32
08003403 bne      #0x800344d
08003405 cmp      r2, #0xe7
08003407 bhi      #0x800340b
08003409 b        #0x80030b3
0800340b ldr      r3, [sp, #0xc]
0800340d cmp      r3, #0x9f
0800340f bhi      #0x8003417
08003411 movs     r3, #1
08003413 strb     r3, [r4]
08003415 b        #0x8003437
08003417 movs     r3, #0xa0
08003419 ldr      r2, [sp, #0xc]
0800341b lsls     r3, r3, #1
0800341d cmp      r2, r3
0800341f bhs      #0x8003449
08003421 ldr      r3, [pc, #0x23c]
08003423 adds     r3, #0x7b
08003425 ldrb     r2, [r3]
08003427 cmp      r2, #0
08003429 beq      #0x8003443
0800342b movs     r2, #0
0800342d strb     r2, [r3]
0800342f bl       #0x800210d
08003433 bl       #0x80002ed
08003437 movs     r3, #0
08003439 strb     r3, [r4, #1]
0800343b movs     r0, r4
0800343d bl       #0x80024b1
08003443 movs     r2, #1
08003445 strb     r2, [r3]
08003447 b        #0x8003433
08003449 movs     r3, #0x28
0800344b b        #0x8003413
0800344d cmp      r3, #1
0800344f bne      #0x80034a9
08003451 adds     r3, #0x31
08003453 cmp      r2, #0xe7
08003455 bhi      #0x8003503
08003457 movs     r3, r2
08003459 subs     r3, #0x20
0800345b cmp      r3, #0xc7
0800345d bls      #0x8003461
0800345f b        #0x80030b3
08003461 cmp      r2, #0x28
08003463 bhs      #0x8003467
08003465 movs     r0, #0x28
08003467 uxth     r0, r0
08003469 movs     r1, #0x27
0800346b subs     r0, #0x28
0800346d bl       #0x8004671
08003471 ldr      r2, [sp, #0xc]
08003473 movs     r3, #0
08003475 cmp      r2, #0xef
08003477 bls      #0x800347b
08003479 movs     r3, #5
0800347b adds     r0, r0, r3
0800347d sxtb     r0, r0
0800347f subs     r0, #1
08003481 cmp      r0, #6
08003483 bls      #0x8003487
08003485 b        #0x80030b3
08003487 bl       #0x800465d
0800348b movs     r7, r0
080034a9 cmp      r3, #0x28
080034ab bne      #0x80034af
080034ad b        #0x80035f3
080034af bhi      #0x80034c5
080034b1 cmp      r3, #0xd
080034b3 bne      #0x80034b7
080034b5 b        #0x800362b
080034b7 cmp      r3, #0x1e
080034b9 beq      #0x80034bd
080034bb b        #0x80030b3
080034bd ldr      r5, [pc, #0x1a4]
080034bf movs     r6, #5
080034c1 adds     r5, #0x40
080034c3 b        #0x80035f7
080034c5 cmp      r3, #0x46
080034c7 beq      #0x80034cb
080034c9 b        #0x80030b3
080034cb ldr      r5, [pc, #0x19c]
080034cd movs     r6, #5
080034cf adds     r5, #0x30
080034d1 b        #0x80035f7
080034d3 ldr      r3, [sp, #0xc]
080034d5 cmp      r3, #0x9f
080034d7 bhi      #0x80034f5
080034d9 movs     r3, #1
080034db rsbs     r3, r3, #0
080034dd movs     r2, r7
080034df movs     r1, r6
080034e1 movs     r0, r5
080034e3 bl       #0x80001ad
080034e7 movs     r2, r7
080034e9 movs     r1, r6
080034eb movs     r0, r5
080034ed ldrb     r3, [r4, #1]
080034ef bl       #0x80026dd
080034f3 b        #0x80030b3
080034f5 movs     r3, #0xa0
080034f7 ldr      r2, [sp, #0xc]
080034f9 lsls     r3, r3, #1
080034fb cmp      r2, r3
080034fd bhs      #0x8003507
080034ff subs     r3, #0x40
08003501 subs     r3, #0xff
08003503 strh     r3, [r4]
08003505 b        #0x800343b
08003507 movs     r3, #1
08003509 b        #0x80034dd
0800350b movs     r3, #0xa0
0800350d ldr      r1, [sp, #0xc]
0800350f lsls     r3, r3, #1
08003511 cmp      r1, r3
08003513 bls      #0x80034e7
08003515 subs     r3, #0x40
08003517 subs     r3, #0xff
08003519 b        #0x80034df
0800351b adds     r4, #8
0800351d ldrh     r3, [r4, #0x3e]
0800351f b        #0x800317f
08003521 ldrh     r2, [r7, #8]
08003523 ldr      r3, [pc, #0x148]
08003525 cmp      r2, r3
08003527 bne      #0x800352b
08003529 b        #0x80032b3
0800352b movs     r2, #0xf8
0800352d movs     r0, #1
0800352f ldr      r1, [pc, #0x140]
08003531 lsls     r2, r2, #8
08003533 bl       #0x8002371
08003541 ldr      r5, [pc, #0x130]
08003543 cmp      r2, r5
08003545 bne      #0x8003549
08003547 b        #0x800333b
08003549 movs     r2, #0xf8
0800354b movs     r0, #3
0800354d ldr      r1, [pc, #0x120]
0800354f lsls     r2, r2, #8
08003551 bl       #0x8002371
0800355f ldr      r3, [sp, #0x30]
08003561 cmp      r3, #2
08003563 beq      #0x8003567
08003565 b        #0x800336d
08003567 cmp      r4, #4
08003569 bne      #0x800356d
0800356b b        #0x800336d
0800356d cmp      r4, #8
0800356f bne      #0x8003573
08003571 b        #0x800336d
08003573 movs     r4, #6
08003575 b        #0x800336d
08003577 ldr      r3, [sp, #0x2c]
08003579 movs     r4, #3
0800357b subs     r2, r3, #1
0800357d sbcs     r3, r2
0800357f rsbs     r3, r3, #0
08003581 ands     r4, r3
08003583 b        #0x800336d
08003585 movs     r4, #5
08003587 b        #0x800336d
080035d1 ldr      r2, [sp, #0x2c]
080035d3 ldr      r3, [pc, #0xb4]
080035d5 cmp      r2, #0
080035d7 bne      #0x80035db
080035d9 ldr      r3, [pc, #0xb0]
080035db ldr      r2, [sp, #0x20]
080035dd movs     r1, #0x20
080035df str      r2, [sp]
080035e1 add      r0, sp, #0x7c
080035e3 ldr      r2, [pc, #0xac]
080035e5 bl       #0x8003a1d
080035f3 movs     r6, #6
080035f5 ldr      r5, [pc, #0xa4]
080035f7 ldrb     r7, [r4, #1]
080035f9 cmp      r2, #0xe7
080035fb bls      #0x80035ff
080035fd b        #0x80034d3
080035ff movs     r3, r2
08003601 subs     r3, #0x22
08003603 cmp      r3, #0xc5
08003605 bls      #0x8003609
08003607 b        #0x80030b3
08003609 cmp      r2, #0x2a
0800360b bhs      #0x800360f
0800360d movs     r0, #0x2a
0800360f uxth     r0, r0
08003611 movs     r1, #0x26
08003613 subs     r0, #0x2a
08003615 bl       #0x8004671
08003619 ldr      r3, [sp, #0xc]
0800361b uxtb     r2, r0
0800361d strb     r2, [r4, #1]
0800361f cmp      r3, #0x9f
08003621 bls      #0x8003625
08003623 b        #0x800350b
08003625 movs     r3, #1
08003627 rsbs     r3, r3, #0
08003629 b        #0x80034df
0800362b ldr      r5, [pc, #0x74]
0800362d movs     r6, #5
0800362f adds     r5, #0x38
08003631 b        #0x80035f7
08003637 subs     r0, r4, #1
08003639 cmp      r0, #8
0800363b bhi      #0x80035d1
0800363d bl       #0x8004649
08003641 adr      r4, #0x3e4
08003643 lsrs     r5, r1, #0xc
08003645 lsls     r5, r2, #0x1f
08003647 lsls     r1, r1, #0x14
08003649 lsls     r7, r2, #3
0800364b ldr      r3, [pc, #0x5c]
0800364d b        #0x80035db
