08000899 push     {r4, r5, lr}
0800089b sub      sp, #0x1c
0800089d add      r4, sp, #4
0800089f movs     r2, r4
080008a1 ldr      r3, [pc, #0x4c]
080008a3 ldm      r3!, {r0, r1, r5}
080008a5 stm      r2!, {r0, r1, r5}
080008a7 ldm      r3!, {r0, r1}
080008a9 stm      r2!, {r0, r1}
080008ab ldr      r2, [pc, #0x48]
080008ad movs     r3, #0x38
080008af ldr      r1, [r2, #8]
080008b1 movs     r0, r1
080008b3 ands     r0, r3
080008b5 tst      r1, r3
080008b7 bne      #0x80008d7
080008b9 movs     r5, #7
080008bb ldr      r1, [r2]
080008bd ldr      r3, [r2, #4]
080008bf lsrs     r1, r1, #0xb
080008c1 lsrs     r3, r3, #0xd
080008c3 ands     r1, r5
080008c5 ands     r3, r5
080008c7 cmp      r3, #4
080008c9 bls      #0x80008cd
080008cb movs     r3, r0
080008cd lsls     r3, r3, #2
080008cf ldr      r0, [r4, r3]
080008d1 lsrs     r0, r1
080008d3 add      sp, #0x1c
080008d5 pop      {r4, r5, pc}
080008d7 ldr      r1, [r2, #8]
080008d9 ands     r1, r3
080008db cmp      r1, #8
080008dd beq      #0x80008ed
080008df ldr      r0, [r2, #8]
080008e1 ands     r0, r3
080008e3 subs     r0, #0x18
080008e5 rsbs     r3, r0, #0
080008e7 adcs     r0, r3
080008e9 lsls     r0, r0, #0xf
080008eb b        #0x80008d3
080008ed ldr      r0, [pc, #8]
080008ef b        #0x80008d3
