void sub_800210b(unsigned int a0, unsigned int a1, unsigned int a2, unsigned int a3)
{
    sub_800210f();
    return;
}
