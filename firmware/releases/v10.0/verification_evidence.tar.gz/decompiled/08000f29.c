extern unsigned short g_20000358;
extern unsigned short g_2000035a;
extern char g_2000035c;
extern char g_20000372;
extern char g_20000373;
extern char g_20000375;
extern char g_20000376;
extern char g_20000377;
extern unsigned int g_2000037c;

int sub_8000f29(unsigned short a0, unsigned int a1, unsigned int a2, unsigned short a3)
{
    unsigned int v0;  // [bp-0x1c]
    short v1;  // [bp+0x0]

    v0 = v1;
    sub_80007b9();
    g_2000037c = 0;
    g_2000035a = 0;
    g_20000358 = 0;
    sub_80002c1();
    g_2000035c = 1;
    g_20000377 = 1;
    g_20000375 = 0;
    g_20000372 = 0;
    g_20000373 = 0;
    g_20000376 = 0;
    sub_80002d9();
    return (unsigned int)sub_80005a1(a0, a1, a2, a3, v0, 0, 2);
}
