080036f3 push     {r4, lr}
080036f5 bl       #0x80003f5
080036f9 pop      {r4, pc}
