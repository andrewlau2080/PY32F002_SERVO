int sub_800477d(unsigned int a0, unsigned int a1)
{
    if (!a1)
        return (unsigned int)sub_8004771(a0);
    return sub_8004671(a0, a1);
}
