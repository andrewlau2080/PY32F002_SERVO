extern unsigned short g_2000000e;
extern unsigned short g_20000024;
extern unsigned short g_20000370;

int sub_800332d(unsigned int a0, unsigned int a1, unsigned int a2, unsigned int a3, unsigned int a4, unsigned int a5, unsigned int a6, unsigned int a7, unsigned int a8, unsigned short a9)
{
    g_2000000e = a9;
    g_20000024 = g_20000370;
}
