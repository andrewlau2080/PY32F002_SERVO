08000ab1 push     {r0, r1, r2, r4, r5, r6, r7, lr}
08000ab3 ldr      r4, [pc, #0x1c0]
08000ab5 movs     r3, #4
08000ab7 ldr      r5, [r4, #0x40]
08000ab9 ldr      r2, [r5, #8]
08000abb movs     r1, r2
08000abd ands     r1, r3
08000abf tst      r2, r3
08000ac1 beq      #0x8000ac5
08000ac3 b        #0x8000bab
08000ac5 movs     r2, r4
08000ac7 adds     r2, #0x6c
08000ac9 ldrb     r3, [r2]
08000acb cmp      r3, #1
08000acd bne      #0x8000ad1
08000acf b        #0x8000bab
08000ad1 movs     r3, #1
08000ad3 str      r1, [sp, #4]
08000ad5 strb     r3, [r2]
08000ad7 ldr      r2, [r5, #8]
08000ad9 tst      r2, r3
08000adb beq      #0x8000b95
08000add ldr      r3, [r4, #0x70]
08000adf ldr      r2, [pc, #0x198]
08000ae1 ands     r2, r3
08000ae3 movs     r3, #0x80
08000ae5 lsls     r3, r3, #1
08000ae7 orrs     r3, r2
08000ae9 movs     r2, r4
08000aeb str      r3, [r4, #0x70]
08000aed movs     r3, #0
08000aef adds     r2, #0x6c
08000af1 str      r3, [r4, #0x74]
08000af3 strb     r3, [r2]
08000af5 adds     r3, #0x1c
08000af7 str      r3, [r5]
08000af9 ldr      r2, [r5, #8]
08000afb subs     r3, #0x18
08000afd orrs     r3, r2
08000aff str      r3, [r5, #8]
08000b01 ldr      r3, [r4, #0x54]
08000b03 cmp      r3, #8
08000b05 bne      #0x8000bd1
08000b07 movs     r7, #0xfa
08000b09 ldr      r2, [pc, #0x170]
08000b0b lsls     r7, r7, #2
08000b0d ldr      r6, [r2, #0x20]
08000b0f movs     r0, r3
08000b11 ldr      r1, [r5]
08000b13 ands     r0, r1
08000b15 tst      r3, r1
08000b17 beq      #0x8000bd5
08000b19 movs     r3, #0x80
08000b1b ldr      r1, [r4, #0x70]
08000b1d lsls     r3, r3, #2
08000b1f orrs     r3, r1
08000b21 str      r3, [r4, #0x70]
08000b23 movs     r3, #0xc0
08000b25 ldr      r1, [r5, #0xc]
08000b27 lsls     r3, r3, #4
08000b29 tst      r1, r3
08000b2b bne      #0x8000b57
08000b2d movs     r3, r4
08000b2f adds     r3, #0x40
08000b31 ldrb     r3, [r3, #0x19]
08000b33 cmp      r3, #0
08000b35 bne      #0x8000b57
08000b37 ldr      r3, [r5]
08000b39 lsls     r3, r3, #0x1c
08000b3b bpl      #0x8000b57
08000b3d ldr      r3, [r5, #8]
08000b3f lsls     r3, r3, #0x1d
08000b41 bmi      #0x8000beb
08000b43 movs     r1, #0xc
08000b45 ldr      r3, [r5, #4]
08000b47 bics     r3, r1
08000b49 str      r3, [r5, #4]
08000b4b ldr      r3, [r4, #0x70]
08000b4d ldr      r1, [pc, #0x130]
08000b4f ands     r1, r3
08000b51 movs     r3, #1
08000b53 orrs     r3, r1
08000b55 str      r3, [r4, #0x70]
08000b57 movs     r3, r4
08000b59 adds     r3, #0x40
08000b5b ldrb     r3, [r3, #0x18]
08000b5d cmp      r3, #0
08000b5f bne      #0x8000b65
08000b61 adds     r3, #0xc
08000b63 str      r3, [r5]
08000b65 movs     r1, r4
08000b67 movs     r3, #1
08000b69 adds     r1, #0x6c
08000b6b strb     r3, [r1]
08000b6d movs     r1, #4
08000b6f ldr      r0, [r5, #0x40]
08000b71 ldr      r6, [r5, #8]
08000b73 uxth     r0, r0
08000b75 tst      r6, r1
08000b77 bne      #0x8000bfd
08000b79 movs     r1, #1
08000b7b ldr      r3, [r5, #8]
08000b7d tst      r3, r1
08000b7f bne      #0x8000c35
08000b81 ldr      r3, [r4, #0x70]
08000b83 ldr      r2, [pc, #0xfc]
08000b85 ands     r2, r3
08000b87 movs     r3, #1
08000b89 orrs     r3, r2
08000b8b str      r3, [r4, #0x70]
08000b8d movs     r3, #0
08000b8f adds     r4, #0x6c
08000b91 strb     r3, [r4]
08000b93 pop      {r1, r2, r3, r4, r5, r6, r7, pc}
08000b95 ldr      r1, [r5, #8]
08000b97 ldr      r2, [pc, #0xec]
08000b99 tst      r1, r2
08000b9b beq      #0x8000baf
08000b9d movs     r2, #0x10
08000b9f ldr      r1, [r4, #0x70]
08000ba1 orrs     r2, r1
08000ba3 str      r2, [r4, #0x70]
08000ba5 ldr      r2, [r4, #0x74]
08000ba7 orrs     r3, r2
08000ba9 str      r3, [r4, #0x74]
08000bab bl       #0x8000a9d
08000baf ldr      r2, [r5, #8]
08000bb1 ldr      r1, [pc, #0xd4]
08000bb3 orrs     r3, r2
08000bb5 str      r3, [r5, #8]
08000bb7 ldr      r3, [pc, #0xd4]
08000bb9 ldr      r0, [r3, #0x38]
08000bbb bl       #0x8004671
08000bbf str      r0, [sp, #4]
08000bc1 ldr      r3, [sp, #4]
08000bc3 cmp      r3, #0
08000bc5 bne      #0x8000bc9
08000bc7 b        #0x8000add
08000bc9 ldr      r3, [sp, #4]
08000bcb subs     r3, #1
08000bcd str      r3, [sp, #4]
08000bcf b        #0x8000bc1
08000bd1 movs     r3, #0xc
08000bd3 b        #0x8000b07
08000bd5 ldr      r1, [r2, #0x20]
08000bd7 subs     r1, r1, r6
08000bd9 cmp      r1, r7
08000bdb bls      #0x8000b0f
08000bdd movs     r3, #4
08000bdf ldr      r2, [r4, #0x70]
08000be1 adds     r4, #0x6c
08000be3 orrs     r3, r2
08000be5 str      r3, [r4, #4]
08000be7 strb     r0, [r4]
08000be9 b        #0x8000bab
08000beb movs     r3, #0x20
08000bed ldr      r1, [r4, #0x70]
08000bef orrs     r3, r1
08000bf1 str      r3, [r4, #0x70]
08000bf3 movs     r3, #1
08000bf5 ldr      r1, [r4, #0x74]
08000bf7 orrs     r3, r1
08000bf9 str      r3, [r4, #0x74]
08000bfb b        #0x8000b57
08000bfd ldr      r6, [r5, #8]
08000bff tst      r6, r1
08000c01 beq      #0x8000c11
08000c03 ldr      r1, [r5, #8]
08000c05 tst      r1, r3
08000c07 beq      #0x8000c11
08000c09 movs     r3, #0x10
08000c0b ldr      r1, [r5, #8]
08000c0d orrs     r3, r1
08000c0f str      r3, [r5, #8]
08000c11 movs     r1, #4
08000c13 ldr      r6, [r2, #0x20]
08000c15 ldr      r3, [r5, #8]
08000c17 tst      r3, r1
08000c19 beq      #0x8000b79
08000c1b ldr      r3, [r2, #0x20]
08000c1d subs     r3, r3, r6
08000c1f cmp      r3, #2
08000c21 bls      #0x8000c15
08000c23 movs     r3, #0x10
08000c25 ldr      r2, [r4, #0x70]
08000c27 orrs     r3, r2
08000c29 str      r3, [r4, #0x70]
08000c2b movs     r3, #1
08000c2d ldr      r2, [r4, #0x74]
08000c2f orrs     r3, r2
08000c31 str      r3, [r4, #0x74]
08000c33 b        #0x8000b8d
08000c35 movs     r3, #5
08000c37 ldr      r6, [r5, #8]
08000c39 ands     r3, r6
08000c3b cmp      r3, #1
08000c3d bne      #0x8000c65
08000c3f ldr      r1, [r5, #8]
08000c41 bics     r1, r3
08000c43 str      r1, [r5, #8]
08000c45 movs     r1, #2
08000c47 str      r1, [r5]
08000c49 ldr      r6, [r2, #0x20]
08000c4b ldr      r1, [r5, #8]
08000c4d tst      r1, r3
08000c4f beq      #0x8000b81
08000c51 ldr      r1, [r2, #0x20]
08000c53 subs     r1, r1, r6
08000c55 cmp      r1, #2
08000c57 bls      #0x8000c4b
08000c59 movs     r2, #0x10
08000c5b ldr      r1, [r4, #0x70]
08000c5d orrs     r2, r1
08000c5f str      r2, [r4, #0x70]
08000c61 ldr      r2, [r4, #0x74]
08000c63 b        #0x8000c2f
08000c65 movs     r3, #0x10
08000c67 ldr      r2, [r4, #0x70]
08000c69 orrs     r3, r2
08000c6b str      r3, [r4, #0x70]
08000c6d ldr      r3, [r4, #0x74]
08000c6f orrs     r1, r3
08000c71 str      r1, [r4, #0x74]
08000c73 b        #0x8000b8d
