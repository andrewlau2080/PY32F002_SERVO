typedef struct st_800053d_0 {
    unsigned short field_0;
    unsigned short field_2;
    unsigned short field_4;
    char field_6;
    char padding_7[1];
    unsigned int field_8;
    unsigned int field_c;
    unsigned int field_10;
    unsigned int field_14;
    char field_18;
    char field_19;
} st_800053d_0;

extern unsigned short g_20000034;
extern char g_20000036;
extern unsigned short g_20000330;
extern unsigned short g_20000332;
extern unsigned int g_20000334;
extern char g_20000338;
extern char g_20000339;
extern unsigned int g_2000033c;
extern char g_2000035c;
extern unsigned int g_2000037c;
extern unsigned int g_2000039c;
extern unsigned short g_200003a0;
extern unsigned int g_200003a4;
extern unsigned int g_200003a8;
extern unsigned int g_200003ac;
extern unsigned int g_200003b0;
extern unsigned short g_200003b4;
extern unsigned short g_200003b6;
extern unsigned short g_200003b8;
extern unsigned short g_200003ba;
extern unsigned short g_200003bc;
extern unsigned short g_200003be;
extern unsigned short g_200003c0;
extern unsigned short g_200003c2;
extern unsigned short g_200003c4;
extern unsigned short g_200003ce;
extern char g_200003d0;
extern char g_200003d1;
extern char g_200003d2;
extern unsigned int g_200003d4;
extern unsigned int g_2000046c;

void sub_80005a1(unsigned short a0, unsigned int a1, unsigned int a2, unsigned short a3, unsigned short a4, short a5, char a6)
{
    unsigned int v10;  // r4
    unsigned int v11;  // r3
    unsigned int v20;  // r1
    unsigned int idx;  // r3
    unsigned int v22;  // r3
    unsigned int v12;  // r5
    unsigned int v13;  // r3
    unsigned int v14;  // r3
    unsigned int v15;  // r1
    unsigned int v16;  // r2
    unsigned short v17;  // r0
    unsigned short v18;  // r0
    unsigned int v19;  // r1
    unsigned int v0;  // [bp-0x64]
    unsigned int v1;  // [bp-0x58]
    unsigned int v2;  // [bp-0x54]
    unsigned int v3;  // [bp-0x50]
    unsigned int v4;  // [bp-0x4c]
    st_800053d_0 v5;  // [bp-0x34]
    unsigned short v6;  // [bp-0x32]
    unsigned short v7;  // [bp-0x30]
    char v8;  // [bp-0x2e]
    unsigned int v9;  // [bp-0x2c]

    v10 = a5;
    v4 = g_2000039c + 1;
    v1 = g_2000039c + 2;
    sub_800053d(&v5, a1);
    if ((int)g_2000037c < 0x8000)
    {
        v0 = 0xffff8000;
        if ((int)g_2000037c < -0x8000)
            goto LABEL_80005ed;
        v11 = (short)g_2000037c;
    }
    else
    {
        v11 = 0x7fff;
    }
    v0 = v11;
LABEL_80005ed:
    v3 = 1;
    if (0 >= (int)v10)
        v3 = -(v10 - (v10 - 1) - (1 > v10));
    v12 = 1;
    v13 = g_200003a0;
    if (0 >= (int)v13)
        v12 = -(v13 - (v13 - 1) - (1 > v13));
    v2 = g_2000033c;
    if (g_200003a4 != v2 || g_20000339)
    {
        g_200003a8 = 0;
        g_20000034 = 0xffff;
        g_200003a0 = 0;
        g_20000036 = 0xff;
        g_200003a4 = v2;
        v14 = 0;
        if (!g_20000338)
            goto LABEL_800065b;
    }
    else
    {
        v14 = g_20000338;
        if (!g_20000338)
            goto LABEL_8000661;
    }
    v14 = 1;
    if ((int)(*(int *)0x20000340 - g_20000334) > 0)
    {
        v14 = 0;
        g_20000338 = 0;
    }
LABEL_800065b:
    v15 = 1;
    if (g_20000339)
        goto LABEL_80006c7;
LABEL_8000661:
    v15 = 1;
    if (19 >= *(int *)0x20000340 - g_200003a8 && g_20000034 == a2 && v3 == v12)
    {
        v16 = g_200003a0;
        v17 = v16;
        v15 = 1;
        if (((int)v16 < 0 ? (unsigned short)(160 - v17) : v17 + 160) > (int)((v10 + ((int)(v10) >> 31) ^ (int)(v10) >> 31) & 0xffff))
        {
            v18 = v10;
            v15 = 1;
            if (((int)v10 < 0 ? (unsigned short)(160 - v18) : v18 + 160) > (int)((v16 + ((int)(v16) >> 31) ^ (int)(v16) >> 31) & 0xffff))
            {
                v19 = g_20000036 - a6;
                v15 = v19 - (v19 - 1) - (1 > v19);
            }
        }
    }
LABEL_80006c7:
    g_200003ac = v4;
    g_200003d4 = v4;
    g_200003b0 = *(int *)0x20000340;
    g_200003b4 = a0;
    g_200003b6 = v6;
    g_200003b8 = v9;
    g_200003ce = v7;
    g_200003d2 = v8;
    g_200003ba = a1;
    g_200003bc = a2;
    g_200003be = a3;
    g_200003c0 = a4;
    g_200003c2 = v10;
    g_200003c4 = v0;
    g_200003d0 = g_2000035c;
    g_200003d1 = a6;
    g_200003d4 = v1;
    g_200003ac = v1;
    g_2000039c = v1;
    if (!v14)
    {
        return;
    }
    else if (v15)
    {
        v20 = 20 * g_20000330;
        *(int *)(v20 + (char *)&g_2000046c) = *(int *)0x20000340;
        idx = (char *)&g_2000046c + v20;
        *(unsigned short *)(idx + 4) = a0;
        *(unsigned short *)(idx + 6) = a2;
        *(unsigned short *)(idx + 8) = a3;
        *(unsigned short *)(idx + 10) = a4;
        *(unsigned short *)(idx + 12) = v10;
        *(unsigned short *)(idx + 14) = v0;
        *(char *)(idx + 16) = g_2000035c;
        *(char *)(idx + 0x11) = a6;
        v22 = g_20000330 + 1;
        if (v22 > 0x22)
            v22 = 0;
        g_20000330 = v22;
        if (0x22 >= g_20000332)
            g_20000332 = g_20000332 + 1;
        g_200003a8 = *(int *)0x20000340;
        g_200003a0 = v10;
        g_20000034 = a2;
        g_20000036 = a6;
        g_20000339 = 0;
        return;
    }
    else
    {
        return;
    }
}
