char * sub_8003aa1(char *a0, char *a1)
{
    char *iter;  // r3
    unsigned int i;  // r2

    iter = a0;
    do
    {
        i = *a1;
        a1 += 1;
        *iter = i;
        iter += 1;
    } while (i);
    return a0;
}
