int sub_800059d(unsigned int a0, unsigned int a1, unsigned int a2, unsigned int a3, unsigned int a4, unsigned short a5, char a6)
{
    return sub_80005a1(0);
}
