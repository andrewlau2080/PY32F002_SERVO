int sub_800349d(void)
{
}
