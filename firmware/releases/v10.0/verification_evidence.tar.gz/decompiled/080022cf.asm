080022cf movs     r3, #2
080022d1 movs     r0, #0xaf
080022d3 str      r5, [sp, #0xc]
080022d5 str      r3, [sp, #8]
080022d7 str      r6, [sp]
080022d9 movs     r2, #0x7c
080022db movs     r1, #3
080022dd str      r4, [sp, #4]
080022df adds     r3, #0x18
080022e1 lsls     r0, r0, #1
080022e3 bl       #0x800224d
