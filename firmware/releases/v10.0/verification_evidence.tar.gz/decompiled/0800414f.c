typedef struct st_800414f_0 {
    unsigned int field_0;
    int field_4;
    int field_8;
    char padding_c[4];
    int field_10;
    char padding_14[46];
    char field_42;
    char field_43;
} st_800414f_0;

int sub_800414f(unsigned int a0, unsigned int a1, void* *a2, unsigned int a3, unsigned int a4, unsigned int a5, unsigned int a6, char *a7)
{
    st_800414f_0 *v0;  // r4
    unsigned int v1;  // r3
    unsigned int v10;  // r0
    void* v2;  // r1
    unsigned int v3;  // r6
    unsigned int v4;  // r2
    void* v5;  // r1
    int v6;  // r3
    char *iter;  // r5
    int v8;  // r2
    unsigned int i;  // r6

    v1 = v0->field_0;
    if ((int)(v1 * 0x1000000) < 0 || (int)(v1 * 0x2000000) >= 0)
    {
        v5 = *a2;
        *a2 = v5 + 4;
        v4 = *(int *)v5;
        v3 = v4;
    }
    else
    {
        v2 = *a2;
        *a2 = v2 + 4;
        v3 = *(short *)v2;
        v4 = v3;
    }
    if ((int)v4 >= 0)
    {
        v6 = v0->field_4;
        v0->field_8 = v6;
        if (v6 >= 0)
        {
            v0->field_0 = v0->field_0 & ~4;
            if (!v3)
            {
                if (v6)
                    goto LABEL_80042ad;
                iter = a7;
                goto LABEL_8004229;
            }
            goto LABEL_8004273;
        }
        else
        {
            if (v3)
                goto LABEL_8004273;
LABEL_80042ad:
            iter = &v0->field_42;
            v0->field_42 = 48;
LABEL_8004229:
        }
    }
    else
    {
        v0->field_43 = 45;
        v8 = v0->field_4;
        v3 = -v3;
        v0->field_8 = v8;
        if (v8 >= 0)
            v0->field_0 = v1 & ~4;
LABEL_8004273:
        iter = a7;
        do
        {
            i = v3;
            v10 = sub_800477d(i, 10);
            iter -= 1;
            *iter = 65;
            v3 = v10;
        } while (10 <= i);
    }
    v0->field_10 = a7 - iter;
}
