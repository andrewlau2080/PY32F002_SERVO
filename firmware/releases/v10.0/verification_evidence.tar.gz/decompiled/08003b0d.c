typedef struct st_8003b0d_0 {
    unsigned int field_0;
    char padding_4[4];
    int field_8;
    unsigned short field_c;
    char padding_e[2];
    unsigned int field_10;
    int field_14;
} st_8003b0d_0;

unsigned int sub_8003b0d(unsigned int *a0, st_8003b0d_0 *a1, int a2, int a3)
{
    unsigned int v6;  // r5
    unsigned int v7;  // r6
    unsigned int v16;  // r9
    int v17;  // r2
    int v18;  // r0
    int v19;  // r2
    unsigned int v21;  // r7
    int v22;  // r3
    unsigned int v23;  // r3
    unsigned int v8;  // r7
    unsigned int v9;  // r8
    unsigned int v10;  // r9
    unsigned int v11;  // r10
    int v12;  // r7
    int v13;  // r5
    unsigned int v14;  // r3
    unsigned int v15;  // r0
    unsigned int v0;  // [bp-0x20]
    unsigned int v1;  // [bp-0x1c]
    unsigned int v2;  // [bp-0x18]
    unsigned int v3;  // [bp-0x10]
    unsigned int v4;  // [bp-0xc]
    unsigned int v5;  // [bp-0x8]

    v3 = v6;
    v4 = v7;
    v5 = v8;
    v0 = v9;
    v1 = v10;
    v2 = v11;
    v12 = a1->field_8;
    v13 = a3;
    if ((unsigned int)a3 >= (unsigned int)v12)
    {
        v14 = a1->field_c;
        if (!(v14 & 1152))
        {
            v13 = v12;
            v15 = a1->field_0;
        }
        else
        {
            v16 = a1->field_0 - a1->field_10;
            v17 = a1->field_14 * 3 / 2;
            v18 = v13 + 1 + v16;
            v19 = v17;
            if ((unsigned int)v18 > (unsigned int)v19)
            {
                v17 = v18;
                v19 = v18;
            }
            if ((int)(v14 * 0x200000) < 0)
            {
                v21 = sub_80044d9(a0, v19);
                if (!v21)
                {
                    *a0 = 12;
                    a1->field_c = a1->field_c | 64;
                    return 0xfffffffe;
                }
                sub_8003855(v21, a1->field_10, v16);
                a1->field_c = a1->field_c & 0xfffffb7f | 128;
            }
            else
            {
                v21 = sub_800459d(a0);
                if (!v21)
                {
                    sub_8004419(a0, a1->field_10);
                    *a0 = 12;
                    a1->field_c = a1->field_c | 64;
                    return 0xfffffffe;
                }
            }
            v22 = v17;
            v15 = v21 + v16;
            a1->field_14 = v22;
            a1->field_10 = v21;
            a1->field_0 = v15;
            v12 = v13;
            a1->field_8 = v22 - v16;
        }
    }
    else
    {
        v12 = a3;
        v15 = a1->field_0;
    }
    sub_800436d(v15, a2, v13);
    v23 = a1->field_0;
    a1->field_8 = a1->field_8 - v12;
    a1->field_0 = v13 + v23;
    return 0;
}
