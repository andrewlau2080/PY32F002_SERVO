08000a9d push     {r4, lr}
08000a9f bl       #0x80007b9
08000aa3 bl       #0x8000a5d
08000aa7 movs     r3, #0xa0
08000aa9 movs     r2, #0x20
08000aab lsls     r3, r3, #0x17
08000aad str      r2, [r3, #0x28]
08000aaf b        #0x8000aaf
