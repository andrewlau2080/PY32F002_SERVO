typedef struct st_8000d69_1 {
    unsigned int field_0;
    unsigned int field_4;
} st_8000d69_1;

extern char g_2000040c;
extern unsigned int g_20000410;
extern unsigned int g_40012708;

unsigned int sub_8000d69(st_8000d69_1 *a0)
{
    unsigned int v2;  // r0
    unsigned int v3;  // r7
    unsigned int v4;  // r0
    unsigned int v5;  // r2
    unsigned int v6;  // r1
    unsigned int v8;  // r3
    unsigned int v0;  // [bp-0x24]
    unsigned int v1;  // [bp-0x1c]

    v1 = 0;
    if (g_2000040c == 1)
        return 2;
    v2 = 1;
    g_2000040c = 1;
    v0 = *(int *)(*(int *)0x200003e0 + 8) & 4;
    if (!(*(int *)(*(int *)0x200003e0 + 8) & 4))
    {
        v3 = a0->field_0;
        v4 = 1 << ((char)v3 & 31) & (int)((v3 & 0xff) - 32) >> 31;
        v5 = v3 - 11;
        if (a0->field_4 != 4097)
        {
            *(unsigned int *)(*(int *)0x200003e0 + 40) = v4 | *(int *)(*(int *)0x200003e0 + 40);
            if (*(int *)0x20000408 != 0x10000000 && (unsigned int)(*(int *)0x20000408 - 1) > 6)
            {
                v6 = a0[1].field_0;
                if (a0[1].field_0 != (*(int *)(*(int *)0x200003e0 + 20) & 7))
                {
                    *(unsigned int *)(*(int *)0x200003e0 + 20) = *(int *)(*(int *)0x200003e0 + 20) & ~7;
                    *(unsigned int *)(*(int *)0x200003e0 + 20) = v6 & 7 | *(int *)(*(int *)0x200003e0 + 20);
                }
            }
            if (v5 > 1)
            {
                v2 = 0;
            }
            else
            {
                g_40012708 = g_40012708 | (v3 == 11 ? 0x800000 : 0x400000);
                if (v3 != 11)
                {
                    v2 = 0;
                }
                else
                {
                    v8 = 10 * sub_8004671(*0x20000038, 1000000);
                    while (1)
                    {
                        v1 = v8;
                        if (!v1)
                            break;
                        v8 = v1 - 1;
                    }
                    v2 = 0;
                }
            }
        }
        else
        {
            *(unsigned int *)(*(int *)0x200003e0 + 40) = *(int *)(*(int *)0x200003e0 + 40) & ~v4;
            if (1 < v5)
            {
                v2 = 0;
            }
            else
            {
                g_40012708 = (-(v5 + -v5 + (v5 <= 0)) >> 22) * 0x400000 + 0xffbfffff & g_40012708;
                v2 = 0;
            }
        }
    }
    else
    {
        g_20000410 = 32 | g_20000410;
    }
    g_2000040c = 0;
    return v2;
}
