typedef struct st_800240d_0 {
    char padding_0[4];
    struct st_800240d_1 *field_4;
} st_800240d_0;

typedef struct st_800240d_1 {
    char field_0;
} st_800240d_1;

void sub_800240d(unsigned int a0, st_800240d_0 *a1, unsigned int a2)
{
    unsigned int v6;  // r4
    unsigned int v7;  // r5
    unsigned int v8;  // r6
    unsigned int v9;  // lr
    char *v10;  // r2
    char *v0;  // [bp-0x40]
    char v1;  // [bp-0x34]
    unsigned int v2;  // [bp-0x10]
    unsigned int v3;  // [bp-0xc]
    unsigned int v4;  // [bp-0x8]
    unsigned int v5;  // [bp-0x4]

    v2 = v6;
    v3 = v7;
    v4 = v8;
    v5 = v9;
    v10 = a1->field_4;
    if (v10 && *v10)
    {
        v0 = v10;
        sub_8003a1d(&v1, 36, "%ld %s"); /* do not return */
    }
    sub_8003a1d(&v1, 36, "%ld"); /* do not return */
}
