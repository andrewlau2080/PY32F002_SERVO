typedef struct st_8004197_0 {
    unsigned int field_0;
} st_8004197_0;

typedef struct st_8004197_1 {
    char padding_0[16];
    unsigned int field_10;
    char padding_14[46];
    char field_42;
} st_8004197_1;

int sub_8004197(unsigned int a0, unsigned int a1, st_8004197_0 **a2)
{
    unsigned int *v0;  // r3
    st_8004197_1 *v1;  // r4

    v0 = *a2;
    *a2 = v0 + 1;
    v1->field_42 = *v0;
    v1->field_10 = 1;
}
