080036d9 movs     r2, #8
080036db ldr      r3, [pc, #0x10]
080036dd push     {r4, lr}
080036df ldr      r1, [r3, #0xc]
080036e1 tst      r1, r2
080036e3 beq      #0x80036eb
080036e5 str      r2, [r3, #0xc]
080036e7 bl       #0x80003f5
080036eb pop      {r4, pc}
