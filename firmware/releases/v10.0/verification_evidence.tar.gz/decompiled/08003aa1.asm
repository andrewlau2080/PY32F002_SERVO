08003aa1 movs     r3, r0
08003aa3 ldrb     r2, [r1]
08003aa5 adds     r1, #1
08003aa7 strb     r2, [r3]
08003aa9 adds     r3, #1
08003aab cmp      r2, #0
08003aad bne      #0x8003aa3
08003aaf bx       lr
