080023a9 push     {r0, r1, r2, r3, r4, r5, r6, lr}
080023ab movs     r6, r1
080023ad movs     r5, r2
080023af str      r2, [sp]
080023b1 movs     r3, #0x20
080023b3 movs     r2, #0xa0
080023b5 movs     r1, #0xf0
080023b7 movs     r4, r0
080023b9 bl       #0x8002221
