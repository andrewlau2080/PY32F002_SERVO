int sub_800261d(void)
{
}
