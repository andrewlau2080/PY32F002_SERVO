void sub_8002345(unsigned int a0, unsigned int a1, unsigned int a2, unsigned int a3, unsigned int a4, unsigned int a5, unsigned int a6, unsigned int a7, int a8, unsigned short a9)
{
    int v0;  // r7
    unsigned short v1;  // r4
    char v2;  // r6

    sub_800224d(286, v0, 152, 36, a9, v1, v2, a8); /* do not return */
}
