extern unsigned int g_20000424;

int sub_80012b7(unsigned int a0, unsigned int a1, unsigned int a2, unsigned int a3, unsigned int a4, unsigned int a5, unsigned int a6, unsigned int a7, unsigned int a8, unsigned int a9, unsigned int a10, unsigned int a11, unsigned int a12, unsigned int a13, unsigned int a14, unsigned int a15, unsigned int a16, unsigned int a17, unsigned int a18, unsigned int a19, unsigned int a20, unsigned int a21, unsigned int a22, unsigned int a23, unsigned int a24, unsigned int a25, unsigned int a26, unsigned int a27, unsigned int a28, unsigned int a29, unsigned int a30, unsigned int a31, unsigned int a32, unsigned int a33, unsigned int a34, char a35)
{
    g_20000424 = g_20000424 + 1;
    a35 -= 1;
    if (a35)
        sub_8001d4d();
    g_20000424 = *(int *)0x20000340;
}
