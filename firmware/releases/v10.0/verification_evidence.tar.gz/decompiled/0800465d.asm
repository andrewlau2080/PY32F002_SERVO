0800465d push     {r0, r1}
0800465f mov      r1, lr
08004661 lsrs     r1, r1, #1
08004663 lsls     r0, r0, #1
08004665 lsls     r1, r1, #1
08004667 ldrsh    r1, [r1, r0]
08004669 lsls     r1, r1, #1
0800466b add      lr, r1
0800466d pop      {r0, r1}
0800466f bx       lr
