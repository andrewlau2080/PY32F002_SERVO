void sub_8004dd1(void)
{
}
