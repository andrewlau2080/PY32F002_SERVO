08002d59 movs     r0, #0xe1
08002d5b lsls     r0, r0, #0xa
08002d5d bl       #0x8002725
