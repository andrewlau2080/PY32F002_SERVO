080010cf ldr      r2, [pc, #0x310]
080010d1 ldr      r2, [r2, #4]
080010d3 cmp      r2, r3
080010d5 bne      #0x80010d9
080010d7 b        #0x80012d7
080010d9 add      r4, sp, #0x8c
080010db movs     r0, r4
080010dd bl       #0x800053d
080010e1 movs     r3, #0xa0
080010e3 movs     r2, #1
080010e5 lsls     r3, r3, #0x17
080010e7 str      r2, [r3, #0x18]
080010e9 ldr      r3, [pc, #0x2ec]
080010eb adds     r3, #0x7b
080010ed ldrb     r3, [r3]
080010ef cmp      r3, #0
080010f1 beq      #0x80010f9
080010f3 movs     r0, r4
080010f5 bl       #0x80001d1
080010f9 movs     r2, #0
080010fb ldrb     r3, [r4, #0x19]
080010fd str      r2, [sp, #0x30]
080010ff cmp      r3, r2
08001101 beq      #0x8001117
08001103 movs     r1, #0
08001105 ldr      r3, [pc, #0x2d4]
08001107 ldr      r2, [r4, #0xc]
08001109 ldr      r3, [r3, #0x20]
0800110b subs     r3, r3, r2
0800110d ldr      r2, [pc, #0x2d4]
0800110f ldrh     r2, [r2, #0x36]
08001111 cmp      r2, r3
08001113 adcs     r1, r1
08001115 str      r1, [sp, #0x30]
08001117 ldr      r3, [pc, #0x2d0]
08001119 ldr      r5, [r3, #0x38]
0800111b ldr      r3, [pc, #0x2d0]
0800111d uxth     r5, r5
0800111f ldr      r2, [r3, #0x48]
08001121 ldr      r1, [r3, #0x4c]
08001123 str      r2, [sp, #0x4c]
08001125 cmp      r2, r1
08001127 blt      #0x800112f
08001129 ldr      r1, [r3, #0x50]
0800112b cmp      r2, r1
0800112d ble      #0x8001135
0800112f movs     r2, #0xd0
08001131 lsls     r2, r2, #1
08001133 str      r2, [sp, #0x4c]
08001135 movs     r2, r3
08001137 adds     r2, #0x90
08001139 ldr      r2, [r2]
0800113b str      r2, [sp, #0x48]
0800113d movs     r2, r3
0800113f adds     r2, #0x94
08001141 ldr      r2, [r2]
08001143 ldr      r1, [sp, #0x48]
08001145 cmp      r1, r2
08001147 blt      #0x8001153
08001149 movs     r2, r3
0800114b adds     r2, #0x98
0800114d ldr      r2, [r2]
0800114f cmp      r1, r2
08001151 ble      #0x8001157
08001153 movs     r2, #3
08001155 str      r2, [sp, #0x48]
08001157 ldr      r3, [r3, #0x78]
08001159 str      r3, [sp, #0x38]
0800115b movs     r3, #0x80
0800115d ldr      r2, [sp, #0x38]
0800115f lsls     r3, r3, #9
08001161 cmp      r2, r3
08001163 blo      #0x8001169
08001165 movs     r2, #0x78
08001167 str      r2, [sp, #0x38]
08001169 ldr      r2, [pc, #0x284]
0800116b ldr      r1, [r2, #0x58]
0800116d str      r1, [sp, #0x50]
0800116f cmp      r1, r3
08001171 blo      #0x8001177
08001173 movs     r1, #3
08001175 str      r1, [sp, #0x50]
08001177 ldr      r2, [r2, #0x40]
08001179 str      r2, [sp, #0x44]
0800117b cmp      r2, r3
0800117d blo      #0x8001183
0800117f movs     r3, #0xa0
08001181 str      r3, [sp, #0x44]
08001183 ldr      r3, [pc, #0x26c]
08001185 ldr      r2, [r3, #0x70]
08001187 str      r2, [sp, #0x54]
08001189 movs     r2, #0x80
0800118b ldr      r1, [sp, #0x54]
0800118d lsls     r2, r2, #9
0800118f cmp      r1, r2
08001191 blo      #0x8001199
08001193 movs     r1, #0x9b
08001195 lsls     r1, r1, #2
08001197 str      r1, [sp, #0x54]
08001199 adds     r3, #0x88
0800119b ldr      r3, [r3]
0800119d str      r3, [sp, #0x3c]
0800119f cmp      r3, r2
080011a1 blo      #0x80011a7
080011a3 movs     r3, #0x20
080011a5 str      r3, [sp, #0x3c]
080011a7 ldr      r3, [pc, #0x248]
080011a9 adds     r3, #0xa0
080011ab ldr      r3, [r3]
080011ad str      r3, [sp, #0x70]
080011af movs     r3, #0x80
080011b1 ldr      r2, [sp, #0x70]
080011b3 lsls     r3, r3, #9
080011b5 cmp      r2, r3
080011b7 blo      #0x80011bd
080011b9 movs     r2, #0x44
080011bb str      r2, [sp, #0x70]
080011bd ldr      r2, [pc, #0x234]
080011bf ldr      r1, [r2, #0x38]
080011c1 str      r1, [sp, #0x64]
080011c3 cmp      r1, r3
080011c5 blo      #0x80011cb
080011c7 movs     r1, #0x10
080011c9 str      r1, [sp, #0x64]
080011cb ldr      r2, [r2, #0x50]
080011cd str      r2, [sp, #0x40]
080011cf cmp      r2, r3
080011d1 blo      #0x80011d7
080011d3 movs     r3, #0x1c
080011d5 str      r3, [sp, #0x40]
080011d7 ldr      r3, [pc, #0x21c]
080011d9 ldr      r2, [r3, #0x68]
080011db str      r2, [sp, #0x74]
080011dd movs     r2, #0x80
080011df ldr      r1, [sp, #0x74]
080011e1 lsls     r2, r2, #9
080011e3 cmp      r1, r2
080011e5 blo      #0x80011eb
080011e7 movs     r1, #0x10
080011e9 str      r1, [sp, #0x74]
080011eb adds     r3, #0x98
080011ed ldr      r3, [r3]
080011ef str      r3, [sp, #0x78]
080011f1 cmp      r3, r2
080011f3 blo      #0x80011f9
080011f5 ldr      r3, [pc, #0x200]
080011f7 str      r3, [sp, #0x78]
080011f9 ldr      r3, [pc, #0x1f8]
080011fb adds     r3, #4
080011fd ldr      r3, [r3, #0x7c]
080011ff str      r3, [sp, #0x58]
08001201 movs     r3, #0x80
08001203 ldr      r2, [sp, #0x58]
08001205 lsls     r3, r3, #9
08001207 cmp      r2, r3
08001209 blo      #0x800120f
0800120b movs     r3, #0xe0
0800120d str      r3, [sp, #0x58]
0800120f ldr      r4, [pc, #0x1cc]
08001211 ldr      r3, [r4, #0x20]
08001213 str      r3, [sp, #0x6c]
08001215 bl       #0x8000ea5
08001219 ldr      r3, [pc, #0x1bc]
0800121b str      r0, [sp, #0x28]
0800121d adds     r3, #0x7c
0800121f ldrh     r3, [r3]
08001221 cmp      r3, r5
08001223 beq      #0x800124b
08001225 cpsid    i
08001227 ldr      r3, [pc, #0x1d4]
08001229 adds     r1, r5, #0
0800122b cmp      r5, r3
0800122d bls      #0x80012db
0800122f adds     r1, r3, #0
08001231 uxth     r1, r1
08001233 ldr      r0, [pc, #0x1cc]
08001235 bl       #0x8004671
08001239 movs     r2, #0
0800123b ldr      r3, [pc, #0x1c8]
0800123d uxth     r0, r0
0800123f strh     r0, [r3, #0x28]
08001241 ldr      r3, [pc, #0x194]
08001243 strh     r2, [r3, #0x3c]
08001245 cpsie    i
08001247 adds     r3, #0x7c
08001249 strh     r5, [r3]
0800124b ldr      r3, [sp, #0x28]
0800124d ldr      r2, [pc, #0x1b8]
0800124f subs     r3, #0x1f
08001251 uxth     r3, r3
08001253 movs     r6, #0
08001255 ldr      r5, [pc, #0x184]
08001257 cmp      r3, r2
08001259 bls      #0x80012e5
0800125b bl       #0x80007b9
0800125f strh     r6, [r4, #0x38]
08001261 bl       #0x80002c1
08001265 adds     r3, r4, #4
08001267 strh     r6, [r3, #0x3e]
08001269 movs     r3, r4
0800126b adds     r3, #0x44
0800126d strb     r6, [r3]
0800126f movs     r3, r4
08001271 adds     r3, #0x4d
08001273 strb     r6, [r3]
08001275 movs     r3, #1
08001277 adds     r2, r4, #2
08001279 rsbs     r3, r3, #0
0800127b strh     r3, [r4, #0x3e]
0800127d strh     r3, [r2, #0x3e]
0800127f movs     r3, r4
08001281 adds     r3, #0x55
08001283 strb     r6, [r3]
08001285 movs     r3, r4
08001287 adds     r3, #0x56
08001289 strb     r6, [r3]
0800128b movs     r3, r4
0800128d adds     r3, #0x57
0800128f strb     r6, [r3]
08001291 movs     r3, r4
08001293 strh     r6, [r4, #0x3a]
08001295 adds     r3, #0x60
08001297 adds     r4, #0x54
08001299 strb     r6, [r3]
0800129b bl       #0x80002d9
0800129f ldrb     r3, [r4]
080012a1 cmp      r3, #5
080012a3 bhi      #0x80012b1
080012a5 adds     r3, #1
080012a7 uxtb     r3, r3
080012a9 movs     r2, #1
080012ab strb     r3, [r4]
080012ad cmp      r3, #6
080012af bne      #0x80012b3
080012b1 movs     r2, #8
080012b3 adds     r5, #0x3c
080012b5 strb     r2, [r5]
080012db uxth     r3, r5
080012dd cmp      r3, #0x64
080012df bhs      #0x8001231
080012e1 movs     r1, #0x64
080012e3 b        #0x8001231
080012e5 movs     r3, r5
080012e7 adds     r3, #0x54
080012e9 strb     r6, [r3]
080012eb ldr      r3, [sp, #0x28]
080012ed lsls     r4, r3, #4
080012ef movs     r3, r5
080012f1 adds     r3, #0x60
080012f3 ldrb     r2, [r3]
080012f5 cmp      r2, #0
080012f7 bne      #0x8001383
080012f9 ldr      r1, [sp, #0x28]
080012fb str      r2, [r5, #0x5c]
080012fd ldr      r2, [pc, #0xec]
080012ff str      r4, [r5, #0x58]
08001301 strh     r1, [r2, #0x2a]
08001303 movs     r2, #1
08001305 strb     r2, [r3]
08001307 movs     r2, #0xf
08001309 ldr      r5, [pc, #0xd0]
0800130b ldr      r3, [r5, #0x58]
0800130d asrs     r6, r3, #4
0800130f ldr      r3, [r5, #0x5c]
08001311 uxth     r6, r6
08001313 str      r3, [sp, #0x24]
08001315 asrs     r3, r3, #0x1f
08001317 ands     r3, r2
08001319 ldr      r2, [sp, #0x24]
0800131b adds     r3, r3, r2
0800131d asrs     r3, r3, #4
0800131f strh     r3, [r5, #0x3a]
08001321 movs     r3, r5
08001323 adds     r3, #8
08001325 strh     r6, [r3, #0x3e]
08001327 movs     r3, r5
08001329 movs     r2, #1
0800132b adds     r3, #0x4d
0800132d strb     r2, [r3]
0800132f ldr      r3, [pc, #0xbc]
08001331 ldrh     r2, [r3, #0x20]
08001333 cmp      r2, r6
08001335 bls      #0x8001339
08001337 strh     r6, [r3, #0x20]
08001339 movs     r3, r5
0800133b adds     r3, #0x4e
0800133d ldrh     r2, [r3]
0800133f cmp      r2, r6
08001341 bhs      #0x8001345
08001343 strh     r6, [r3]
08001345 ldr      r3, [sp, #0x30]
08001347 add      r4, sp, #0x8c
08001349 cmp      r3, #0
0800134b bne      #0x8001411
0800134d bl       #0x80007b9
08001351 ldr      r3, [sp, #0x30]
08001353 strh     r3, [r5, #0x38]
08001355 bl       #0x80002c1
08001359 ldr      r3, [sp, #0x30]
0800135b ldr      r2, [r4, #0x10]
0800135d strh     r3, [r5, #0x3a]
0800135f cmp      r2, #0
08001361 beq      #0x8001365
08001363 movs     r3, #3
08001365 movs     r2, r5
08001367 adds     r2, #0x3c
08001369 strb     r3, [r2]
0800136b movs     r2, r5
0800136d movs     r3, #0
0800136f adds     r2, #0x55
08001371 strb     r3, [r2]
08001373 movs     r2, r5
08001375 adds     r5, #0x57
08001377 adds     r2, #0x56
08001379 strb     r3, [r2]
0800137b strb     r3, [r5]
0800137d bl       #0x80002d9
08001381 b        #0x80012b7
08001383 ldr      r3, [r5, #0x5c]
08001385 ldr      r2, [r5, #0x58]
08001387 str      r3, [sp, #0x14]
08001389 adds     r6, r3, r2
0800138b movs     r2, #0x38
0800138d ldrsh    r3, [r5, r2]
0800138f subs     r4, r4, r6
08001391 cmp      r3, #0
08001393 bne      #0x80013c7
08001395 adds     r5, #0x57
08001397 ldrb     r3, [r5]
08001399 subs     r3, #2
0800139b cmp      r3, #3
0800139d bls      #0x80013c7
0800139f movs     r1, #3
080013a1 movs     r7, #0xc
080013a3 movs     r0, r4
080013a5 bl       #0x8004785
080013a9 ldr      r5, [pc, #0x30]
080013ab adds     r6, r0, r6
080013ad movs     r1, r7
080013af movs     r0, r4
080013b1 str      r6, [r5, #0x58]
080013b3 bl       #0x8004785
080013b7 ldr      r3, [sp, #0x14]
080013b9 adds     r0, r0, r3
080013bb movs     r3, #0x80
080013bd lsls     r3, r3, #2
080013bf cmp      r0, r3
080013c1 ble      #0x80013cd
080013c3 str      r3, [r5, #0x5c]
080013c5 b        #0x8001307
080013c7 movs     r1, #2
080013c9 movs     r7, #7
080013cb b        #0x80013a3
080013cd ldr      r3, [pc, #0x3c]
080013cf cmp      r0, r3
080013d1 blt      #0x80013c3
080013d3 str      r0, [r5, #0x5c]
080013d5 b        #0x8001307
08001411 ldrh     r3, [r4]
08001413 ldr      r2, [r4, #0x14]
08001415 str      r3, [sp, #0x14]
08001417 ldr      r3, [pc, #0x2f4]
08001419 ldr      r4, [pc, #0x2f4]
0800141b movs     r1, r3
0800141d adds     r1, #0x4c
0800141f ldrb     r0, [r1]
08001421 cmp      r0, #0
08001423 bne      #0x80014c7
08001425 str      r2, [r3, #0x48]
08001427 movs     r3, #1
08001429 ldr      r0, [sp, #0x14]
0800142b strb     r3, [r1]
0800142d strh     r0, [r4, #0x1c]
0800142f ldr      r0, [sp, #0x14]
08001431 bl       #0x8000255
08001435 lsls     r3, r0, #0xc
08001437 subs     r0, r3, r0
08001439 ldr      r3, [pc, #0x2d8]
0800143b ldr      r1, [pc, #0x2dc]
0800143d adds     r0, r0, r3
0800143f bl       #0x8004671
08001443 movs     r3, #0x80
08001445 lsls     r3, r3, #5
08001447 cmp      r0, r3
08001449 blo      #0x800144d
0800144b ldr      r0, [pc, #0x2d0]
0800144d ldr      r2, [pc, #0x2c0]
0800144f ldr      r1, [pc, #0x2d0]
08001451 ldrh     r3, [r2, #0x1a]
08001453 movs     r5, #0
08001455 uxth     r4, r0
08001457 cmp      r3, r1
08001459 beq      #0x8001465
0800145b ldr      r1, [sp, #0x14]
0800145d cmp      r3, r1
0800145f bhs      #0x80014f9
08001461 subs     r3, r1, r3
08001463 uxth     r5, r3
08001465 ldrh     r3, [r2, #0x18]
08001467 ldr      r1, [pc, #0x2b8]
08001469 cmp      r3, r1
0800146b bne      #0x80014ff
0800146d strh     r4, [r2, #0x2a]
080014c7 ldr      r1, [r3, #0x48]
080014c9 cmp      r2, r1
080014cb bne      #0x80014d3
080014cd ldrh     r3, [r4, #0x1c]
080014cf str      r3, [sp, #0x14]
080014d1 b        #0x800142f
080014d3 ldr      r0, [sp, #0x14]
080014d5 str      r2, [r3, #0x48]
080014d7 bl       #0x8000239
080014db cmp      r0, #0
080014dd beq      #0x80014e5
080014df ldr      r3, [sp, #0x14]
080014e1 strh     r3, [r4, #0x1c]
080014e3 b        #0x800142f
080014e5 ldrh     r3, [r4, #0x1c]
080014e7 ldr      r2, [sp, #0x14]
080014e9 cmp      r2, r3
080014eb bhi      #0x80014ef
080014ed beq      #0x80014f3
080014ef ldr      r3, [sp, #0x14]
080014f1 strh     r3, [r4, #0x1c]
080014f3 ldr      r3, [pc, #0x21c]
080014f5 ldrh     r3, [r3, #0x1c]
080014f7 b        #0x80014cf
080014f9 ldr      r1, [sp, #0x14]
080014fb subs     r3, r3, r1
080014fd b        #0x8001463
080014ff movs     r3, #0
08001501 str      r3, [sp, #0x20]
08001503 cmp      r5, r3
08001505 beq      #0x8001515
08001507 strh     r4, [r2, #0x2a]
08001509 cmp      r5, #2
0800150b bls      #0x8001511
0800150d bl       #0x8001e09
08001511 ldr      r3, [sp, #0x34]
08001513 str      r3, [sp, #0x20]
08001515 ldr      r3, [pc, #0x1f8]
08001517 ldr      r2, [sp, #0x14]
08001519 strh     r4, [r3, #0x18]
0800151b strh     r2, [r3, #0x1a]
0800151d ldrh     r3, [r3, #0x2a]
0800151f str      r3, [sp, #0x1c]
08001521 subs     r3, r3, r6
08001523 uxth     r1, r3
08001525 sxth     r7, r3
08001527 str      r1, [sp, #0x18]
08001529 lsls     r3, r3, #0x10
0800152b bpl      #0x8001535
0800152d ldr      r3, [sp, #0x1c]
0800152f subs     r3, r6, r3
08001531 uxth     r3, r3
08001533 str      r3, [sp, #0x18]
08001535 mov      r3, sp
08001537 ldrh     r5, [r3, #0x24]
08001539 ldr      r3, [sp, #0x24]
0800153b cmp      r3, #0
0800153d bge      #0x8001543
0800153f rsbs     r5, r5, #0
08001541 uxth     r5, r5
08001543 ldr      r3, [pc, #0x1c8]
08001545 movs     r2, r3
08001547 adds     r2, #0x52
08001549 ldrb     r2, [r2]
0800154b sxtb     r2, r2
0800154d cmp      r2, #0
0800154f bgt      #0x8001553
08001551 b        #0x800169f
08001553 ldr      r2, [sp, #0x1c]
08001555 cmp      r6, r2
08001557 bls      #0x8001567
08001559 adds     r3, #0x50
0800155b subs     r2, r6, r2
0800155d ldrh     r1, [r3]
0800155f uxth     r2, r2
08001561 cmp      r1, r2
08001563 bhs      #0x8001567
08001565 strh     r2, [r3]
08001567 movs     r2, #0xfa
08001569 ldr      r3, [pc, #0x1c0]
0800156b lsls     r2, r2, #2
0800156d ldr      r3, [r3, #0x50]
0800156f uxth     r3, r3
08001571 adds     r4, r3, #0
08001573 cmp      r3, r2
08001575 bls      #0x8001579
08001577 adds     r4, r2, #0
08001579 uxth     r3, r4
0800157b str      r3, [sp, #0x2c]
0800157d ldr      r3, [pc, #0x18c]
0800157f movs     r2, r3
08001581 adds     r2, #0x53
08001583 ldrb     r2, [r2]
08001585 sxtb     r2, r2
08001587 cmp      r2, #0
08001589 bne      #0x800159d
0800158b adds     r2, #1
0800158d cmp      r7, #0
0800158f bgt      #0x8001599
08001591 movs     r2, r7
08001593 subs     r1, r2, #1
08001595 sbcs     r2, r1
08001597 rsbs     r2, r2, #0
08001599 adds     r3, #0x53
0800159b strb     r2, [r3]
0800159d ldr      r3, [pc, #0x16c]
0800159f adds     r3, #0x53
080015a1 ldrb     r3, [r3]
080015a3 sxtb     r3, r3
080015a5 cmp      r3, #0
080015a7 bgt      #0x80015ab
080015a9 b        #0x80016bb
080015ab lsrs     r3, r7, #0x1f
080015ad str      r3, [sp, #0x5c]
080015af mov      r3, sp
080015b1 ldrh     r3, [r3, #0x3c]
080015b3 str      r3, [sp, #0x84]
080015b5 cmp      r7, #0
080015b7 bgt      #0x80015bb
080015b9 b        #0x80016cb
080015bb movs     r3, #1
080015bd ldr      r2, [sp, #0x24]
080015bf ldr      r1, [sp, #0x3c]
080015c1 cmp      r1, r2
080015c3 blt      #0x80015c7
080015c5 movs     r3, #0
080015c7 str      r3, [sp, #0x60]
080015c9 movs     r2, #0x44
080015cb mov      r3, sp
080015cd adds     r3, r3, r2
080015cf ldrh     r3, [r3]
080015d1 adds     r2, #0x20
080015d3 str      r3, [sp, #0x80]
080015d5 mov      r3, sp
080015d7 adds     r3, r3, r2
080015d9 ldrh     r3, [r3]
080015db subs     r2, #0x24
080015dd str      r3, [sp, #0x68]
080015df mov      r3, sp
080015e1 adds     r3, r3, r2
080015e3 ldrh     r3, [r3]
080015e5 adds     r2, #0x34
080015e7 str      r3, [sp, #0x44]
080015e9 mov      r3, sp
080015eb ldr      r0, [sp, #0x50]
080015ed adds     r3, r3, r2
080015ef ldrh     r3, [r3]
080015f1 movs     r1, #3
080015f3 muls     r0, r5, r0
080015f5 str      r3, [sp, #0x64]
080015f7 bl       #0x8004671
080015fb ldr      r3, [sp, #0x80]
080015fd movs     r2, #0x54
080015ff adds     r0, r3, r0
08001601 mov      r3, sp
08001603 adds     r3, r3, r2
08001605 ldrh     r3, [r3]
08001607 uxth     r0, r0
08001609 cmp      r3, r0
0800160b bls      #0x800160f
0800160d adds     r3, r0, #0
0800160f uxth     r3, r3
08001611 str      r3, [sp, #0x3c]
08001613 movs     r3, #0xe
08001615 ldr      r2, [sp, #0x68]
08001617 muls     r3, r2, r3
08001619 ldr      r2, [sp, #0x64]
0800161b adds     r3, r2, r3
0800161d uxth     r4, r3
0800161f cmp      r7, #0
08001621 ble      #0x80016dd
08001623 ldr      r3, [sp, #0x40]
08001625 ldr      r1, [sp, #0x24]
08001627 rsbs     r2, r3, #0
08001629 movs     r3, #1
0800162b cmp      r2, r1
0800162d bgt      #0x8001631
0800162f movs     r3, #0
08001631 str      r3, [sp, #0x54]
08001633 ldr      r0, [sp, #0x4c]
08001635 cmp      r0, #0x10
08001637 bge      #0x800163b
08001639 movs     r0, #0x10
0800163b ldr      r3, [sp, #0x3c]
0800163d ldr      r2, [sp, #0x18]
0800163f cmp      r3, r2
08001641 bhi      #0x80016eb
08001643 uxth     r3, r0
08001645 movs     r2, #0x70
08001647 str      r3, [sp, #0x74]
08001649 mov      r3, sp
0800164b adds     r3, r3, r2
0800164d ldrh     r3, [r3]
0800164f str      r3, [sp, #0x40]
08001651 movs     r3, #0
08001653 str      r3, [sp, #0x70]
08001655 ldr      r3, [sp, #0x60]
08001657 cmp      r3, #0
08001659 beq      #0x800166b
0800165b ldr      r3, [sp, #0x74]
0800165d ldr      r2, [sp, #0x40]
0800165f adds     r3, r3, r2
08001661 uxth     r3, r3
08001663 cmp      r3, r5
08001665 sbcs     r3, r3
08001667 rsbs     r3, r3, #0
08001669 str      r3, [sp, #0x70]
0800166b mov      r3, sp
0800166d movs     r2, #0x78
0800166f adds     r3, r3, r2
08001671 ldrh     r3, [r3]
08001673 str      r3, [sp, #0x4c]
08001675 ldr      r3, [sp, #0x20]
08001677 cmp      r3, #0
08001679 beq      #0x800167d
0800167b b        #0x8001dcd
0800167d ldr      r3, [pc, #0x8c]
0800167f movs     r2, r3
08001681 adds     r2, #0x57
08001683 ldrb     r2, [r2]
08001685 cmp      r2, #1
08001687 bne      #0x800168b
08001689 b        #0x8001dc5
0800168b cmp      r2, #6
0800168d beq      #0x8001691
0800168f b        #0x8001dcd
08001691 ldr      r3, [sp, #0x18]
08001693 cmp      r4, r3
08001695 blo      #0x8001747
08001697 b        #0x8001dcd
0800169f cmp      r2, #0
080016a1 bne      #0x80016a5
080016a3 b        #0x8001567
080016a5 ldr      r2, [sp, #0x1c]
080016a7 cmp      r6, r2
080016a9 blo      #0x80016ad
080016ab b        #0x8001567
080016ad adds     r3, #0x50
080016af ldrh     r2, [r3]
080016b1 cmp      r2, r1
080016b3 blo      #0x80016b7
080016b5 b        #0x8001567
080016b7 strh     r1, [r3]
080016b9 b        #0x8001567
080016bb str      r3, [sp, #0x5c]
080016bd cmp      r3, #0
080016bf bne      #0x80016c3
080016c1 b        #0x80015af
080016c3 asrs     r3, r7, #0x1f
080016c5 subs     r3, r3, r7
080016c7 lsrs     r3, r3, #0x1f
080016c9 b        #0x80015ad
080016cb str      r7, [sp, #0x60]
080016cd cmp      r7, #0
080016cf bne      #0x80016d3
080016d1 b        #0x80015c9
080016d3 ldr      r3, [sp, #0x3c]
080016d5 ldr      r1, [sp, #0x24]
080016d7 rsbs     r2, r3, #0
080016d9 movs     r3, #1
080016db b        #0x80015c1
080016dd str      r7, [sp, #0x54]
080016df cmp      r7, #0
080016e1 beq      #0x8001633
080016e3 movs     r3, #1
080016e5 ldr      r2, [sp, #0x24]
080016e7 ldr      r1, [sp, #0x40]
080016e9 b        #0x800162b
080016eb ldr      r3, [sp, #0x18]
080016ed ldr      r1, [sp, #0x3c]
080016ef muls     r0, r3, r0
080016f1 bl       #0x8004671
080016f5 ldr      r2, [sp, #0x44]
080016f7 adds     r3, r0, #0
080016f9 uxth     r0, r0
080016fb cmp      r0, r2
080016fd bhs      #0x8001707
080016ff mov      r3, sp
08001701 movs     r2, #0x44
08001703 adds     r3, r3, r2
08001705 ldrh     r3, [r3]
08001707 uxth     r3, r3
08001709 b        #0x8001645
08001731 adds     r3, #0x55
08001733 movs     r2, r3
08001735 ldrb     r3, [r3]
08001737 cmp      r3, #7
08001739 bhi      #0x8001747
0800173b adds     r3, #1
0800173d uxtb     r3, r3
0800173f strb     r3, [r2]
08001741 cmp      r3, #8
08001743 beq      #0x8001747
08001745 b        #0x8001dd7
08001747 ldr      r3, [pc, #0x314]
08001749 adds     r3, #0x7e
0800174b ldrb     r3, [r3]
0800174d cmp      r3, #0
0800174f bne      #0x8001767
08001751 ldr      r3, [pc, #0x30c]
08001753 ldrb     r2, [r3, #0x18]
08001755 cmp      r2, #0
08001757 bne      #0x800175f
08001759 ldr      r0, [r3, #0x20]
0800175b bl       #0x8000189
0800175f movs     r2, #1
08001761 ldr      r3, [pc, #0x2f8]
08001763 adds     r3, #0x7e
08001765 strb     r2, [r3]
08001767 movs     r2, #6
08001769 ldr      r3, [pc, #0x2f4]
0800176b ldr      r1, [sp, #0x4c]
0800176d adds     r3, #0x57
0800176f strb     r2, [r3]
08001771 mov      r3, sp
08001773 ldr      r2, [sp, #0x2c]
08001775 ldrh     r3, [r3, #0x2c]
08001777 cmp      r2, r1
08001779 bls      #0x8001783
0800177b mov      r3, sp
0800177d movs     r2, #0x4c
0800177f adds     r3, r3, r2
08001781 ldrh     r3, [r3]
08001783 uxth     r3, r3
08001785 str      r3, [sp, #0x2c]
08001787 ldr      r3, [sp, #0x34]
08001789 ldr      r2, [sp, #0x18]
0800178b str      r3, [sp, #0x20]
0800178d ldr      r3, [sp, #0x64]
0800178f cmp      r3, r2
08001791 blo      #0x8001795
08001793 b        #0x8001def
08001795 ldr      r3, [pc, #0x2c8]
08001797 adds     r3, #0x57
08001799 ldrb     r3, [r3]
0800179b cmp      r3, #1
0800179d beq      #0x80017a3
0800179f cmp      r3, #6
080017a1 bne      #0x80017bb
080017a3 ldr      r3, [sp, #0x20]
080017a5 cmp      r3, #0
080017a7 bne      #0x80017bb
080017a9 ldr      r3, [sp, #0x18]
080017ab cmp      r4, r3
080017ad blo      #0x80017bb
080017af ldr      r3, [sp, #0x40]
080017b1 adds     r3, #0x20
080017b3 uxth     r3, r3
080017b5 cmp      r5, r3
080017b7 bhi      #0x80017bb
080017b9 b        #0x8001df7
080017bb ldr      r3, [sp, #0x30]
080017bd ldr      r2, [sp, #0x5c]
080017bf orrs     r3, r2
080017c1 beq      #0x80017e5
080017c3 ldr      r3, [sp, #0x20]
080017c5 cmp      r3, #0
080017c7 bne      #0x80017e5
080017c9 ldr      r2, [sp, #0x68]
080017cb ldr      r3, [sp, #0x64]
080017cd mov      ip, r2
080017cf ldr      r2, [sp, #0x18]
080017d1 add      r3, ip
080017d3 uxth     r3, r3
080017d5 cmp      r3, r2
080017d7 blo      #0x80017e5
080017d9 ldr      r3, [sp, #0x44]
080017db adds     r3, #0x10
080017dd uxth     r3, r3
080017df cmp      r5, r3
080017e1 bhi      #0x80017e5
080017e3 b        #0x8001df7
080017e5 ldr      r3, [pc, #0x278]
080017e7 adds     r3, #0x50
080017e9 ldrh     r3, [r3]
080017eb cmp      r3, #0
080017ed beq      #0x8001801
080017ef ldr      r3, [sp, #0x18]
080017f1 cmp      r3, #0xf0
080017f3 bhi      #0x8001801
080017f5 ldr      r3, [sp, #0x40]
080017f7 adds     r3, #0x20
080017f9 uxth     r3, r3
080017fb cmp      r5, r3
080017fd bhi      #0x8001801
080017ff b        #0x8001df7
08001801 ldr      r3, [pc, #0x25c]
08001803 movs     r2, r3
08001805 adds     r2, #0x35
08001807 ldrb     r2, [r2]
08001809 cmp      r2, #0
0800180b beq      #0x8001833
0800180d ldr      r2, [pc, #0x254]
0800180f ldr      r0, [r2]
08001811 ldr      r2, [sp, #0x6c]
08001813 subs     r0, r2, r0
08001815 cmp      r0, #0x2a
08001817 bhi      #0x800182f
08001819 ldr      r2, [sp, #0x68]
0800181b ldr      r1, [sp, #0x18]
0800181d cmp      r2, r1
0800181f bhs      #0x800182f
08001821 movs     r2, r3
08001823 adds     r2, #0x36
08001825 ldrb     r2, [r2]
08001827 sxtb     r2, r2
08001829 cmp      r2, #0
0800182b beq      #0x800182f
0800182d b        #0x8001969
0800182f bl       #0x80002d9
08001833 movs     r2, #0x58
08001835 mov      r3, sp
08001837 adds     r3, r3, r2
08001839 ldrh     r2, [r3]
0800183b ldr      r3, [sp, #0x20]
0800183d cmp      r3, #0
0800183f beq      #0x8001843
08001841 b        #0x80019cb
08001843 ldr      r3, [sp, #0x5c]
08001845 cmp      r3, #0
08001847 bne      #0x800184b
08001849 b        #0x80019fd
0800184b ldr      r3, [sp, #0x54]
0800184d cmp      r3, #0
0800184f bne      #0x8001863
08001851 ldr      r3, [sp, #0x18]
08001853 cmp      r4, r3
08001855 blo      #0x8001863
08001857 ldr      r3, [sp, #0x40]
08001859 adds     r3, #0x10
0800185b uxth     r3, r3
0800185d cmp      r5, r3
0800185f bhi      #0x8001863
08001861 b        #0x8001df7
08001863 movs     r3, #3
08001865 ldr      r2, [sp, #0x18]
08001867 lsrs     r5, r5, #2
08001869 muls     r3, r2, r3
0800186b adds     r5, r3, r5
0800186d uxth     r5, r5
0800186f cmp      r4, r2
08001871 bhs      #0x8001879
08001873 movs     r3, #0x50
08001875 cmp      r5, #0x4f
08001877 bls      #0x8001887
08001879 movs     r2, #0xb4
0800187b adds     r3, r5, #0
0800187d lsls     r2, r2, #1
0800187f cmp      r5, r2
08001881 bls      #0x8001885
08001883 adds     r3, r2, #0
08001885 uxth     r3, r3
08001887 cmp      r7, #0
08001889 bge      #0x800188d
0800188b rsbs     r3, r3, #0
0800188d ldr      r2, [pc, #0x1d0]
0800188f movs     r0, #4
08001891 movs     r1, r2
08001893 adds     r1, #0x57
08001895 strb     r0, [r1]
08001897 movs     r1, #0
08001899 adds     r2, #0x56
0800189b strb     r1, [r2]
0800189d movs     r2, #0x12
0800189f str      r2, [sp, #0x24]
080018a1 ldr      r4, [sp, #0x2c]
080018a3 cmp      r4, r3
080018a5 blt      #0x80018af
080018a7 rsbs     r4, r4, #0
080018a9 cmp      r4, r3
080018ab bge      #0x80018af
080018ad movs     r4, r3
080018af movs     r3, #1
080018b1 cmp      r7, #0
080018b3 bgt      #0x80018bd
080018b5 movs     r3, r7
080018b7 subs     r2, r3, #1
080018b9 sbcs     r3, r2
080018bb rsbs     r3, r3, #0
080018bd ldr      r2, [pc, #0x1a0]
080018bf adds     r2, #0x52
080018c1 strb     r3, [r2]
080018c3 ldr      r3, [pc, #0x1a4]
080018c5 ldr      r1, [r3, #8]
080018c7 cmp      r1, #0
080018c9 beq      #0x80018cd
080018cb b        #0x8001b65
080018cd ldr      r3, [sp, #0x20]
080018cf sxth     r4, r4
080018d1 cmp      r3, #0
080018d3 beq      #0x80018d7
080018d5 b        #0x8001b95
080018d7 uxth     r3, r4
080018d9 movs     r0, #1
080018db str      r3, [sp, #0x20]
080018dd cmp      r4, #0
080018df bgt      #0x80018f5
080018e1 movs     r0, r4
080018e3 subs     r3, r0, #1
080018e5 sbcs     r0, r3
080018e7 rsbs     r0, r0, #0
080018e9 cmp      r4, #0
080018eb beq      #0x80018f5
080018ed uxth     r3, r4
080018ef rsbs     r3, r3, #0
080018f1 uxth     r3, r3
080018f3 str      r3, [sp, #0x20]
080018f5 ldr      r5, [pc, #0x168]
080018f7 movs     r2, r5
080018f9 adds     r2, #0x34
080018fb ldrb     r3, [r2]
080018fd mov      ip, r2
080018ff cmp      r3, #0
08001901 beq      #0x800191b
08001903 ldr      r3, [sp, #0x6c]
08001905 ldr      r2, [r5, #0x30]
08001907 subs     r3, r3, r2
08001909 bpl      #0x800190d
0800190b b        #0x8001b69
0800190d movs     r3, #0
0800190f adds     r2, r3, #0
08001911 mov      r3, ip
08001913 strb     r2, [r3]
08001915 movs     r3, #0
08001917 adds     r5, #0x2c
08001919 strb     r3, [r5]
0800191b ldr      r5, [pc, #0x144]
0800191d movs     r3, r5
0800191f adds     r3, #0x2c
08001921 ldrb     r3, [r3]
08001923 sxtb     r3, r3
08001925 cmp      r3, #0
08001927 bne      #0x800192b
08001929 b        #0x8001d53
0800192b cmp      r0, #0
0800192d bne      #0x8001931
0800192f b        #0x8001d53
08001931 cmp      r3, r0
08001933 bne      #0x8001937
08001935 b        #0x8001d53
08001937 bl       #0x80007b9
0800193b movs     r3, #0
0800193d strh     r3, [r5, #0x38]
0800193f movs     r3, r5
08001941 movs     r2, #9
08001943 adds     r3, #0x3c
08001945 strb     r2, [r3]
08001947 ldr      r3, [sp, #0x20]
08001949 cmp      r3, #0xb3
0800194b bhi      #0x800194f
0800194d b        #0x8001b8f
0800194f ldr      r3, [sp, #0x6c]
08001951 adds     r3, #8
08001953 str      r3, [r5, #0x30]
08001955 movs     r3, #1
08001957 adds     r5, #0x34
08001959 strb     r3, [r5]
0800195b movs     r3, #3
0800195d str      r3, [sp, #8]
0800195f movs     r3, #0
08001961 str      r3, [sp, #4]
08001963 b        #0x8001b7d
08001965 str      r2, [sp, #0x20]
08001967 b        #0x8001801
08001969 movs     r1, r3
0800196b movs     r4, #0
0800196d adds     r1, #0x56
0800196f strb     r4, [r1]
08001971 cmp      r0, #0xb
08001973 bhi      #0x800198f
08001975 movs     r1, #2
08001977 adds     r3, #0x57
08001979 strb     r1, [r3]
0800197b movs     r3, #0xc
0800197d ldr      r1, [pc, #0xec]
0800197f str      r3, [sp, #0x24]
08001981 ldr      r0, [sp, #0x2c]
08001983 adds     r3, r1, #0
08001985 cmp      r1, r0
08001987 bls      #0x80019af
08001989 mov      r3, sp
0800198b ldrh     r3, [r3, #0x2c]
0800198d b        #0x80019af
0800198f rsbs     r2, r2, #0
08001991 sxtb     r2, r2
08001993 cmp      r0, #0xf
08001995 bls      #0x80019c3
08001997 movs     r1, #0xdc
08001999 movs     r3, #0x11
0800199b movs     r4, #4
0800199d str      r3, [sp, #0x24]
0800199f ldr      r3, [pc, #0xc0]
080019a1 adds     r3, #0x57
080019a3 strb     r4, [r3]
080019a5 cmp      r0, #0x12
080019a7 bls      #0x8001981
080019a9 movs     r3, #3
080019ab str      r3, [sp, #0x24]
080019ad movs     r3, #0
080019af uxth     r3, r3
080019b1 cmp      r2, #0
080019b3 bgt      #0x80019b7
080019b5 rsbs     r3, r3, #0
080019b7 ldr      r2, [sp, #0x20]
080019b9 cmp      r2, #0
080019bb beq      #0x80019bf
080019bd b        #0x80018a1
080019bf ldr      r2, [sp, #0x34]
080019c1 b        #0x80019f9
080019c3 movs     r1, #0xb4
080019c5 movs     r3, #0xe
080019c7 lsls     r1, r1, #1
080019c9 b        #0x800199b
080019cb ldr      r3, [sp, #0x18]
080019cd movs     r1, #0x4c
080019cf lsls     r3, r3, #3
080019d1 adds     r2, r2, r3
080019d3 mov      r3, sp
080019d5 adds     r3, r3, r1
080019d7 ldr      r1, [sp, #0x4c]
080019d9 uxth     r2, r2
080019db ldrh     r3, [r3]
080019dd cmp      r1, r2
080019df bls      #0x80019e3
080019e1 adds     r3, r2, #0
080019e3 uxth     r3, r3
080019e5 cmp      r7, #0
080019e7 bge      #0x80019eb
080019e9 rsbs     r3, r3, #0
080019eb movs     r1, #6
080019ed ldr      r2, [pc, #0x70]
080019ef adds     r2, #0x57
080019f1 strb     r1, [r2]
080019f3 movs     r2, #0x10
080019f5 str      r2, [sp, #0x24]
080019f7 movs     r2, #0
080019f9 str      r2, [sp, #0x20]
080019fb b        #0x80018a1
080019fd mov      r3, sp
080019ff ldr      r1, [sp, #0x70]
08001a01 ldrh     r3, [r3, #0x38]
08001a03 cmp      r1, #0
08001a05 beq      #0x8001a71
08001a07 ldr      r2, [sp, #0x18]
08001a09 ldr      r1, [sp, #0x80]
08001a0b lsrs     r2, r2, #3
08001a0d ldr      r0, [sp, #0x18]
08001a0f adds     r2, r5, r2
08001a11 uxth     r2, r2
08001a13 cmp      r1, r0
08001a15 blo      #0x8001a2b
08001a17 ldr      r1, [sp, #0x44]
08001a19 adds     r1, #0x10
08001a1b uxth     r1, r1
08001a1d cmp      r5, r1
08001a1f bls      #0x8001a2b
08001a21 lsrs     r5, r5, #1
08001a23 adds     r5, r2, r5
08001a25 lsrs     r3, r3, #1
08001a27 adds     r5, r5, r3
08001a29 uxth     r2, r5
08001a2b movs     r1, #0xb4
08001a2d adds     r3, r2, #0
08001a2f lsls     r1, r1, #1
08001a31 cmp      r2, r1
08001a33 bls      #0x8001a37
08001a35 adds     r3, r1, #0
08001a37 uxth     r2, r3
08001a39 cmp      r2, #0x50
08001a3b bhs      #0x8001a3f
08001a3d movs     r3, #0x50
08001a3f ldr      r2, [sp, #0x24]
08001a41 uxth     r3, r3
08001a43 cmp      r2, #0
08001a45 ble      #0x8001a49
08001a47 rsbs     r3, r3, #0
08001a49 ldr      r2, [pc, #0x14]
08001a4b movs     r0, #4
08001a4d movs     r1, r2
08001a4f adds     r1, #0x57
08001a51 strb     r0, [r1]
08001a53 movs     r1, #0
08001a55 adds     r2, #0x56
08001a57 strb     r1, [r2]
08001a59 movs     r2, #0xe
08001a5b b        #0x800189f
08001a71 ldr      r0, [sp, #0x74]
08001a73 cmp      r7, #0
08001a75 bge      #0x8001a79
08001a77 rsbs     r0, r0, #0
08001a79 ldr      r3, [sp, #0x48]
08001a7b cmp      r3, #0
08001a7d bgt      #0x8001a81
08001a7f movs     r3, #1
08001a81 ldr      r1, [sp, #0x24]
08001a83 subs     r4, r0, r1
08001a85 movs     r1, #3
08001a87 muls     r4, r3, r4
08001a89 asrs     r3, r7, #0x1f
08001a8b ands     r3, r1
08001a8d adds     r3, r3, r7
08001a8f asrs     r3, r3, #2
08001a91 adds     r3, r3, r4
08001a93 ldr      r1, [sp, #0x50]
08001a95 ldr      r4, [sp, #0x24]
08001a97 muls     r1, r4, r1
08001a99 subs     r3, r3, r1
08001a9b cmp      r0, #0x18
08001a9d ble      #0x8001ad1
08001a9f ldr      r1, [sp, #0x38]
08001aa1 adds     r3, r3, r1
08001aa3 ldr      r1, [sp, #0x3c]
08001aa5 ldr      r0, [sp, #0x18]
08001aa7 cmp      r1, r0
08001aa9 bhs      #0x8001ae5
08001aab movs     r1, r0
08001aad ldr      r4, [sp, #0x38]
08001aaf ldr      r0, [sp, #0x3c]
08001ab1 mov      ip, r4
08001ab3 subs     r0, r1, r0
08001ab5 ldr      r1, [sp, #0x58]
08001ab7 asrs     r0, r0, #1
08001ab9 add      r1, ip
08001abb adds     r0, r0, r1
08001abd ldr      r1, [sp, #0x2c]
08001abf cmp      r1, r0
08001ac1 ble      #0x8001ac5
08001ac3 movs     r1, r0
08001ac5 cmp      r7, #0
08001ac7 ble      #0x8001adb
08001ac9 cmp      r3, r1
08001acb bge      #0x8001ae5
08001acd movs     r3, r1
08001acf b        #0x8001ae5
08001ad1 adds     r0, #0x18
08001ad3 bge      #0x8001aa3
08001ad5 ldr      r1, [sp, #0x38]
08001ad7 subs     r3, r3, r1
08001ad9 b        #0x8001aa3
08001adb cmp      r7, #0
08001add beq      #0x8001ae5
08001adf rsbs     r1, r1, #0
08001ae1 cmp      r3, r1
08001ae3 bgt      #0x8001acd
08001ae5 ldr      r0, [sp, #0x60]
08001ae7 ldr      r1, [pc, #0x2c4]
08001ae9 cmp      r0, #0
08001aeb bne      #0x8001b41
08001aed ldr      r0, [sp, #0x68]
08001aef ldr      r4, [sp, #0x18]
08001af1 cmp      r0, r4
08001af3 bhs      #0x8001b41
08001af5 ldr      r0, [sp, #0x84]
08001af7 cmp      r0, r5
08001af9 blo      #0x8001b41
08001afb movs     r4, r1
08001afd adds     r4, #0x56
08001aff ldrb     r0, [r4]
08001b01 cmp      r0, #0x1d
08001b03 bls      #0x8001b2d
08001b05 ldr      r3, [sp, #0x18]
08001b07 ldr      r1, [sp, #0x2c]
08001b09 lsls     r3, r3, #1
08001b0b adds     r2, r2, r3
08001b0d uxth     r2, r2
08001b0f adds     r3, r2, #0
08001b11 cmp      r2, r1
08001b13 bls      #0x8001b19
08001b15 mov      r3, sp
08001b17 ldrh     r3, [r3, #0x2c]
08001b19 uxth     r3, r3
08001b1b cmp      r7, #0
08001b1d bge      #0x8001b21
08001b1f rsbs     r3, r3, #0
08001b21 movs     r1, #6
08001b23 ldr      r2, [pc, #0x288]
08001b25 adds     r2, #0x57
08001b27 strb     r1, [r2]
08001b29 movs     r2, #0x10
08001b2b b        #0x800189f
08001b2d adds     r0, #1
08001b2f uxtb     r0, r0
08001b31 strb     r0, [r4]
08001b33 cmp      r0, #0x1e
08001b35 beq      #0x8001b05
08001b37 movs     r2, #2
08001b39 adds     r1, #0x57
08001b3b strb     r2, [r1]
08001b3d adds     r2, #0xa
08001b3f b        #0x800189f
08001b41 movs     r2, #0
08001b43 adds     r1, #0x56
08001b45 strb     r2, [r1]
08001b47 ldr      r2, [sp, #0x3c]
08001b49 ldr      r1, [sp, #0x18]
08001b4b cmp      r2, r1
08001b4d bhs      #0x8001b5d
08001b4f movs     r2, #0xc
08001b51 movs     r1, #2
08001b53 str      r2, [sp, #0x24]
08001b55 ldr      r2, [pc, #0x254]
08001b57 adds     r2, #0x57
08001b59 strb     r1, [r2]
08001b5b b        #0x80018a1
08001b5d movs     r2, #0xd
08001b5f movs     r1, #3
08001b61 str      r2, [sp, #0x24]
08001b63 b        #0x8001b55
08001b65 rsbs     r4, r4, #0
08001b67 b        #0x80018cd
08001b69 bl       #0x80007b9
08001b6d movs     r2, #0
08001b6f movs     r3, #9
08001b71 strh     r2, [r5, #0x38]
08001b73 adds     r5, #0x3c
08001b75 strb     r3, [r5]
08001b77 subs     r3, #6
08001b79 str      r3, [sp, #8]
08001b7b str      r2, [sp, #4]
08001b7d movs     r3, r6
08001b7f ldr      r2, [sp, #0x1c]
08001b81 str      r7, [sp]
08001b83 ldr      r1, [sp, #0x28]
08001b85 ldr      r0, [sp, #0x14]
08001b87 bl       #0x80005a1
08001b8b bl       #0x80012b7
08001b8f bl       #0x80002c1
08001b93 b        #0x800195b
08001b95 bl       #0x80002c1
08001b99 cmp      r4, #0
08001b9b bne      #0x8001c0b
08001b9d ldr      r3, [sp, #0x24]
08001b9f cmp      r3, #0xe
08001ba1 beq      #0x8001ba7
08001ba3 movs     r3, #3
08001ba5 str      r3, [sp, #0x24]
08001ba7 movs     r3, #1
08001ba9 str      r3, [sp, #0xc]
08001bab ldr      r3, [sp, #0x24]
08001bad str      r3, [sp, #8]
08001baf movs     r3, #9
08001bb1 str      r3, [sp, #4]
08001bb3 ldr      r2, [sp, #0x1c]
08001bb5 movs     r3, r6
08001bb7 ldr      r1, [sp, #0x28]
08001bb9 ldr      r0, [sp, #0x14]
08001bbb str      r7, [sp]
08001bbd bl       #0x8001061
08001bc1 bl       #0x80012b7
08001bc5 cmp      r3, #0
08001bc7 bne      #0x8001bcb
08001bc9 b        #0x8001da7
08001bcb cmp      r4, #0
08001bcd ble      #0x8001c69
08001bcf adds     r3, r0, r3
08001bd1 adds     r4, r3, #0
08001bd3 sxth     r3, r3
08001bd5 cmp      r3, #0
08001bd7 ble      #0x8001bdb
08001bd9 b        #0x8001d81
08001bdb sxth     r4, r4
08001bdd cmp      r4, #0
08001bdf beq      #0x8001b9d
08001be1 uxth     r2, r4
08001be3 cmp      r4, #0
08001be5 bge      #0x8001beb
08001be7 rsbs     r2, r2, #0
08001be9 uxth     r2, r2
08001beb ldr      r0, [pc, #0x1c4]
08001bed ldr      r3, [pc, #0x1bc]
08001bef ldr      r5, [r0, #0x14]
08001bf1 cmp      r1, r5
08001bf3 beq      #0x8001c77
08001bf5 movs     r2, #0
08001bf7 adds     r5, r3, #4
08001bf9 strh     r2, [r5, #0x3e]
08001bfb movs     r5, r3
08001bfd adds     r5, #0x44
08001bff strb     r2, [r5]
08001c01 ldr      r2, [sp, #0x1c]
08001c03 strh     r6, [r3, #0x3e]
08001c05 adds     r3, #2
08001c07 strh     r2, [r3, #0x3e]
08001c09 str      r1, [r0, #0x14]
08001c0b ldr      r3, [pc, #0x1a8]
08001c0d adds     r2, r4, #0
08001c0f cmp      r4, r3
08001c11 bge      #0x8001c15
08001c13 adds     r2, r3, #0
08001c15 movs     r3, #0xfa
08001c17 sxth     r1, r2
08001c19 lsls     r3, r3, #2
08001c1b cmp      r1, r3
08001c1d ble      #0x8001c21
08001c1f adds     r2, r3, #0
08001c21 cpsid    i
08001c23 ldr      r3, [pc, #0x194]
08001c25 strh     r2, [r3, #0x38]
08001c27 movs     r2, #2
08001c29 adds     r3, #0x3a
08001c2b cmp      r4, #0
08001c2d bgt      #0x8001c31
08001c2f movs     r2, #3
08001c31 strb     r2, [r3]
08001c33 cpsie    i
08001c35 ldr      r3, [pc, #0x174]
08001c37 movs     r2, #1
08001c39 strh     r4, [r3, #0x38]
08001c3b cmp      r4, #0
08001c3d bgt      #0x8001c41
08001c3f subs     r2, #2
08001c41 movs     r1, r3
08001c43 adds     r1, #0x2c
08001c45 strb     r2, [r1]
08001c47 movs     r2, r3
08001c49 movs     r1, #0
08001c4b adds     r2, #0x34
08001c4d strb     r1, [r2]
08001c4f movs     r2, #2
08001c51 adds     r3, #0x3c
08001c53 strb     r2, [r3]
08001c55 ldr      r3, [pc, #0x158]
08001c57 ldrh     r2, [r3, #0x2a]
08001c59 ldr      r3, [sp, #0x24]
08001c5b str      r4, [sp, #4]
08001c5d str      r3, [sp, #8]
08001c5f str      r7, [sp]
08001c61 movs     r3, r6
08001c63 b        #0x8001b83
08001c65 cmp      r3, #0
08001c67 bgt      #0x8001bdd
08001c69 cmp      r4, r3
08001c6b bge      #0x8001bdd
08001c6d subs     r5, r3, r4
08001c6f cmp      r5, r2
08001c71 ble      #0x8001be1
08001c73 subs     r3, r3, r0
08001c75 b        #0x8001da3
08001c77 ldr      r1, [pc, #0x144]
08001c79 ldr      r1, [r1, #0x20]
08001c7b cmp      r1, #0
08001c7d bne      #0x8001c93
08001c7f adds     r2, r3, #4
08001c81 strh     r1, [r2, #0x3e]
08001c83 movs     r2, r3
08001c85 adds     r2, #0x44
08001c87 strh     r6, [r3, #0x3e]
08001c89 strb     r1, [r2]
08001c8b adds     r3, #2
08001c8d ldr      r2, [sp, #0x1c]
08001c8f strh     r2, [r3, #0x3e]
08001c91 b        #0x8001c0b
08001c93 adds     r3, #2
08001c95 ldrh     r1, [r3, #0x3e]
08001c97 ldr      r3, [sp, #0x1c]
08001c99 cmp      r3, r1
08001c9b bls      #0x8001cf5
08001c9d subs     r3, r3, r1
08001c9f ldr      r0, [pc, #0x120]
08001ca1 uxth     r3, r3
08001ca3 cmp      r1, r0
08001ca5 beq      #0x8001cb7
08001ca7 cmp      r3, #0x3c
08001ca9 bls      #0x8001cb7
08001cab movs     r1, #0
08001cad ldr      r3, [pc, #0xfc]
08001caf adds     r0, r3, #4
08001cb1 adds     r3, #0x44
08001cb3 strh     r1, [r0, #0x3e]
08001cb5 strb     r1, [r3]
08001cb7 ldr      r1, [pc, #0xf4]
08001cb9 ldr      r5, [pc, #0x104]
08001cbb ldrh     r0, [r1, #0x3e]
08001cbd adds     r3, r1, #2
08001cbf strh     r6, [r1, #0x3e]
08001cc1 cmp      r0, r5
08001cc3 beq      #0x8001c8d
08001cc5 ldr      r1, [sp, #0x1c]
08001cc7 strh     r1, [r3, #0x3e]
08001cc9 ldr      r3, [sp, #0x18]
08001ccb cmp      r3, #0x3b
08001ccd bls      #0x8001cd3
08001ccf cmp      r2, #0xb3
08001cd1 bhi      #0x8001cfb
08001cd3 ldr      r3, [pc, #0xd8]
08001cd5 adds     r1, r3, #4
08001cd7 ldrh     r2, [r1, #0x3e]
08001cd9 cmp      r2, #0
08001cdb beq      #0x8001ce1
08001cdd subs     r2, #1
08001cdf strh     r2, [r1, #0x3e]
08001ce1 adds     r3, #0x44
08001ce3 ldrb     r3, [r3]
08001ce5 cmp      r3, #0
08001ce7 beq      #0x8001c0b
08001ce9 movs     r3, #0
08001ceb str      r3, [sp, #0xc]
08001ced adds     r3, #8
08001cef str      r3, [sp, #8]
08001cf1 subs     r3, #4
08001cf3 b        #0x8001bb1
08001cf5 ldr      r3, [sp, #0x1c]
08001cf7 subs     r3, r1, r3
08001cf9 b        #0x8001c9f
08001cfb subs     r3, r6, r0
08001cfd sxth     r3, r3
08001cff cmp      r7, #0
08001d01 ble      #0x8001d2b
08001d03 cmp      r3, #0
08001d05 bge      #0x8001d33
08001d07 subs     r3, r0, r6
08001d09 sxth     r3, r3
08001d0b cmp      r3, #0
08001d0d beq      #0x8001d37
08001d0f uxth     r3, r3
08001d11 cmp      r3, #8
08001d13 bhi      #0x8001d37
08001d15 ldr      r2, [pc, #0x94]
08001d17 adds     r2, #4
08001d19 ldrh     r3, [r2, #0x3e]
08001d1b cmp      r3, #0x4f
08001d1d bls      #0x8001d41
08001d1f movs     r2, #1
08001d21 ldr      r3, [pc, #0x88]
08001d23 adds     r3, #0x44
08001d25 strb     r2, [r3]
08001d27 ldr      r3, [pc, #0x84]
08001d29 b        #0x8001ce1
08001d2b cmp      r7, #0
08001d2d beq      #0x8001d33
08001d2f cmp      r3, #0
08001d31 bgt      #0x8001d0f
08001d33 cmp      r3, #0
08001d35 beq      #0x8001d27
08001d37 movs     r2, #0
08001d39 ldr      r3, [pc, #0x70]
08001d3b adds     r3, #4
08001d3d strh     r2, [r3, #0x3e]
08001d3f b        #0x8001d27
08001d41 adds     r3, #1
08001d43 uxth     r3, r3
08001d45 strh     r3, [r2, #0x3e]
08001d47 cmp      r3, #0x50
08001d49 bne      #0x8001d27
08001d4b b        #0x8001d1f
08001d53 ldr      r3, [pc, #0x5c]
08001d55 adds     r3, #0xa8
08001d57 ldr      r2, [r3]
08001d59 movs     r3, #0x80
08001d5b lsls     r3, r3, #9
08001d5d cmp      r2, r3
08001d5f blo      #0x8001d63
08001d61 movs     r2, #0x50
08001d63 ldr      r3, [pc, #0x48]
08001d65 uxth     r0, r2
08001d67 movs     r5, #0x38
08001d69 ldrsh    r3, [r3, r5]
08001d6b sxth     r2, r2
08001d6d cmp      r3, #0
08001d6f bgt      #0x8001d73
08001d71 b        #0x8001bc5
08001d73 cmp      r4, #0
08001d75 bge      #0x8001d93
08001d77 subs     r3, r3, r0
08001d79 adds     r4, r3, #0
08001d7b lsls     r3, r3, #0x10
08001d7d bmi      #0x8001d81
08001d7f b        #0x8001bdb
08001d81 movs     r4, #0
08001d83 b        #0x8001bdb
08001d85 ldr      r3, [sp, #0x20]
08001d87 cmp      r3, #0
08001d89 bne      #0x8001d8d
08001d8b b        #0x8001795
08001d8d movs     r3, #0
08001d8f str      r3, [sp, #0x20]
08001d91 b        #0x8001801
08001d93 cmp      r4, r3
08001d95 bgt      #0x8001d99
08001d97 b        #0x8001bdd
08001d99 subs     r5, r4, r3
08001d9b cmp      r5, r2
08001d9d bgt      #0x8001da1
08001d9f b        #0x8001c65
08001da1 adds     r3, r0, r3
08001da3 sxth     r4, r3
08001da5 b        #0x8001bdd
08001da7 cmp      r4, #0
08001da9 bgt      #0x8001d99
08001dab b        #0x8001c69
08001dc5 ldr      r2, [sp, #0x18]
08001dc7 cmp      r4, r2
08001dc9 bhs      #0x8001dcd
08001dcb b        #0x8001731
08001dcd movs     r2, #0
08001dcf ldr      r3, [pc, #0x44]
08001dd1 str      r2, [sp, #0x30]
08001dd3 adds     r3, #0x55
08001dd5 strb     r2, [r3]
08001dd7 ldr      r3, [sp, #0x64]
08001dd9 ldr      r2, [sp, #0x18]
08001ddb cmp      r3, r2
08001ddd blo      #0x8001d85
08001ddf movs     r2, #0
08001de1 ldr      r3, [pc, #0x34]
08001de3 adds     r3, #0x7e
08001de5 strb     r2, [r3]
08001de7 ldr      r3, [sp, #0x20]
08001de9 cmp      r3, r2
08001deb beq      #0x8001def
08001ded b        #0x8001965
08001def ldr      r3, [sp, #0x44]
08001df1 cmp      r5, r3
08001df3 bls      #0x8001df7
08001df5 b        #0x8001795
08001df7 movs     r3, r6
08001df9 ldr      r2, [sp, #0x1c]
08001dfb ldr      r1, [sp, #0x28]
08001dfd ldr      r0, [sp, #0x14]
08001dff str      r7, [sp]
08001e01 bl       #0x8000f29
08001e05 bl       #0x80012b7
