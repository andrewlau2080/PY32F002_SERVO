int sub_8004957(void)
{
    unsigned int v0;  // r0

    return v0;
}
