08002345 movs     r0, #0x8f
08002347 ldr      r3, [sp, #0x10]
08002349 movs     r2, #0x98
0800234b str      r3, [sp, #0xc]
0800234d ldr      r3, [sp, #0x14]
0800234f movs     r1, r7
08002351 str      r3, [sp]
08002353 str      r6, [sp, #8]
08002355 movs     r3, #0x24
08002357 str      r4, [sp, #4]
08002359 lsls     r0, r0, #1
0800235b bl       #0x800224d
