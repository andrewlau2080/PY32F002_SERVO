extern unsigned int g_200007b0;

unsigned int sub_80045ed(unsigned int *a0, int a1)
{
    unsigned int v0;  // r0

    g_200007b0 = 0;
    v0 = sub_800462d(a1);
    if (v0 != 0xffffffff)
    {
        return v0;
    }
    else if (!g_200007b0)
    {
        return v0;
    }
    else
    {
        *a0 = g_200007b0;
        return v0;
    }
}
