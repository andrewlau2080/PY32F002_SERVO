int sub_80036f3(unsigned int a0, unsigned int a1)
{
    return sub_80003f5(a0, a1);
}
