080039a1 push     {r3}
080039a3 push     {r4, lr}
080039a5 movs     r4, r0
080039a7 sub      sp, #0x74
080039a9 cmp      r2, #0
080039ab blt      #0x8003a11
080039ad movs     r3, #0x82
080039af mov      r0, sp
080039b1 lsls     r3, r3, #2
080039b3 strh     r3, [r0, #0x14]
080039b5 str      r1, [sp, #8]
080039b7 str      r1, [sp, #0x18]
080039b9 cmp      r2, #0
080039bb beq      #0x80039e7
080039bd movs     r3, #1
080039bf subs     r2, #1
080039c1 rsbs     r3, r3, #0
080039c3 strh     r3, [r0, #0x16]
080039c5 str      r2, [sp, #0x10]
080039c7 add      r3, sp, #0x80
080039c9 str      r2, [sp, #0x1c]
080039cb movs     r0, r4
080039cd ldr      r2, [sp, #0x7c]
080039cf add      r1, sp, #8
080039d1 str      r3, [sp, #4]
080039d3 bl       #0x8003cf9
080039d7 adds     r3, r0, #1
080039d9 bge      #0x80039df
080039db movs     r3, #0x8b
080039dd str      r3, [r4]
080039df movs     r3, #0
080039e1 ldr      r2, [sp, #8]
080039e3 strb     r3, [r2]
080039e5 b        #0x8003a07
080039e7 movs     r3, #1
080039e9 rsbs     r3, r3, #0
080039eb strh     r3, [r0, #0x16]
080039ed str      r2, [sp, #0x10]
080039ef add      r3, sp, #0x80
080039f1 str      r2, [sp, #0x1c]
080039f3 movs     r0, r4
080039f5 ldr      r2, [sp, #0x7c]
080039f7 add      r1, sp, #8
080039f9 str      r3, [sp, #4]
080039fb bl       #0x8003cf9
080039ff adds     r3, r0, #1
08003a01 bge      #0x8003a07
08003a03 movs     r3, #0x8b
08003a05 str      r3, [r4]
08003a07 add      sp, #0x74
08003a09 pop      {r4}
08003a0b pop      {r3}
08003a0d add      sp, #4
08003a0f bx       r3
08003a11 movs     r3, #0x8b
08003a13 str      r3, [r0]
08003a15 movs     r0, #1
08003a17 rsbs     r0, r0, #0
08003a19 b        #0x8003a07
