int sub_8002d61(unsigned int a0, unsigned int a1)
{
    int v1;  // r4
    char v0;  // [bp+0x7c]

    sub_8001ea9(0x38400);
    sub_80021d5("bkcmd=0");
    sub_8001e49(80, a1);
    sub_80021d5("bkcmd=0");
    sub_80021d5("dim=100");
    sub_80021d5("page 0");
    sub_8001e49(250, a1);
    sub_80021d5("tsw 255,0");
    sub_80021d5("tsw 255,0");
    sub_80021d5("tsw 255,0");
    sub_8003a1d(&v0, 16, "tsw %u,0", v1); /* do not return */
}
