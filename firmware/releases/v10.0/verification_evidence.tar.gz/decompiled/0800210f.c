extern char g_20000388;
extern char g_20000389;
extern unsigned int g_40012c00;
extern unsigned int g_40012c0c;
extern unsigned int g_40012c10;
extern unsigned int g_40012c14;
extern unsigned int g_40012c18;
extern unsigned int g_40012c20;
extern unsigned int g_40012c24;
extern unsigned int g_40012c28;
extern unsigned int g_40012c2c;
extern unsigned int g_40021034;
extern unsigned int g_40021040;
extern unsigned int g_e000e100;
extern unsigned int g_e000e280;
extern unsigned int g_e000e40c;

void sub_800210f(unsigned int a0, unsigned int a1, unsigned int a2, unsigned int a3)
{
    unsigned int v7;  // r4
    unsigned int v0;  // [bp-0x2c]
    unsigned int v1;  // [bp-0x28]
    unsigned int v2;  // [bp-0x24]
    unsigned int v3;  // [bp-0x20]
    unsigned int v4;  // [bp-0x1c]
    unsigned int v5;  // [bp-0x18]
    unsigned int v6;  // [bp-0x14]

    v7 = 1;
    v4 = a3;
    g_40021034 = g_40021034 | 1;
    v0 = g_40021034 & 1;
    g_40021040 = g_40021040 | 0x800;
    v1 = g_40021040 & 0x800;
    v2 = 8;
    v3 = 2;
    v5 = 2;
    v6 = 13;
    sub_8000925(0x50000000, &v2);
    if ((unsigned int)*(int *)0x20000038 > 999999)
        v7 = sub_8004671(*0x20000038, 1000000);
    g_40012c00 = 0;
    g_40012c0c = 0;
    g_40012c28 = v7 - 1;
    g_40012c2c = 0xffff;
    g_40012c24 = 0;
    g_40012c18 = 1;
    g_40012c20 = 1;
    g_40012c14 = 1;
    g_40012c10 = 0;
    g_40012c0c = 2;
    g_40012c00 = 1;
    g_20000388 = 0;
    g_20000389 = 0;
    g_e000e40c = g_e000e40c & 0xff00ffff;
    g_e000e280 = 0x4000;
    g_e000e100 = 0x4000;
    return;
}
