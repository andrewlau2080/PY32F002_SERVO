int sub_8003657(void)
{
}
