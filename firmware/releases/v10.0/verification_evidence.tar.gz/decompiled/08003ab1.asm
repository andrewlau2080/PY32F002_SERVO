08003ab1 push     {r4, lr}
08003ab3 lsls     r3, r0, #0x1e
08003ab5 beq      #0x8003acd
08003ab7 movs     r3, r0
08003ab9 movs     r1, #3
08003abb b        #0x8003ac3
08003abd adds     r3, #1
08003abf tst      r3, r1
08003ac1 beq      #0x8003acf
08003ac3 ldrb     r2, [r3]
08003ac5 cmp      r2, #0
08003ac7 bne      #0x8003abd
08003ac9 subs     r0, r3, r0
08003acb pop      {r4, pc}
08003acd movs     r3, r0
08003acf ldr      r1, [r3]
08003ad1 ldr      r2, [pc, #0x30]
08003ad3 ldr      r4, [pc, #0x34]
08003ad5 adds     r2, r1, r2
08003ad7 bics     r2, r1
08003ad9 tst      r2, r4
08003adb bne      #0x8003afd
08003add ldr      r1, [r3, #4]
08003adf ldr      r2, [pc, #0x24]
08003ae1 adds     r3, #4
08003ae3 adds     r2, r1, r2
08003ae5 bics     r2, r1
08003ae7 tst      r2, r4
08003ae9 bne      #0x8003afd
08003aeb ldr      r1, [r3, #4]
08003aed ldr      r2, [pc, #0x14]
08003aef adds     r3, #4
08003af1 adds     r2, r1, r2
08003af3 bics     r2, r1
08003af5 tst      r2, r4
08003af7 beq      #0x8003add
08003af9 b        #0x8003afd
08003afb adds     r3, #1
08003afd ldrb     r2, [r3]
08003aff cmp      r2, #0
08003b01 bne      #0x8003afb
08003b03 b        #0x8003ac9
