void sub_8004e99(unsigned int a0)
{
}
