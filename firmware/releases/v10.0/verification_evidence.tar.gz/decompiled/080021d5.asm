080021d5 push     {r3, r4, r5, r6, r7, lr}
080021d7 movs     r5, r0
080021d9 bl       #0x8003ab1
080021dd movs     r7, #0x10
080021df movs     r4, r0
080021e1 bl       #0x8000155
080021e5 cmp      r4, #0
080021e7 bne      #0x8002201
080021e9 ldr      r0, [pc, #0x30]
080021eb movs     r2, #0x14
080021ed movs     r1, #3
080021ef adds     r0, #0x34
080021f1 bl       #0x8000f95
080021f5 movs     r0, #2
080021f7 bl       #0x8001e1d
080021fb bl       #0x8000155
080021ff pop      {r3, r4, r5, r6, r7, pc}
08002201 movs     r6, r4
08002203 cmp      r4, #0x10
08002205 bls      #0x8002209
08002207 movs     r6, r7
08002209 movs     r0, r5
0800220b movs     r2, #0xfa
0800220d uxth     r1, r6
0800220f bl       #0x8000f95
08002213 adds     r5, r5, r6
08002215 subs     r4, r4, r6
08002217 bl       #0x80010b5
0800221b b        #0x80021e5
