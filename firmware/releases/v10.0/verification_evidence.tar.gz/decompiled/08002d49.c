void sub_8002d49(void)
{
    sub_8002725(0x9600); /* do not return */
}
