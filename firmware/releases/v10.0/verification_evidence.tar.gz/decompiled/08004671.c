int sub_8004671(unsigned int a0, unsigned int a1)
{
    unsigned int v0;  // r2
    unsigned int v1;  // r1
    unsigned int v10;  // r3
    unsigned int v11;  // r0
    unsigned int v12;  // cc_dep2
    unsigned int v13;  // r2
    unsigned int v14;  // r3
    unsigned int v15;  // r3
    unsigned int v17;  // r3
    unsigned int v18;  // r0
    unsigned int v19;  // cc_dep2
    unsigned int v2;  // r3
    unsigned int v20;  // r0
    unsigned int v21;  // r3
    unsigned int v22;  // r0
    unsigned int v23;  // cc_dep2
    unsigned int v24;  // r0
    unsigned int v25;  // r3
    unsigned int v26;  // r0
    unsigned int v27;  // cc_dep2
    unsigned int v28;  // r0
    unsigned int v29;  // r2
    unsigned int v3;  // r0
    unsigned int v30;  // r3
    unsigned int v31;  // r0
    unsigned int v32;  // cc_dep2
    unsigned int v33;  // 4130
    unsigned int v34;  // r3
    unsigned int v35;  // r0
    unsigned int v36;  // cc_dep2
    unsigned int v37;  // r0
    unsigned int v38;  // r3
    unsigned int v39;  // r0
    unsigned int v4;  // cc_dep2
    unsigned int v40;  // cc_dep2
    unsigned int v41;  // r0
    unsigned int v42;  // r3
    unsigned int v43;  // r0
    unsigned int v44;  // cc_dep2
    unsigned int v45;  // r2
    unsigned int v46;  // r3
    unsigned int v47;  // r3
    unsigned int v49;  // r3
    unsigned int v5;  // r0
    unsigned int v50;  // r0
    unsigned int v51;  // cc_dep2
    unsigned int v52;  // r0
    unsigned int v53;  // r3
    unsigned int v54;  // r0
    unsigned int v55;  // cc_dep2
    unsigned int v56;  // r2
    unsigned int v57;  // r3
    unsigned int v58;  // r3
    unsigned int v6;  // r3
    unsigned int v7;  // r0
    unsigned int v8;  // cc_dep2
    unsigned int v9;  // r0

    v0 = 0;
    if (a0 >> 1 >= a1)
    {
        if (a0 >> 4 >= a1)
        {
            if (a0 >> 8 >= a1)
            {
                if (a0 >> 12 < a1)
                    goto LABEL_80046dd;
                if (a0 >> 16 >= a1)
                {
                    v1 = a1 * 0x100;
                    v0 = 0xff000000;
                    a1 = v1;
                    if (a0 >> 16 >= a1)
                    {
                        v0 = 0xff0000;
                        a1 = v1 * 0x100;
                        if (!(v1 * 0x100))
                            return sub_8004771();
                    }
                    if (a0 >> 12 < a1)
                        goto LABEL_80046dd;
                }
                while (1)
                {
                    v2 = a0 >> 15;
                    v3 = a0;
                    v4 = a1;
                    if (v2 >= v4)
                    {
                        v4 = a1 * 0x8000;
                        v3 = a0 - v4;
                        v2 = a0;
                    }
                    v5 = v3;
                    v6 = v5 >> 14;
                    v7 = v5;
                    v8 = a1;
                    if (v6 >= v8)
                    {
                        v8 = a1 * 0x4000;
                        v7 = v5 - v8;
                        v6 = v5;
                    }
                    v9 = v7;
                    v10 = v9 >> 13;
                    v11 = v9;
                    v12 = a1;
                    if (v10 >= v12)
                    {
                        v12 = a1 * 0x2000;
                        v11 = v9 - v12;
                        v10 = v9;
                    }
                    a0 = v11;
                    v13 = ((v0 * 2 + (v2 >= v4)) * 2 + (v6 >= v8)) * 2 + (v10 >= v12);
                    v14 = a0 >> 12;
                    if (v14 >= a1)
                    {
                        v15 = a1 * 0x1000;
                        v0 = v13 * 2 + (a0 >= v15);
                        a0 -= v15;
                    }
                    else
                    {
                        v0 = v13 * 2 + (v14 >= a1);
                    }
LABEL_80046dd:
                    v17 = a0 >> 11;
                    v18 = a0;
                    v19 = a1;
                    if (v17 >= v19)
                    {
                        v19 = a1 * 0x800;
                        v18 = a0 - v19;
                        v17 = a0;
                    }
                    v20 = v18;
                    v21 = v20 >> 10;
                    v22 = v20;
                    v23 = a1;
                    if (v21 >= v23)
                    {
                        v23 = a1 * 0x400;
                        v22 = v20 - v23;
                        v21 = v20;
                    }
                    v24 = v22;
                    v25 = v24 >> 9;
                    v26 = v24;
                    v27 = a1;
                    if (v25 >= v27)
                    {
                        v27 = a1 * 0x200;
                        v26 = v24 - v27;
                        v25 = v24;
                    }
                    v28 = v26;
                    v29 = ((v0 * 2 + (v17 >= v19)) * 2 + (v21 >= v23)) * 2 + (v25 >= v27);
                    v30 = v28 >> 8;
                    v31 = v28;
                    v32 = a1;
                    if (v30 >= v32)
                    {
                        v32 = a1 * 0x100;
                        v31 = v28 - v32;
                        v30 = v28;
                    }
                    a0 = v31;
                    v0 = v29 * 2 + (v30 >= v32);
                    v33 = _ccall(35, v29, v29, v30 >= v32);
                    if (!(v33 & 1))
                        break;
                    a1 >>= 8;
                }
            }
            v34 = a0 >> 7;
            v35 = a0;
            v36 = a1;
            if (v34 >= v36)
            {
                v36 = a1 * 128;
                v35 = a0 - v36;
                v34 = a0;
            }
            v37 = v35;
            v38 = v37 >> 6;
            v39 = v37;
            v40 = a1;
            if (v38 >= v40)
            {
                v40 = a1 * 64;
                v39 = v37 - v40;
                v38 = v37;
            }
            v41 = v39;
            v42 = v41 >> 5;
            v43 = v41;
            v44 = a1;
            if (v42 >= v44)
            {
                v44 = a1 * 32;
                v43 = v41 - v44;
                v42 = v41;
            }
            a0 = v43;
            v45 = ((v0 * 2 + (v34 >= v36)) * 2 + (v38 >= v40)) * 2 + (v42 >= v44);
            v46 = a0 >> 4;
            if (v46 >= a1)
            {
                v47 = a1 * 16;
                v0 = v45 * 2 + (a0 >= v47);
                a0 -= v47;
            }
            else
            {
                v0 = v45 * 2 + (v46 >= a1);
            }
        }
        v49 = a0 >> 3;
        v50 = a0;
        v51 = a1;
        if (v49 >= v51)
        {
            v51 = a1 * 8;
            v50 = a0 - v51;
            v49 = a0;
        }
        v52 = v50;
        v53 = v52 >> 2;
        v54 = v52;
        v55 = a1;
        if (v53 >= v55)
        {
            v55 = a1 * 4;
            v54 = v52 - v55;
            v53 = v52;
        }
        a0 = v54;
        v56 = (v0 * 2 + (v49 >= v51)) * 2 + (v53 >= v55);
        v57 = a0 >> 1;
        if (v57 >= a1)
        {
            v58 = a1 * 2;
            v0 = v56 * 2 + (a0 >= v58);
            a0 -= v58;
        }
        else
        {
            v0 = v56 * 2 + (v57 >= a1);
        }
    }
    return v0 * 2 + (a0 >= a1);
}
