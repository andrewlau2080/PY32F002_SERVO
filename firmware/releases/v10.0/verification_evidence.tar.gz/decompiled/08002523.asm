08002523 movs     r3, #0xf8
08002525 movs     r0, #4
08002527 lsls     r3, r3, #8
08002529 ldr      r2, [pc, #0x13c]
0800252b ldr      r1, [pc, #0x140]
0800252d str      r4, [sp]
0800252f bl       #0x80022f1
