08002593 cmp      r5, #5
08002595 bne      #0x8002569
08002597 movs     r6, #0
08002599 ldr      r7, [pc, #0xfc]
0800259b adds     r7, #0x38
0800259d ldm      r7!, {r3}
0800259f movs     r0, r6
080025a1 movs     r1, r5
080025a3 str      r3, [sp, #0x14]
080025a5 bl       #0x800477d
080025a9 movs     r0, r6
080025ab uxtb     r4, r1
080025ad movs     r1, r5
080025af bl       #0x8004671
080025b3 movs     r2, #1
080025b5 movs     r3, #0xe8
080025b7 movs     r1, #0x27
080025b9 uxtb     r0, r0
080025bb muls     r0, r3, r0
080025bd muls     r1, r4, r1
080025bf ldr      r3, [pc, #0xdc]
080025c1 ands     r4, r2
080025c3 rsbs     r4, r4, #0
080025c5 ands     r4, r3
080025c7 ldr      r3, [pc, #0xd8]
080025c9 adds     r0, #0x22
080025cb adds     r4, r4, r3
080025cd ldr      r3, [sp, #0x14]
080025cf adds     r6, #1
080025d1 str      r3, [sp, #0xc]
080025d3 movs     r3, #0
080025d5 str      r2, [sp, #8]
080025d7 str      r3, [sp]
080025d9 adds     r1, #0x2c
080025db uxth     r0, r0
080025dd str      r4, [sp, #4]
080025df adds     r3, #0x1c
080025e1 adds     r2, #0xb3
080025e3 uxtb     r6, r6
080025e5 bl       #0x800224d
