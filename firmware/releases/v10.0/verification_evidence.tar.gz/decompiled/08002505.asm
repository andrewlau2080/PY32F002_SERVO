08002505 movs     r2, r5
08002507 movs     r3, #0x1f
08002509 movs     r0, #2
0800250b ldr      r1, [pc, #0x154]
0800250d str      r4, [sp]
0800250f bl       #0x80022f1
