0800053d push     {r0, r1, r2, r4, r5, r6, r7, lr}
0800053f cpsid    i
08000541 ldr      r3, [pc, #0x54]
08000543 ldrh     r6, [r3, #0x2e]
08000545 ldrh     r5, [r3, #0x2c]
08000547 ldrh     r4, [r3, #0x30]
08000549 ldr      r3, [pc, #0x50]
0800054b uxth     r6, r6
0800054d movs     r2, r3
0800054f adds     r2, #0x71
08000551 ldrb     r1, [r2]
08000553 ldr      r2, [r3, #0x6c]
08000555 ldr      r7, [r3, #0x74]
08000557 mov      ip, r2
08000559 ldr      r2, [r3, #0x64]
0800055b adds     r3, #0x70
0800055d str      r2, [sp]
0800055f ldr      r2, [r3, #8]
08000561 uxth     r5, r5
08000563 str      r2, [sp, #4]
08000565 movs     r2, #0xa0
08000567 lsls     r2, r2, #0x17
08000569 ldr      r2, [r2, #0x10]
0800056b ldrb     r3, [r3]
0800056d uxth     r4, r4
0800056f uxtb     r1, r1
08000571 uxtb     r3, r3
08000573 cpsie    i
08000575 strb     r1, [r0, #6]
08000577 mov      r1, ip
08000579 lsls     r2, r2, #0x1c
0800057b lsrs     r2, r2, #0x1f
0800057d strb     r2, [r0, #0x18]
0800057f subs     r2, r3, #1
08000581 sbcs     r3, r2
08000583 str      r1, [r0, #8]
08000585 ldr      r1, [sp]
08000587 strh     r6, [r0]
08000589 str      r1, [r0, #0x10]
0800058b ldr      r1, [sp, #4]
0800058d strh     r5, [r0, #2]
0800058f str      r7, [r0, #0xc]
08000591 strh     r4, [r0, #4]
08000593 str      r1, [r0, #0x14]
08000595 strb     r3, [r0, #0x19]
08000597 pop      {r1, r2, r3, r4, r5, r6, r7, pc}
