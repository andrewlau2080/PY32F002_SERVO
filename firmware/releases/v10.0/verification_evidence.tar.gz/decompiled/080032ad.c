extern unsigned short g_20000008;
extern unsigned short g_2000000a;

int sub_80032ad(void)
{
    unsigned short v0;  // r5
    unsigned short v1;  // r4

    g_2000000a = v0;
    g_20000008 = v1;
}
