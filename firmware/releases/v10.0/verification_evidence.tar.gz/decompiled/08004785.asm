08004785 mov      r3, r0
08004787 orrs     r3, r1
08004789 bmi      #0x800488b
0800478b movs     r2, #0
0800478d lsrs     r3, r0, #1
0800478f cmp      r3, r1
08004791 blo      #0x800487d
08004793 lsrs     r3, r0, #4
08004795 cmp      r3, r1
08004797 blo      #0x8004859
08004799 lsrs     r3, r0, #8
0800479b cmp      r3, r1
0800479d blo      #0x8004829
0800479f lsrs     r3, r0, #0xc
080047a1 cmp      r3, r1
080047a3 blo      #0x80047f7
080047a5 lsrs     r3, r0, #0x10
080047a7 cmp      r3, r1
080047a9 blo      #0x80047c7
080047ab movs     r2, #0xff
080047ad lsls     r1, r1, #8
080047af rev      r2, r2
080047b1 lsrs     r3, r0, #0x10
080047b3 cmp      r3, r1
080047b5 blo      #0x80047bd
080047b7 asrs     r2, r2, #8
080047b9 lsls     r1, r1, #8
080047bb beq      #0x8004889
080047bd lsrs     r3, r0, #0xc
080047bf cmp      r3, r1
080047c1 blo      #0x80047f7
080047c3 b        #0x80047c7
080047c5 lsrs     r1, r1, #8
080047c7 lsrs     r3, r0, #0xf
080047c9 cmp      r3, r1
080047cb blo      #0x80047d1
080047cd lsls     r3, r1, #0xf
080047cf subs     r0, r0, r3
080047d1 adcs     r2, r2
080047d3 lsrs     r3, r0, #0xe
080047d5 cmp      r3, r1
080047d7 blo      #0x80047dd
080047d9 lsls     r3, r1, #0xe
080047db subs     r0, r0, r3
080047dd adcs     r2, r2
080047df lsrs     r3, r0, #0xd
080047e1 cmp      r3, r1
080047e3 blo      #0x80047e9
080047e5 lsls     r3, r1, #0xd
080047e7 subs     r0, r0, r3
080047e9 adcs     r2, r2
080047eb lsrs     r3, r0, #0xc
080047ed cmp      r3, r1
080047ef blo      #0x80047f5
080047f1 lsls     r3, r1, #0xc
080047f3 subs     r0, r0, r3
080047f5 adcs     r2, r2
080047f7 lsrs     r3, r0, #0xb
080047f9 cmp      r3, r1
080047fb blo      #0x8004801
080047fd lsls     r3, r1, #0xb
080047ff subs     r0, r0, r3
08004801 adcs     r2, r2
08004803 lsrs     r3, r0, #0xa
08004805 cmp      r3, r1
08004807 blo      #0x800480d
08004809 lsls     r3, r1, #0xa
0800480b subs     r0, r0, r3
0800480d adcs     r2, r2
0800480f lsrs     r3, r0, #9
08004811 cmp      r3, r1
08004813 blo      #0x8004819
08004815 lsls     r3, r1, #9
08004817 subs     r0, r0, r3
08004819 adcs     r2, r2
0800481b lsrs     r3, r0, #8
0800481d cmp      r3, r1
0800481f blo      #0x8004825
08004821 lsls     r3, r1, #8
08004823 subs     r0, r0, r3
08004825 adcs     r2, r2
08004827 bhs      #0x80047c5
08004829 lsrs     r3, r0, #7
0800482b cmp      r3, r1
0800482d blo      #0x8004833
0800482f lsls     r3, r1, #7
08004831 subs     r0, r0, r3
08004833 adcs     r2, r2
08004835 lsrs     r3, r0, #6
08004837 cmp      r3, r1
08004839 blo      #0x800483f
0800483b lsls     r3, r1, #6
0800483d subs     r0, r0, r3
0800483f adcs     r2, r2
08004841 lsrs     r3, r0, #5
08004843 cmp      r3, r1
08004845 blo      #0x800484b
08004847 lsls     r3, r1, #5
08004849 subs     r0, r0, r3
0800484b adcs     r2, r2
0800484d lsrs     r3, r0, #4
0800484f cmp      r3, r1
08004851 blo      #0x8004857
08004853 lsls     r3, r1, #4
08004855 subs     r0, r0, r3
08004857 adcs     r2, r2
08004859 lsrs     r3, r0, #3
0800485b cmp      r3, r1
0800485d blo      #0x8004863
0800485f lsls     r3, r1, #3
08004861 subs     r0, r0, r3
08004863 adcs     r2, r2
08004865 lsrs     r3, r0, #2
08004867 cmp      r3, r1
08004869 blo      #0x800486f
0800486b lsls     r3, r1, #2
0800486d subs     r0, r0, r3
0800486f adcs     r2, r2
08004871 lsrs     r3, r0, #1
08004873 cmp      r3, r1
08004875 blo      #0x800487b
08004877 lsls     r3, r1, #1
08004879 subs     r0, r0, r3
0800487b adcs     r2, r2
0800487d subs     r1, r0, r1
0800487f bhs      #0x8004883
08004881 mov      r1, r0
08004883 adcs     r2, r2
08004885 mov      r0, r2
08004887 bx       lr
08004889 b        #0x8004947
0800488b lsrs     r2, r1, #0x1f
0800488d beq      #0x8004891
0800488f rsbs     r1, r1, #0
08004891 asrs     r3, r0, #0x20
08004893 blo      #0x8004897
08004895 rsbs     r0, r0, #0
08004897 eors     r3, r2
08004899 movs     r2, #0
0800489b mov      ip, r3
0800489d lsrs     r3, r0, #4
0800489f cmp      r3, r1
080048a1 blo      #0x80048ff
080048a3 lsrs     r3, r0, #8
080048a5 cmp      r3, r1
080048a7 blo      #0x80048cf
080048a9 movs     r2, #0xfc
080048ab lsls     r1, r1, #6
080048ad rev      r2, r2
080048af lsrs     r3, r0, #8
080048b1 cmp      r3, r1
080048b3 blo      #0x80048cf
080048b5 lsls     r1, r1, #6
080048b7 asrs     r2, r2, #6
080048b9 cmp      r3, r1
080048bb blo      #0x80048cf
080048bd lsls     r1, r1, #6
080048bf asrs     r2, r2, #6
080048c1 cmp      r3, r1
080048c3 blo      #0x80048cf
080048c5 lsls     r1, r1, #6
080048c7 beq      #0x800493f
080048c9 asrs     r2, r2, #6
080048cb b        #0x80048cf
080048cd lsrs     r1, r1, #6
080048cf lsrs     r3, r0, #7
080048d1 cmp      r3, r1
080048d3 blo      #0x80048d9
080048d5 lsls     r3, r1, #7
080048d7 subs     r0, r0, r3
080048d9 adcs     r2, r2
080048db lsrs     r3, r0, #6
080048dd cmp      r3, r1
080048df blo      #0x80048e5
080048e1 lsls     r3, r1, #6
080048e3 subs     r0, r0, r3
080048e5 adcs     r2, r2
080048e7 lsrs     r3, r0, #5
080048e9 cmp      r3, r1
080048eb blo      #0x80048f1
080048ed lsls     r3, r1, #5
080048ef subs     r0, r0, r3
080048f1 adcs     r2, r2
080048f3 lsrs     r3, r0, #4
080048f5 cmp      r3, r1
080048f7 blo      #0x80048fd
080048f9 lsls     r3, r1, #4
080048fb subs     r0, r0, r3
080048fd adcs     r2, r2
080048ff lsrs     r3, r0, #3
08004901 cmp      r3, r1
08004903 blo      #0x8004909
08004905 lsls     r3, r1, #3
08004907 subs     r0, r0, r3
08004909 adcs     r2, r2
0800490b lsrs     r3, r0, #2
0800490d cmp      r3, r1
0800490f blo      #0x8004915
08004911 lsls     r3, r1, #2
08004913 subs     r0, r0, r3
08004915 adcs     r2, r2
08004917 bhs      #0x80048cd
08004919 lsrs     r3, r0, #1
0800491b cmp      r3, r1
0800491d blo      #0x8004923
0800491f lsls     r3, r1, #1
08004921 subs     r0, r0, r3
08004923 adcs     r2, r2
08004925 subs     r1, r0, r1
08004927 bhs      #0x800492b
08004929 mov      r1, r0
0800492b mov      r3, ip
0800492d adcs     r2, r2
0800492f asrs     r3, r3, #1
08004931 mov      r0, r2
08004933 blo      #0x8004939
08004935 rsbs     r0, r0, #0
08004937 cmp      r3, #0
08004939 bpl      #0x800493d
0800493b rsbs     r1, r1, #0
0800493d bx       lr
0800493f mov      r3, ip
08004941 asrs     r3, r3, #1
08004943 blo      #0x8004947
08004945 rsbs     r0, r0, #0
