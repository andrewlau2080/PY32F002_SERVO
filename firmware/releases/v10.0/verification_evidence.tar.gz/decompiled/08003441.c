int sub_8003441(void)
{
}
