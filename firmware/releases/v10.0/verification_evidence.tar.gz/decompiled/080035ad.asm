080035ad movs     r2, #0x1f
080035af cmp      r4, #2
080035b1 beq      #0x80035b7
080035b3 movs     r2, #0xf8
080035b5 lsls     r2, r2, #8
080035b7 movs     r0, #4
080035b9 add      r1, sp, #0x7c
080035bb bl       #0x8002371
