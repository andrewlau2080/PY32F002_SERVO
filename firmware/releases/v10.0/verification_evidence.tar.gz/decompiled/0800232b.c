void sub_800232b(void)
{
    int v0;  // r7
    unsigned short v1;  // r5
    unsigned short v2;  // r4
    int v3;  // r6

    sub_800224d(26, v0 + 42, 230, 36, v1 + 31, v2, 0, v3); /* do not return */
}
