int sub_8004251(void)
{
}
