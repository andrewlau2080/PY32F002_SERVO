void sub_8002505(void)
{
    unsigned int v1;  // r4
    unsigned int v2;  // r5
    unsigned int v0;  // [bp+0x0]

    v0 = v1;
    sub_80022f1(2, "A", v2, 31);
}
