0800436d push     {r4, r5, r6, r7, lr}
0800436f cmp      r0, r1
08004371 bls      #0x8004389
08004373 adds     r3, r1, r2
08004375 cmp      r0, r3
08004377 bhs      #0x8004389
08004379 subs     r3, r2, #1
0800437b cmp      r2, #0
0800437d beq      #0x8004387
0800437f ldrb     r2, [r1, r3]
08004381 strb     r2, [r0, r3]
08004383 subs     r3, #1
08004385 bhs      #0x800437f
08004387 pop      {r4, r5, r6, r7, pc}
08004389 cmp      r2, #0xf
0800438b bhi      #0x80043a5
0800438d movs     r5, r0
0800438f subs     r6, r2, #1
08004391 cmp      r2, #0
08004393 beq      #0x8004387
08004395 movs     r3, #0
08004397 ldrb     r4, [r1, r3]
08004399 movs     r2, r3
0800439b strb     r4, [r5, r3]
0800439d adds     r3, #1
0800439f cmp      r6, r2
080043a1 bne      #0x8004397
080043a3 b        #0x8004387
080043a5 movs     r7, #3
080043a7 movs     r5, r1
080043a9 movs     r6, r7
080043ab orrs     r5, r0
080043ad movs     r4, r1
080043af movs     r3, r0
080043b1 ands     r6, r5
080043b3 tst      r7, r5
080043b5 bne      #0x800440f
080043b7 movs     r5, r2
080043b9 subs     r5, #0x10
080043bb lsrs     r5, r5, #4
080043bd mov      ip, r5
080043bf lsls     r7, r5, #4
080043c1 adds     r7, r7, r0
080043c3 ldr      r5, [r4]
080043c5 str      r5, [r3]
080043c7 ldr      r5, [r4, #4]
080043c9 str      r5, [r3, #4]
080043cb ldr      r5, [r4, #8]
080043cd str      r5, [r3, #8]
080043cf ldr      r5, [r4, #0xc]
080043d1 adds     r4, #0x10
080043d3 str      r5, [r3, #0xc]
080043d5 movs     r5, r3
080043d7 adds     r3, #0x10
080043d9 cmp      r5, r7
080043db bne      #0x80043c3
080043dd mov      r5, ip
080043df movs     r3, #0xf
080043e1 movs     r4, #0xc
080043e3 adds     r5, #1
080043e5 lsls     r5, r5, #4
080043e7 adds     r1, r1, r5
080043e9 ands     r3, r2
080043eb adds     r5, r0, r5
080043ed tst      r4, r2
080043ef beq      #0x8004415
080043f1 ldr      r4, [r1, r6]
080043f3 str      r4, [r5, r6]
080043f5 adds     r6, #4
080043f7 subs     r4, r3, r6
080043f9 cmp      r4, #3
080043fb bhi      #0x80043f1
080043fd subs     r3, #4
080043ff lsrs     r3, r3, #2
08004401 adds     r3, #1
08004403 lsls     r3, r3, #2
08004405 adds     r5, r5, r3
08004407 adds     r1, r1, r3
08004409 movs     r3, #3
0800440b ands     r2, r3
0800440d b        #0x800438f
0800440f movs     r5, r0
08004411 subs     r6, r2, #1
08004413 b        #0x8004395
08004415 movs     r2, r3
08004417 b        #0x800438f
