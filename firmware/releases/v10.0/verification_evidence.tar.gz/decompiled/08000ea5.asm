08000ea5 push     {r0, r1, r2, r4, r5, r6, r7, lr}
08000ea7 ldr      r3, [pc, #0x74]
08000ea9 adds     r3, #0x48
08000eab ldrh     r3, [r3]
08000ead str      r3, [sp, #4]
08000eaf mov      r3, sp
08000eb1 ldrh     r4, [r3, #4]
08000eb3 ldr      r3, [sp, #4]
08000eb5 cmp      r3, #0x20
08000eb7 bls      #0x8000ebb
08000eb9 movs     r4, #0x20
08000ebb uxth     r3, r4
08000ebd cmp      r3, #0
08000ebf bne      #0x8000ec3
08000ec1 movs     r4, #1
08000ec3 movs     r7, #0
08000ec5 movs     r6, r7
08000ec7 movs     r0, #4
08000ec9 ldr      r5, [pc, #0x54]
08000ecb bl       #0x8000e61
08000ecf uxth     r4, r4
08000ed1 str      r7, [sp]
08000ed3 bl       #0x8000ab1
08000ed7 uxth     r2, r0
08000ed9 adds     r3, r0, #0
08000edb cmp      r2, r5
08000edd bls      #0x8000ee1
08000edf adds     r3, r5, #0
08000ee1 ldr      r1, [sp]
08000ee3 uxth     r5, r3
08000ee5 adds     r3, r0, #0
08000ee7 cmp      r2, r1
08000ee9 bhs      #0x8000eef
08000eeb mov      r3, sp
08000eed ldrh     r3, [r3]
08000eef uxth     r3, r3
08000ef1 adds     r7, #1
08000ef3 str      r3, [sp]
08000ef5 adds     r6, r6, r0
08000ef7 cmp      r4, r7
08000ef9 bhi      #0x8000ed3
08000efb ldr      r3, [sp, #4]
08000efd cmp      r3, #3
08000eff bls      #0x8000f0b
08000f01 ldr      r3, [sp]
08000f03 subs     r4, #2
08000f05 adds     r5, r5, r3
08000f07 subs     r6, r6, r5
08000f09 uxth     r4, r4
08000f0b movs     r0, r6
08000f0d movs     r1, r4
08000f0f bl       #0x8004671
08000f13 ldr      r3, [pc, #0x10]
08000f15 uxth     r0, r0
08000f17 adds     r3, #0x78
08000f19 strh     r0, [r3]
08000f1b pop      {r1, r2, r3, r4, r5, r6, r7, pc}
