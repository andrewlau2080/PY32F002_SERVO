int sub_80035ef(void)
{
}
