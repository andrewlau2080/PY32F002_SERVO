08003fe7 adds     r5, #1
08003fe9 cmp      r5, r8
08003feb bge      #0x8004055
