void* sub_8003855(void* a0, void* iter, unsigned int a2)
{
    unsigned int v2;  // r7
    unsigned int v3;  // r8
    unsigned int v12;  // r5
    unsigned int v13;  // r3
    void* v14;  // r5
    unsigned int v15;  // r3
    unsigned int v16;  // r2
    unsigned int j;  // r6
    unsigned int v18;  // r3
    unsigned int v19;  // r3
    unsigned int v4;  // r5
    unsigned int v5;  // r6
    unsigned int v6;  // r5
    void* v7;  // r4
    void* v8;  // r3
    void* i;  // r3
    void* v10;  // r4
    unsigned int v0;  // [bp-0x18]
    unsigned int v1;  // [bp-0x8]

    v1 = v2;
    v0 = v3;
    if (a2 > 15)
    {
        v4 = iter | a0;
        v5 = 3 & v4;
        if (!(v4 & 3))
        {
            v6 = a2 - 16 >> 4;
            v7 = iter;
            v8 = a0;
            do
            {
                i = v8;
                *(int *)i = *(int *)v7;
                *(int *)&i[4] = (int)v7[4];
                *(int *)&i[8] = (int)v7[8];
                v10 = v7 + 16;
                *(int *)&i[12] = (int)v7[12];
                v7 = v10;
                v8 = i + 16;
            } while (i != v6 * 16 + a0);
            v12 = (v6 + 1) * 16;
            iter += v12;
            v13 = 15 & a2;
            v14 = a0 + v12;
            if (a2 & 12)
            {
                do
                {
                    *(int *)((char *)v14 + v5) = *(int *)((char *)iter + v5);
                    v5 += 4;
                } while (3 < v13 - v5);
                v15 = ((v13 - 4 >> 2) + 1) * 4;
                v14 += v15;
                iter += v15;
                v16 = a2 & 3;
                j = v16 - 1;
                if (!v16)
                    return a0;
                v18 = 0;
            }
            else
            {
                a2 = v13;
LABEL_80038e5:
                j = a2 - 1;
                if (!a2)
                    return a0;
                v18 = 0;
            }
        }
        else
        {
            v14 = a0;
            j = a2 - 1;
            v18 = 0;
        }
        do
        {
            v19 = v18;
            *((char *)v14 + v19) = *((char *)iter + v19);
            v18 = v19 + 1;
        } while (j != v19);
        return a0;
    }
    v14 = a0;
    goto LABEL_80038e5;
}
