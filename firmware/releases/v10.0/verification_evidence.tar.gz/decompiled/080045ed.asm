080045ed movs     r3, #0
080045ef push     {r4, r5, r6, lr}
080045f1 ldr      r5, [pc, #0x18]
080045f3 movs     r4, r0
080045f5 movs     r0, r1
080045f7 str      r3, [r5]
080045f9 bl       #0x800462d
080045fd adds     r3, r0, #1
080045ff beq      #0x8004603
08004601 pop      {r4, r5, r6, pc}
08004603 ldr      r3, [r5]
08004605 cmp      r3, #0
08004607 beq      #0x8004601
08004609 str      r3, [r4]
0800460b b        #0x8004601
