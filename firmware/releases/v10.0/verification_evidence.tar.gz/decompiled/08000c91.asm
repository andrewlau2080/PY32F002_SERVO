08000c91 push     {r4, r5, lr}
08000c93 sub      sp, #0x24
08000c95 movs     r4, r0
08000c97 movs     r5, r1
08000c99 movs     r2, #0x14
08000c9b movs     r1, #0
08000c9d add      r0, sp, #0xc
08000c9f bl       #0x80038f9
08000ca3 movs     r3, #0xa0
08000ca5 lsls     r3, r3, #0x17
08000ca7 cmp      r4, r3
08000ca9 bne      #0x8000cd5
08000cab movs     r0, #1
08000cad ldr      r2, [pc, #0x58]
08000caf ldr      r1, [r2, #0x34]
08000cb1 orrs     r1, r0
08000cb3 str      r1, [r2, #0x34]
08000cb5 ldr      r3, [r2, #0x34]
08000cb7 ands     r3, r0
08000cb9 str      r3, [sp, #8]
08000cbb ldr      r3, [sp, #8]
08000cbd movs     r3, #1
08000cbf movs     r0, r4
08000cc1 str      r3, [sp, #0x10]
08000cc3 add      r1, sp, #0xc
08000cc5 adds     r3, r3, r3
08000cc7 str      r5, [sp, #0xc]
08000cc9 str      r3, [sp, #0x14]
08000ccb str      r3, [sp, #0x18]
08000ccd bl       #0x8000925
08000cd1 add      sp, #0x24
08000cd3 pop      {r4, r5, pc}
08000cd5 ldr      r3, [pc, #0x34]
08000cd7 cmp      r4, r3
08000cd9 bne      #0x8000cef
08000cdb movs     r0, #2
08000cdd ldr      r2, [pc, #0x28]
08000cdf ldr      r1, [r2, #0x34]
08000ce1 orrs     r1, r0
08000ce3 str      r1, [r2, #0x34]
08000ce5 ldr      r3, [r2, #0x34]
08000ce7 ands     r3, r0
08000ce9 str      r3, [sp, #4]
08000ceb ldr      r3, [sp, #4]
08000ced b        #0x8000cbd
08000cef ldr      r3, [pc, #0x20]
08000cf1 cmp      r4, r3
08000cf3 bne      #0x8000cbd
08000cf5 movs     r0, #0x20
08000cf7 ldr      r2, [pc, #0x10]
08000cf9 ldr      r1, [r2, #0x34]
08000cfb orrs     r1, r0
08000cfd str      r1, [r2, #0x34]
08000cff ldr      r3, [r2, #0x34]
08000d01 ands     r3, r0
08000d03 str      r3, [sp]
08000d05 ldr      r3, [sp]
08000d07 b        #0x8000cbd
