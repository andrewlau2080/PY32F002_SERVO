void sub_8003263(unsigned int a0, unsigned int a1, unsigned int a2, unsigned int a3)
{
    char v0;  // [bp+0x7c]

    sub_8002371(0, &v0, 31, a3); /* do not return */
}
