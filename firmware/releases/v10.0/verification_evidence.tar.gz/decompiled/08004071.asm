08004071 push     {r4, r5, r6, r7, lr}
08004073 mov      r6, sb
08004075 mov      sb, r3
08004077 movs     r3, #0x43
08004079 mov      ip, r3
0800407b mov      r7, sl
0800407d mov      r5, r8
0800407f mov      lr, fp
08004081 add      ip, r1
08004083 mov      r3, ip
08004085 push     {r5, r6, r7, lr}
08004087 sub      sp, #0x1c
08004089 str      r3, [sp, #0xc]
0800408b movs     r4, r1
0800408d ldrb     r1, [r1, #0x18]
0800408f mov      r8, r2
08004091 movs     r7, r0
08004093 ldr      r2, [sp, #0x40]
08004095 cmp      r1, #0
08004097 beq      #0x80040c3
08004099 movs     r3, r1
0800409b subs     r3, #0x58
0800409d uxtb     r3, r3
0800409f cmp      r3, #0x20
080040a1 bhi      #0x800413b
080040a3 ldr      r0, [pc, #0x248]
080040a5 lsls     r3, r3, #2
080040a7 ldr      r3, [r0, r3]
080040a9 mov      pc, r3
080040c3 movs     r3, #0
080040c5 ldr      r5, [sp, #0xc]
080040c7 str      r3, [r4, #0x10]
080040c9 mov      r3, sb
080040cb movs     r1, r4
080040cd str      r3, [sp]
080040cf movs     r0, r7
080040d1 mov      r3, r8
080040d3 add      r2, sp, #0x14
080040d5 bl       #0x8003f35
0800413b movs     r3, #0x42
0800413d movs     r5, r4
0800413f strb     r1, [r4, r3]
08004141 subs     r3, #0x41
08004143 adds     r5, #0x42
08004145 str      r3, [r4, #0x10]
08004147 movs     r3, #0x43
08004149 movs     r2, #0
0800414b strb     r2, [r4, r3]
0800414d b        #0x80040c9
