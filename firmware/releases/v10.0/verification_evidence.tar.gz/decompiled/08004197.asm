08004197 ldr      r3, [r2]
08004199 movs     r5, r4
0800419b adds     r1, r3, #4
0800419d str      r1, [r2]
0800419f ldr      r2, [r3]
080041a1 movs     r3, #0x42
080041a3 strb     r2, [r4, r3]
080041a5 subs     r3, #0x41
080041a7 adds     r5, #0x42
080041a9 str      r3, [r4, #0x10]
080041ab b        #0x8004147
