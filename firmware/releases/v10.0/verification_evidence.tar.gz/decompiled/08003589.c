int sub_8003589(unsigned int a0, unsigned int a1, unsigned int a2, unsigned int a3, unsigned int a4, unsigned int a5, unsigned int a6, unsigned int a7, unsigned int a8, unsigned int a9, unsigned int a10, unsigned int a11, unsigned int a12, unsigned int a13, unsigned int a14, unsigned int a15, unsigned int a16, unsigned int a17)
{
    char v0;  // [bp+0x7c]

    a5 = a12;
    a4 = a17;
    sub_8003a1d(&v0, 32, "%s%u %d"); /* do not return */
}
