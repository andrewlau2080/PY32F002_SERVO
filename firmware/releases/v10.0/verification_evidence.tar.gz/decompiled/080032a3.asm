080032a3 movs     r2, #0x1f
080032a5 movs     r0, #1
080032a7 add      r1, sp, #0x7c
080032a9 bl       #0x8002371
