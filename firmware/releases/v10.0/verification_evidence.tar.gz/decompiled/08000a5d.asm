08000a5d push     {r4, r5, lr}
08000a5f sub      sp, #0x1c
08000a61 movs     r2, #8
08000a63 movs     r1, #0
08000a65 add      r0, sp, #0x10
08000a67 bl       #0x80038f9
08000a6b movs     r3, #1
08000a6d movs     r4, #0xa0
08000a6f movs     r5, #0x20
08000a71 ldr      r2, [pc, #0x24]
08000a73 lsls     r4, r4, #0x17
08000a75 ldr      r1, [r2, #0x34]
08000a77 movs     r0, r4
08000a79 orrs     r1, r3
08000a7b str      r1, [r2, #0x34]
08000a7d ldr      r2, [r2, #0x34]
08000a7f add      r1, sp, #4
08000a81 ands     r2, r3
08000a83 str      r2, [sp]
08000a85 str      r3, [sp, #8]
08000a87 adds     r3, r3, r3
08000a89 ldr      r2, [sp]
08000a8b str      r5, [sp, #4]
08000a8d str      r3, [sp, #0xc]
08000a8f bl       #0x8000925
08000a93 str      r5, [r4, #0x18]
08000a95 add      sp, #0x1c
08000a97 pop      {r4, r5, pc}
