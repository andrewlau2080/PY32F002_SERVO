080000c1 movs     r3, #0
080000c3 push     {r4, r5, r6, lr}
080000c5 ldr      r5, [pc, #0x20]
080000c7 ldr      r4, [r5, #4]
080000c9 ldr      r2, [r5, #8]
080000cb adds     r4, #1
080000cd cmp      r3, r0
080000cf blo      #0x80000d3
080000d1 pop      {r4, r5, r6, pc}
080000d3 ldr      r1, [r5, #8]
080000d5 cmp      r2, r1
080000d7 blo      #0x80000e1
080000d9 adds     r3, r3, r2
080000db subs     r3, r3, r1
080000dd movs     r2, r1
080000df b        #0x80000cd
080000e1 subs     r6, r4, r1
080000e3 adds     r3, r6, r3
080000e5 adds     r3, r2, r3
080000e7 b        #0x80000dd
