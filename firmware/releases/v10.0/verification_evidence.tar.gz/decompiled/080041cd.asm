080041cd movs     r3, #0x20
080041cf ldr      r1, [r4]
080041d1 orrs     r3, r1
080041d3 str      r3, [r4]
080041d5 movs     r1, #0x45
080041d7 movs     r0, #0x78
080041d9 strb     r0, [r4, r1]
080041db ldr      r1, [pc, #0x118]
080041dd mov      fp, r1
080041df lsls     r1, r3, #0x18
080041e1 bmi      #0x8004247
080041e3 lsls     r1, r3, #0x19
080041e5 bpl      #0x8004247
080041e7 ldr      r1, [r2]
080041e9 adds     r0, r1, #4
080041eb ldrh     r6, [r1]
080041ed str      r0, [r2]
080041ef lsls     r2, r3, #0x1f
080041f1 bpl      #0x80041f9
080041f3 movs     r2, #0x20
080041f5 orrs     r3, r2
080041f7 str      r3, [r4]
080041f9 movs     r3, #0x10
080041fb mov      sl, r3
080041fd cmp      r6, #0
080041ff bne      #0x8004209
08004201 ldr      r2, [r4]
08004203 adds     r3, #0x10
08004205 bics     r2, r3
08004207 str      r2, [r4]
08004247 ldr      r1, [r2]
08004249 adds     r0, r1, #4
0800424b str      r0, [r2]
0800424d ldr      r6, [r1]
0800424f b        #0x80041ef
