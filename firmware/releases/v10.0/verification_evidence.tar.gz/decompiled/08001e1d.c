void sub_8001e1d(unsigned int i)
{
    unsigned int v0;  // r4

    v0 = 0;
    do
    {
        sub_80010b5();
        v0 += 1;
        sub_80000c1(sub_8004671(*0x20000038, 1000));
    } while (i != v0);
    sub_80010b5();
    return;
}
