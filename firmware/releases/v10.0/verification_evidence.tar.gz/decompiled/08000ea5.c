extern unsigned short g_20000418;

int sub_8000ea5(unsigned int a0, unsigned int a1)
{
    unsigned int v3;  // r2
    unsigned short v4;  // r4
    unsigned int i;  // r7
    int iter;  // r6
    unsigned int v7;  // r5
    unsigned int v8;  // r0
    unsigned int v9;  // r4
    unsigned int v10;  // r2
    unsigned int v11;  // r3
    unsigned int v12;  // r3
    unsigned int v0;  // [bp-0x20]
    unsigned int v1;  // [bp-0x1c]
    unsigned int v2;  // [bp-0x18]

    v0 = a0;
    v1 = a1;
    v2 = v3;
    v1 = *(short *)0x20000770;
    v4 = v1;
    if (v1 > 32)
        v4 = 32;
    if (!v4)
        v4 = 1;
    i = 0;
    iter = 0;
    v7 = 0xffff;
    v8 = (unsigned int)sub_8000e61(4, a1, v3);
    v9 = v4;
    v0 = 0;
    do
    {
        v8 = sub_8000ab1(v8, a1);
        v10 = v8 & 0xffff;
        v11 = v8;
        if (v10 > v7)
            v11 = v7;
        a1 = v0;
        v7 = v11 & 0xffff;
        v12 = v8;
        if (a1 > v10)
            v12 = (unsigned short)v0;
        i += 1;
        v0 = v12 & 0xffff;
        iter += v8;
    } while (i < v9);
    if (v1 > 3)
    {
        iter -= v7 + v0;
        v9 = v9 - 2 & 0xffff;
    }
    g_20000418 = sub_8004671(iter, v9);
    return g_20000418;
}
