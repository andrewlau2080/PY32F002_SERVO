void sub_80022b5(void)
{
    unsigned short v0;  // r4
    int v1;  // r6

    sub_800224d(6, 3, 340, 26, 0xffff, v0, 0, v1); /* do not return */
}
