08002371 push     {r0, r1, r2, r3, r4, lr}
08002373 movs     r3, #0x26
08002375 muls     r3, r0, r3
08002377 adds     r3, #0x2a
08002379 movs     r4, r1
0800237b lsls     r0, r0, #0x1f
0800237d movs     r1, r3
0800237f ldr      r3, [pc, #0x20]
08002381 asrs     r0, r0, #0x1f
08002383 ands     r0, r3
08002385 ldr      r3, [pc, #0x1c]
08002387 str      r2, [sp]
08002389 adds     r0, r0, r3
0800238b str      r0, [sp, #4]
0800238d movs     r3, #0
0800238f movs     r0, #0x8f
08002391 str      r3, [sp, #8]
08002393 movs     r2, #0x98
08002395 str      r4, [sp, #0xc]
08002397 adds     r3, #0x24
08002399 lsls     r0, r0, #1
0800239b bl       #0x800224d
