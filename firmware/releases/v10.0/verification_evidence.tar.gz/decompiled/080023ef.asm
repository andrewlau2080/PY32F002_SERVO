080023ef movs     r1, r5
080023f1 movs     r2, #0x10
080023f3 movs     r0, #0xa0
080023f5 bl       #0x80023a9
