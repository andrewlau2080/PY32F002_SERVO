extern char g_20000355;
extern char g_20000356;

int sub_80002d9(void)
{
    unsigned int v0;  // r0

    g_20000355 = 0;
    g_20000356 = 0;
    return v0;
}
