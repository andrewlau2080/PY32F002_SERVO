unsigned int sub_8004619(unsigned int a0, int *a1)
{
    unsigned int *v0;  // r3
    unsigned int v1;  // r0

    v0 = (char *)a1 - 4;
    v1 = *v0 - 4;
    if ((int)*v0 < 0)
        v1 += *(int *)((char *)a1 + v1);
    return v1;
}
