void sub_8002283(void)
{
    char v0;  // [bp+0x20]

    sub_80021d5(&v0);
    return;
}
