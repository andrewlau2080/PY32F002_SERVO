extern unsigned int g_20000340;

int sub_80036c9(void)
{
    unsigned int v0;  // r0

    g_20000340 = g_20000340 + 1;
    return v0;
}
