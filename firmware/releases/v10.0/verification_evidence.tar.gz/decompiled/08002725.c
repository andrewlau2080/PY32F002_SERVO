void sub_8002725(unsigned int a0)
{
    unsigned int v3;  // r4
    unsigned int v4;  // lr
    char v0;  // [bp-0x20]
    unsigned int v1;  // [bp-0x8]
    unsigned int v2;  // [bp-0x4]

    v1 = v3;
    v2 = v4;
    sub_8001ea9(a0);
    sub_80021d5("bkcmd=0");
    sub_8003a1d(&v0, 24, "bauds=%lu", 0x38400); /* do not return */
}
