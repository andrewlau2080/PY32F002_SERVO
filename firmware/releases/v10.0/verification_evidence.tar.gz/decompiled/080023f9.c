void sub_80023f9(unsigned int a0, unsigned int a1, unsigned int a2, unsigned int a3)
{
    unsigned int v0;  // r4
    unsigned int v1;  // r6

    sub_80023a9(320, v0, v1, a3); /* do not return */
}
