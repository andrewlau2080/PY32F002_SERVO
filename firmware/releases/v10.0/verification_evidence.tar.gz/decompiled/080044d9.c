typedef struct st_80044d9_0 {
    int field_0;
    struct st_80044d9_0 *field_4;
} st_80044d9_0;

extern unsigned int g_200007a8;
extern unsigned int g_200007ac;

st_80044d9_0 ** sub_80044d9(unsigned int *a0, int a1)
{
    int v0;  // r5
    st_80044d9_0 *v1;  // r2
    st_80044d9_0 *v2;  // r2
    st_80044d9_0 *iter;  // r4
    int v4;  // r3
    st_80044d9_0 *v6;  // r0
    st_80044d9_0 **v7;  // r3
    st_80044d9_0 **v8;  // r0

    v0 = (a1 + 3 & ~3) + 8;
    if (12 > (unsigned int)v0)
    {
        v0 = 12;
    }
    else if (0 > v0)
    {
        *a0 = 12;
        return NULL;
    }
    if ((unsigned int)v0 < (unsigned int)a1)
    {
        *a0 = 12;
        return NULL;
    }
    sub_8004611(a0);
    v1 = g_200007a8;
    if (g_200007a8)
    {
        v2 = g_200007a8;
        while (1)
        {
            iter = v1;
            v4 = iter->field_0 - v0;
            if (iter->field_0 - v0 >= 0)
                break;
            v1 = iter->field_4;
            if (!iter->field_4)
                goto LABEL_800454d;
            v2 = iter;
        }
        if (11 < (unsigned int)v4)
        {
            iter->field_0 = v4;
            iter = (char *)iter + v4;
            iter->field_0 = v0;
        }
        else if (iter != v2)
        {
            v2->field_4 = iter->field_4;
        }
        else
        {
            g_200007a8 = iter->field_4;
        }
    }
    else
    {
LABEL_800454d:
        if (!g_200007ac)
            g_200007ac = sub_80045ed(a0, 0);
        v6 = sub_80045ed(a0, v0);
        if (v6 == 0xffffffff || !(iter = (char *)&v6->field_0 + 3 & ~3, v6 == iter || sub_80045ed(a0, iter - v6) != 0xffffffff))
        {
            *a0 = 12;
            sub_8004615(a0);
            return NULL;
        }
        iter->field_0 = v0;
    }
    sub_8004615(a0);
    v7 = &iter->field_4;
    v8 = (char *)&iter[1].field_0 + 3 & ~7;
    if (v8 == v7)
        return v8;
    *(unsigned long *)(iter + v8 - (char *)v7) = v7 - v8;
    return v8;
}
