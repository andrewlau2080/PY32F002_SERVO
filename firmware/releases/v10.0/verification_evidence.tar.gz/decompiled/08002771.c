int sub_8002771(void)
{
    unsigned int v0;  // r0

    return v0;
}
