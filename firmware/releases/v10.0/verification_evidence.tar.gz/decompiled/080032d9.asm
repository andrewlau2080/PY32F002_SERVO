080032d9 movs     r2, #0x1f
080032db movs     r0, #2
080032dd add      r1, sp, #0x7c
080032df bl       #0x8002371
