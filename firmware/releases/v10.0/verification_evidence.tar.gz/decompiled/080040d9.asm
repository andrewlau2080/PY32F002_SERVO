080040d9 adds     r3, r0, #1
080040db beq      #0x800411d
080040dd ldr      r3, [r4, #0x10]
080040df movs     r2, r5
080040e1 mov      r1, r8
080040e3 movs     r0, r7
080040e5 blx      sb
0800411d movs     r0, #1
0800411f rsbs     r0, r0, #0
08004121 add      sp, #0x1c
08004123 pop      {r4, r5, r6, r7}
08004125 mov      fp, r7
08004127 mov      sl, r6
08004129 mov      sb, r5
0800412b mov      r8, r4
0800412d pop      {r4, r5, r6, r7, pc}
