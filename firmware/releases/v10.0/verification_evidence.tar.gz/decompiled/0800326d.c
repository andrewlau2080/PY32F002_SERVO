extern unsigned short g_20000000;
extern unsigned short g_20000002;
extern unsigned int g_20000004;
extern unsigned short g_2000001e;

int sub_800326d(unsigned int a0, unsigned int a1, unsigned int a2, unsigned int a3, unsigned int a4, unsigned int a5, unsigned int a6, unsigned int a7, unsigned int a8, unsigned int a9, unsigned int a10, unsigned int a11, unsigned int a12, unsigned short a13, unsigned int a14, unsigned int a15, unsigned int a16, unsigned int a17, unsigned int a18, unsigned int a19, unsigned int a20, unsigned int a21, unsigned int a22, unsigned int a23, unsigned int a24, unsigned int a25, unsigned int a26, unsigned int a27, unsigned short a28, unsigned int a29, unsigned int a30)
{
    unsigned short v0;  // r7

    g_20000002 = v0;
    g_20000000 = a28;
    g_20000004 = a30;
    g_2000001e = a13;
}
