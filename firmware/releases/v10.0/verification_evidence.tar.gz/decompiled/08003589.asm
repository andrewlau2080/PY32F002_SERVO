08003589 ldr      r2, [sp, #0x28]
0800358b ldr      r3, [pc, #0xec]
0800358d cmp      r2, #0x10
0800358f beq      #0x800359b
08003591 ldr      r2, [sp, #0x1c]
08003593 ldr      r3, [pc, #0xe8]
08003595 cmp      r2, #1
08003597 beq      #0x800359b
08003599 ldr      r3, [pc, #0xe4]
0800359b ldr      r2, [sp, #0x20]
0800359d movs     r1, #0x20
0800359f str      r2, [sp, #4]
080035a1 ldr      r2, [sp, #0x34]
080035a3 add      r0, sp, #0x7c
080035a5 str      r2, [sp]
080035a7 ldr      r2, [pc, #0xdc]
080035a9 bl       #0x8003a1d
