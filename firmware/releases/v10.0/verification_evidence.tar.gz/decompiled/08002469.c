void sub_8002469(unsigned int a0, unsigned int a1, unsigned int a2, unsigned int a3)
{
    unsigned int v7;  // r4
    unsigned int v8;  // r5
    unsigned int v9;  // r6
    unsigned int v10;  // r7
    unsigned int v11;  // lr
    unsigned int v0;  // [bp-0x18]
    unsigned int v1;  // [bp-0x14]
    unsigned int v2;  // [bp-0x10]
    unsigned int v3;  // [bp-0xc]
    unsigned int v4;  // [bp-0x8]
    unsigned int v5;  // [bp-0x4]
    char v6;  // [bp+0x0]

    v0 = a3;
    v1 = v7;
    v2 = v8;
    v3 = v9;
    v4 = v10;
    v5 = v11;
    sub_8002291(a0, a1, a2, &v6); /* do not return */
}
