extern unsigned short g_2000031a;
extern char g_20000324;
extern char g_20000325;
extern unsigned int g_20000328;

void* sub_8000f95(void* a0, unsigned int a1)
{
    void* v2;  // r5
    void* v3;  // r6
    void* v4;  // r6
    void* v5;  // r5
    void* v0;  // [bp-0x20]
    unsigned int idx;  // [bp-0x1c]

    v0 = a0;
    idx = a1;
    v2 = a0;
    if (g_20000325 != 32)
    {
        return v0;
    }
    else if (a0)
    {
        if (*(int *)0x200002f0 == 0x1000 && !*(int *)0x200002f8 && a0 & 0x1)
            return v0;
        idx = 536871656;
        if (g_20000324 == 1)
            return v0;
        g_20000324 = 1;
        v3 = NULL;
        g_20000328 = 0;
        g_20000325 = 33;
        *(unsigned short *)(idx + 48) = a1;
        *(unsigned short *)(idx + 50) = a1;
        v0 = *(int *)0x20000340;
        if (*(int *)0x200002f0 == 0x1000 && !*(int *)0x200002f8)
        {
            v3 = v2;
            v2 = *(int *)0x200002f8;
        }
        for (; g_2000031a; g_2000031a = g_2000031a - 1)
        {
            if (sub_8000d15(128))
                return v0;
            if (!v2)
            {
                v4 = v3 + 2;
                *(unsigned int *)(*(int *)0x200002e8 + 4) = *(short *)v3 & 0x1ff;
                v3 = v4;
            }
            else
            {
                v5 = v2 + 1;
                *(unsigned int *)(*(int *)0x200002e8 + 4) = *(char *)v2;
                v2 = v5;
            }
        }
        if (sub_8000d15(64))
            return v0;
        g_20000325 = 32;
        g_20000324 = 0;
        return v0;
    }
    else
    {
        return v0;
    }
}
