int sub_8003497(unsigned int a0, unsigned int a1)
{
}
