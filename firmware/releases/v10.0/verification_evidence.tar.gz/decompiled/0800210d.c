void sub_800210d(void)
{
    sub_800210f();
    return;
}
