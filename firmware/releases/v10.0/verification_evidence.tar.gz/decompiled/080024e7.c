void sub_80024e7(void)
{
    unsigned int v1;  // r4
    unsigned int v0;  // [bp+0x0]

    v0 = v1;
    sub_80022f1(v1, "P", "-- us", 31);
}
