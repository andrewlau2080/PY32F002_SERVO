080000ed movs     r1, #0x3f
080000ef ldr      r3, [pc, #0x20]
080000f1 ldrb     r2, [r3]
080000f3 adds     r2, #1
080000f5 ands     r2, r1
080000f7 ldrb     r1, [r3, #1]
080000f9 cmp      r1, r2
080000fb bne      #0x8000107
080000fd ldrh     r2, [r3, #2]
080000ff adds     r2, #1
08000101 uxth     r2, r2
08000103 strh     r2, [r3, #2]
08000105 bx       lr
08000107 ldrb     r1, [r3]
08000109 adds     r1, r3, r1
0800010b strb     r0, [r1, #4]
0800010d strb     r2, [r3]
0800010f b        #0x8000105
