080005a1 push     {r4, r5, r6, r7, lr}
080005a3 sub      sp, #0x54
080005a5 str      r3, [sp, #0x24]
080005a7 add      r3, sp, #0x68
080005a9 str      r2, [sp, #8]
080005ab movs     r2, #0
080005ad ldrsh    r3, [r3, r2]
080005af ldr      r5, [pc, #0x1f0]
080005b1 str      r3, [sp, #0x28]
080005b3 add      r3, sp, #0x6c
080005b5 movs     r4, #0
080005b7 ldrsh    r4, [r3, r4]
080005b9 add      r3, sp, #0x70
080005bb ldrb     r3, [r3]
080005bd str      r0, [sp, #0x20]
080005bf str      r3, [sp, #0xc]
080005c1 ldr      r3, [r5, #0x7c]
080005c3 add      r0, sp, #0x34
080005c5 adds     r2, r3, #1
080005c7 adds     r3, #2
080005c9 str      r2, [sp, #0x1c]
080005cb str      r3, [sp, #0x10]
080005cd ldr      r7, [r5, #0x20]
080005cf str      r1, [sp, #0x2c]
080005d1 bl       #0x800053d
080005d5 movs     r2, #0x80
080005d7 ldr      r3, [r5, #0x5c]
080005d9 lsls     r2, r2, #8
080005db cmp      r3, r2
080005dd blt      #0x80005e1
080005df b        #0x800078d
080005e1 ldr      r2, [pc, #0x1c0]
080005e3 str      r2, [sp, #4]
080005e5 cmp      r3, r2
080005e7 blt      #0x80005ed
080005e9 sxth     r3, r3
080005eb str      r3, [sp, #4]
080005ed movs     r3, #1
080005ef str      r3, [sp, #0x18]
080005f1 cmp      r4, #0
080005f3 bgt      #0x80005ff
080005f5 movs     r3, r4
080005f7 subs     r2, r3, #1
080005f9 sbcs     r3, r2
080005fb rsbs     r3, r3, #0
080005fd str      r3, [sp, #0x18]
080005ff ldr      r3, [pc, #0x1a8]
08000601 movs     r5, #1
08000603 movs     r2, #0
08000605 ldrsh    r3, [r3, r2]
08000607 cmp      r3, #0
08000609 bgt      #0x8000611
0800060b subs     r2, r3, #1
0800060d sbcs     r3, r2
0800060f rsbs     r5, r3, #0
08000611 ldr      r3, [pc, #0x18c]
08000613 ldr      r2, [r3, #0x1c]
08000615 ldrb     r0, [r3, #0x18]
08000617 str      r2, [sp, #0x14]
08000619 ldr      r2, [pc, #0x18c]
0800061b ldrb     r6, [r3, #0x19]
0800061d ldr      r1, [sp, #0x14]
0800061f ldr      r3, [r2, #4]
08000621 cmp      r3, r1
08000623 bne      #0x800062b
08000625 cmp      r6, #0
08000627 bne      #0x800062b
08000629 b        #0x8000799
0800062b movs     r3, #0
0800062d ldr      r1, [pc, #0x17c]
0800062f str      r3, [r2, #8]
08000631 subs     r3, #1
08000633 mov      ip, r3
08000635 strh     r3, [r1, #0x34]
08000637 movs     r3, #0
08000639 strh     r3, [r2]
0800063b mov      r3, ip
0800063d adds     r1, #0x36
0800063f strb     r3, [r1]
08000641 ldr      r3, [sp, #0x14]
08000643 str      r3, [r2, #4]
08000645 movs     r3, #0
08000647 cmp      r0, r3
08000649 beq      #0x800065b
0800064b ldr      r1, [pc, #0x154]
0800064d ldr      r3, [r1, #0x14]
0800064f subs     r2, r7, r3
08000651 movs     r3, #1
08000653 cmp      r2, #0
08000655 ble      #0x800065b
08000657 movs     r3, #0
08000659 strb     r3, [r1, #0x18]
0800065b movs     r1, #1
0800065d cmp      r6, #0
0800065f bne      #0x80006c7
08000661 ldr      r0, [pc, #0x144]
08000663 movs     r1, #1
08000665 ldr      r2, [r0, #8]
08000667 subs     r2, r7, r2
08000669 cmp      r2, #0x13
0800066b bhi      #0x80006c7
0800066d ldr      r2, [pc, #0x13c]
0800066f ldr      r6, [sp, #8]
08000671 ldrh     r2, [r2, #0x34]
08000673 cmp      r2, r6
08000675 bne      #0x80006c7
08000677 ldr      r2, [sp, #0x18]
08000679 cmp      r2, r5
0800067b bne      #0x80006c7
0800067d asrs     r2, r4, #0x1f
0800067f adds     r5, r4, r2
08000681 eors     r5, r2
08000683 movs     r1, #0
08000685 ldrsh    r2, [r0, r1]
08000687 uxth     r5, r5
08000689 uxth     r0, r2
0800068b cmp      r2, #0
0800068d blt      #0x8000691
0800068f b        #0x8000791
08000691 movs     r1, #0xa0
08000693 subs     r0, r1, r0
08000695 sxth     r0, r0
08000697 movs     r1, #1
08000699 cmp      r5, r0
0800069b bge      #0x80006c7
0800069d asrs     r1, r2, #0x1f
0800069f adds     r2, r2, r1
080006a1 eors     r2, r1
080006a3 uxth     r2, r2
080006a5 uxth     r0, r4
080006a7 cmp      r4, #0
080006a9 blt      #0x80006ad
080006ab b        #0x8000795
080006ad movs     r1, #0xa0
080006af subs     r0, r1, r0
080006b1 sxth     r0, r0
080006b3 movs     r1, #1
080006b5 cmp      r2, r0
080006b7 bge      #0x80006c7
080006b9 ldr      r2, [pc, #0xf0]
080006bb adds     r2, #0x36
080006bd ldrb     r1, [r2]
080006bf ldr      r2, [sp, #0xc]
080006c1 subs     r1, r1, r2
080006c3 subs     r2, r1, #1
080006c5 sbcs     r1, r2
080006c7 ldr      r2, [pc, #0xe0]
080006c9 ldr      r0, [sp, #0x1c]
080006cb movs     r6, r2
080006cd str      r0, [r2, #0xc]
080006cf str      r0, [r2, #0x34]
080006d1 ldr      r0, [sp, #0x20]
080006d3 str      r7, [r2, #0x10]
080006d5 strh     r0, [r2, #0x14]
080006d7 add      r0, sp, #0x34
080006d9 ldrh     r5, [r0, #2]
080006db adds     r6, #0x30
080006dd strh     r5, [r2, #0x16]
080006df ldr      r5, [sp, #0x3c]
080006e1 uxth     r5, r5
080006e3 strh     r5, [r2, #0x18]
080006e5 ldrh     r5, [r0, #4]
080006e7 strh     r5, [r2, #0x2e]
080006e9 ldrb     r5, [r0, #6]
080006eb movs     r0, r2
080006ed adds     r0, #0x32
080006ef strb     r5, [r0]
080006f1 ldr      r0, [sp, #0x2c]
080006f3 strh     r0, [r2, #0x1a]
080006f5 ldr      r0, [sp, #8]
080006f7 strh     r0, [r2, #0x1c]
080006f9 ldr      r0, [sp, #0x24]
080006fb strh     r0, [r2, #0x1e]
080006fd ldr      r0, [sp, #0x28]
080006ff strh     r0, [r2, #0x20]
08000701 ldr      r0, [sp, #4]
08000703 strh     r4, [r2, #0x22]
08000705 strh     r0, [r2, #0x24]
08000707 ldr      r0, [pc, #0x98]
08000709 movs     r5, r0
0800070b adds     r5, #0x3c
0800070d ldrb     r5, [r5]
0800070f mov      ip, r0
08000711 strb     r5, [r6]
08000713 movs     r6, r2
08000715 ldr      r0, [sp, #0xc]
08000717 adds     r6, #0x31
08000719 strb     r0, [r6]
0800071b ldr      r0, [sp, #0x10]
0800071d str      r0, [r2, #0x34]
0800071f str      r0, [r2, #0xc]
08000721 movs     r2, r0
08000723 mov      r0, ip
08000725 str      r2, [r0, #0x7c]
08000727 cmp      r3, #0
08000729 beq      #0x8000789
0800072b cmp      r1, #0
0800072d beq      #0x8000789
0800072f movs     r1, #0x14
08000731 ldrh     r2, [r0, #0x10]
08000733 ldr      r3, [pc, #0x7c]
08000735 muls     r1, r2, r1
08000737 str      r7, [r1, r3]
08000739 adds     r3, r3, r1
0800073b ldr      r1, [sp, #0x20]
0800073d adds     r2, #1
0800073f strh     r1, [r3, #4]
08000741 ldr      r1, [sp, #8]
08000743 strh     r1, [r3, #6]
08000745 ldr      r1, [sp, #0x24]
08000747 strh     r1, [r3, #8]
08000749 ldr      r1, [sp, #0x28]
0800074b strh     r1, [r3, #0xa]
0800074d ldr      r1, [sp, #4]
0800074f strh     r4, [r3, #0xc]
08000751 strh     r1, [r3, #0xe]
08000753 ldr      r1, [sp, #0xc]
08000755 strb     r5, [r3, #0x10]
08000757 strb     r1, [r3, #0x11]
08000759 uxth     r3, r2
0800075b cmp      r3, #0x22
0800075d bls      #0x8000761
0800075f movs     r3, #0
08000761 ldr      r2, [pc, #0x3c]
08000763 strh     r3, [r2, #0x10]
08000765 ldrh     r3, [r2, #0x12]
08000767 cmp      r3, #0x22
08000769 bhi      #0x8000773
0800076b ldrh     r3, [r2, #0x12]
0800076d adds     r3, #1
0800076f uxth     r3, r3
08000771 strh     r3, [r2, #0x12]
08000773 ldr      r1, [pc, #0x34]
08000775 ldr      r3, [pc, #0x34]
08000777 ldr      r0, [sp, #8]
08000779 str      r7, [r1, #8]
0800077b strh     r4, [r1]
0800077d ldr      r1, [sp, #0xc]
0800077f strh     r0, [r3, #0x34]
08000781 adds     r3, #0x36
08000783 strb     r1, [r3]
08000785 movs     r3, #0
08000787 strb     r3, [r2, #0x19]
08000789 add      sp, #0x54
0800078b pop      {r4, r5, r6, r7, pc}
0800078d ldr      r3, [pc, #0x24]
0800078f b        #0x80005eb
08000791 adds     r0, #0xa0
08000793 b        #0x8000695
08000795 adds     r0, #0xa0
08000797 b        #0x80006b1
08000799 subs     r3, r0, #0
0800079b bne      #0x800079f
0800079d b        #0x8000661
0800079f b        #0x800064b
