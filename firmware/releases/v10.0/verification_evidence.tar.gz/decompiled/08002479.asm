08002479 subs     r2, r7, r4
0800247b rsbs     r3, r2, #0
0800247d adcs     r2, r3
0800247f movs     r0, r4
08002481 adds     r4, #1
08002483 movs     r1, r5
08002485 uxtb     r2, r2
08002487 uxtb     r4, r4
08002489 bl       #0x800240d
