void sub_8002371(unsigned int a0, int a1, unsigned int a2, unsigned int a3)
{
    unsigned int v6;  // r4
    unsigned int v7;  // lr
    unsigned int v0;  // [bp-0x18]
    int v1;  // [bp-0x14]
    unsigned int v2;  // [bp-0x10]
    unsigned int v3;  // [bp-0xc]
    unsigned int v4;  // [bp-0x8]
    unsigned int v5;  // [bp-0x4]

    v0 = a0;
    v1 = a1;
    v2 = a2;
    v3 = a3;
    v4 = v6;
    v5 = v7;
    sub_800224d(286, 38 * a0 + 42, 152, 36, a2, ((int)(a0 * 0x80000000) >> 31 & 4161) + 61374, 0, a1); /* do not return */
}
