extern unsigned int g_200007b4;

unsigned int sub_800462d(unsigned int a0)
{
    unsigned int v0;  // r0

    v0 = g_200007b4;
    if (!g_200007b4)
        v0 = 536872888;
    g_200007b4 = v0 + a0;
    return v0;
}
