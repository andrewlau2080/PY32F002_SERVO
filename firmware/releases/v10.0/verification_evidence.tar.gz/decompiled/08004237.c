typedef struct st_8004237_0 {
    unsigned int field_0;
    char padding_4[65];
    char field_45;
} st_8004237_0;

int sub_8004237(void)
{
    st_8004237_0 *v0;  // r4

    v0->field_45 = 88;
    if ((int)(v0->field_0 * 0x1000000) >= 0)
        goto LABEL_0x80041e3;
    else
        goto LABEL_0x8004247;
}
