int sub_80036c7(void)
{
    unsigned int v0;  // r0

    return v0;
}
