080024f5 ldr      r5, [pc, #0x160]
080024f7 movs     r3, #0x1f
080024f9 movs     r2, r5
080024fb movs     r0, #1
080024fd ldr      r1, [pc, #0x15c]
080024ff str      r4, [sp]
08002501 bl       #0x80022f1
