08004103 ldr      r3, [r4, #0xc]
08004105 ldr      r0, [sp, #0x14]
08004107 adds     r5, #1
08004109 subs     r2, r3, r0
0800410b cmp      r2, r5
0800410d ble      #0x8004133
