080022e7 pop      {r0, r1, r2, r3, r4, r5, r6, pc}
