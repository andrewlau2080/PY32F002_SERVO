080040ab ldr      r3, [r4]
080040ad lsls     r1, r3, #0x18
080040af bmi      #0x80040b7
080040b1 lsls     r3, r3, #0x19
080040b3 bpl      #0x80040b7
080040b5 b        #0x80042bb
080040b7 ldr      r3, [r2]
080040b9 adds     r1, r3, #4
080040bb str      r1, [r2]
080040bd ldr      r3, [r3]
080040bf ldr      r2, [r4, #0x14]
080040c1 str      r2, [r3]
080042bb ldr      r3, [r2]
080042bd ldr      r1, [r4, #0x14]
080042bf adds     r0, r3, #4
080042c1 str      r0, [r2]
080042c3 ldr      r3, [r3]
080042c5 strh     r1, [r3]
080042c7 b        #0x80040c3
