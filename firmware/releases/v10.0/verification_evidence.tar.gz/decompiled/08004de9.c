void sub_8004de9(unsigned int a0, unsigned int a1, unsigned int a2, unsigned int a3)
{
}
