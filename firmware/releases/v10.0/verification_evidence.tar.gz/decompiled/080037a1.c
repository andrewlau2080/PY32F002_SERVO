extern unsigned int g_2000032c;
extern unsigned int g_20000428;
extern char g_2000043c;

unsigned int sub_80037a1(void)
{
    unsigned int v0;  // r4
    unsigned int v1;  // r0
    unsigned int v2;  // r0

    if (!(*(int *)0x40013800 & 47))
        return v2;
    if (*(int *)0x40013800 * 0x4000000 < 0)
    {
        v0 = *(int *)0x40013804 & 0xff;
        v1 = sub_80000ed(v0);
        g_2000043c = v0;
        g_20000428 = g_20000428 + 1;
    }
    if (!(*(int *)0x40013800 * 0x10000000))
        return v1;
    g_2000032c = g_2000032c + 1;
    return v1;
}
