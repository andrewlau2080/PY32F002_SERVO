int sub_800400b(void)
{
    unsigned int *v0;  // r4
    unsigned int *v1;  // r10
    int v2;  // r8

    if ((int)(v0[3] - *v1) > v2 + 1)
        goto LABEL_0x800401d;
    if ((int)(*v0 * 0x4000000) < 0)
        goto LABEL_0x8003fa3;
}
