void sub_8002221(int a0, int a1, int a2, int a3)
{
    unsigned int v4;  // r4
    unsigned int v5;  // lr
    char v0;  // [bp-0x38]
    unsigned int v1;  // [bp-0x8]
    unsigned int v2;  // [bp-0x4]
    unsigned short v3;  // [bp+0x0]

    v1 = v4;
    v2 = v5;
    sub_8003a1d(&v0, 48, "fill %u,%u,%u,%u,%u", a0, a1, a2, a3, v3); /* do not return */
}
