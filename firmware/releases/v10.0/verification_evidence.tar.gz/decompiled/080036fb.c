extern unsigned short g_200001a8;
extern unsigned short g_200003d8;
extern char g_200003da;
extern unsigned short g_200003dc;
extern unsigned int g_40014410;
extern unsigned int g_50000018;
extern unsigned int g_50000028;
extern unsigned int g_50000418;
extern unsigned int g_50000428;

void sub_80036fb(void)
{
    unsigned int v0;  // r0
    unsigned int v1;  // r0

    if (!(g_40014410 & 1))
        return;
    g_40014410 = g_40014410 & ~1;
    g_200003dc = g_200003dc + 20;
    if (g_200003dc >= g_200001a8)
        g_200003dc = 0;
    if (!g_200003da || !g_200003d8)
    {
LABEL_800373d:
        g_50000028 = 2;
        g_50000028 = 4;
    }
    else
    {
        v0 = g_200003d8;
        if (0 > g_200003d8)
            v0 = -g_200003d8 & 0xffff;
        v1 = sub_8004671(v0 * g_200001a8, 1000);
        if (v1 <= g_200003dc)
            goto LABEL_800373d;
        if ((short)g_200003d8 > 0)
        {
            g_50000028 = 2;
            g_50000028 = 4;
            g_50000018 = 64;
            g_50000418 = 1;
            return;
        }
        g_50000018 = 2;
        g_50000018 = 4;
    }
    g_50000028 = 64;
    g_50000428 = 1;
    return;
}
