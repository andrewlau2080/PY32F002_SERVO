080038f9 push     {r4, r5, r6, r7, lr}
080038fb movs     r5, r0
080038fd lsls     r3, r0, #0x1e
080038ff beq      #0x8003995
08003901 subs     r4, r2, #1
08003903 cmp      r2, #0
08003905 beq      #0x8003993
08003907 movs     r3, r0
08003909 movs     r6, #3
0800390b uxtb     r2, r1
0800390d b        #0x8003915
0800390f adds     r5, #1
08003911 subs     r4, #1
08003913 blo      #0x8003993
08003915 adds     r3, #1
08003917 strb     r2, [r5]
08003919 tst      r3, r6
0800391b bne      #0x800390f
0800391d cmp      r4, #3
0800391f bls      #0x8003983
08003921 movs     r2, #0xff
08003923 ands     r2, r1
08003925 lsls     r5, r2, #8
08003927 orrs     r5, r2
08003929 lsls     r2, r5, #0x10
0800392b orrs     r5, r2
0800392d cmp      r4, #0xf
0800392f bls      #0x800399b
08003931 movs     r7, r4
08003933 subs     r7, #0x10
08003935 lsrs     r7, r7, #4
08003937 lsls     r6, r7, #4
08003939 mov      ip, r6
0800393b movs     r6, r3
0800393d movs     r2, r3
0800393f adds     r6, #0x10
08003941 add      r6, ip
08003943 str      r5, [r2]
08003945 str      r5, [r2, #4]
08003947 str      r5, [r2, #8]
08003949 str      r5, [r2, #0xc]
0800394b adds     r2, #0x10
0800394d cmp      r2, r6
0800394f bne      #0x8003943
08003951 adds     r7, #1
08003953 lsls     r7, r7, #4
08003955 adds     r3, r3, r7
08003957 movs     r7, #0xf
08003959 movs     r2, #0xc
0800395b ands     r7, r4
0800395d ands     r2, r4
0800395f movs     r4, r7
08003961 cmp      r2, #0
08003963 beq      #0x8003983
08003965 subs     r6, r7, #4
08003967 lsrs     r6, r6, #2
08003969 lsls     r4, r6, #2
0800396b mov      ip, r4
0800396d movs     r2, r3
0800396f adds     r4, r3, #4
08003971 add      r4, ip
08003973 stm      r2!, {r5}
08003975 cmp      r2, r4
08003977 bne      #0x8003973
08003979 movs     r4, #3
0800397b adds     r6, #1
0800397d lsls     r6, r6, #2
0800397f adds     r3, r3, r6
08003981 ands     r4, r7
08003983 cmp      r4, #0
08003985 beq      #0x8003993
08003987 uxtb     r1, r1
08003989 adds     r4, r3, r4
0800398b strb     r1, [r3]
0800398d adds     r3, #1
0800398f cmp      r4, r3
08003991 bne      #0x800398b
08003993 pop      {r4, r5, r6, r7, pc}
08003995 movs     r3, r0
08003997 movs     r4, r2
08003999 b        #0x800391d
0800399b movs     r7, r4
0800399d b        #0x8003965
