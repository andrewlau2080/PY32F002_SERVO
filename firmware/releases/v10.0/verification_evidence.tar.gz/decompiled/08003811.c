void sub_8003811(void)
{
    sub_8002771();
    return;
}
