08002daf adds     r4, #1
08002db1 add      r0, sp, #0x7c
08002db3 bl       #0x80021d5
08002db7 cmp      r4, #0x40
08002db9 bne      #0x8002da3
08002dbb ldr      r0, [pc, #0x224]
08002dbd bl       #0x80021d5
08002dc1 movs     r1, #0x64
08002dc3 movs     r3, #0x32
08002dc5 add      r2, sp, #0x38
08002dc7 adds     r2, r2, r1
08002dc9 strh     r3, [r2]
08002dcb adds     r1, #0xa
08002dcd add      r2, sp, #0x38
08002dcf adds     r3, #0xcd
08002dd1 adds     r2, r2, r1
08002dd3 strb     r3, [r2]
08002dd5 ldr      r3, [pc, #0x1c8]
08002dd7 ldr      r1, [pc, #0x20c]
08002dd9 adds     r3, #0x7b
08002ddb ldrb     r3, [r3]
08002ddd cmp      r3, #0
08002ddf beq      #0x8002de3
08002de1 ldr      r1, [pc, #0x204]
08002de3 movs     r0, #0x6f
08002de5 add      r3, sp, #0x38
08002de7 adds     r0, r0, r3
08002de9 bl       #0x8003aa1
08002ded add      r0, sp, #0x9c
08002def bl       #0x80024b1
