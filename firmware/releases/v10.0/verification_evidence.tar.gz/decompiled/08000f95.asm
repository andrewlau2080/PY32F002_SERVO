08000f95 push     {r0, r1, r2, r4, r5, r6, r7, lr}
08000f97 ldr      r4, [pc, #0xc0]
08000f99 movs     r5, r0
08000f9b movs     r3, r4
08000f9d adds     r3, #0x85
08000f9f ldrb     r3, [r3]
08000fa1 movs     r7, r2
08000fa3 cmp      r3, #0x20
08000fa5 bne      #0x8001027
08000fa7 cmp      r0, #0
08000fa9 beq      #0x8001027
08000fab movs     r2, #0x80
08000fad ldr      r3, [r4, #0x50]
08000faf lsls     r2, r2, #5
08000fb1 cmp      r3, r2
08000fb3 bne      #0x8000fbf
08000fb5 ldr      r2, [r4, #0x58]
08000fb7 cmp      r2, #0
08000fb9 bne      #0x8000fbf
08000fbb lsls     r2, r0, #0x1f
08000fbd bmi      #0x8001027
08000fbf movs     r2, r4
08000fc1 movs     r0, r4
08000fc3 adds     r2, #0x48
08000fc5 str      r2, [sp, #4]
08000fc7 adds     r0, #0x84
08000fc9 ldrb     r6, [r0]
08000fcb cmp      r6, #1
08000fcd beq      #0x8001027
08000fcf movs     r6, #1
08000fd1 strb     r6, [r0]
08000fd3 movs     r0, r4
08000fd5 movs     r6, #0
08000fd7 adds     r0, #0x88
08000fd9 str      r6, [r0]
08000fdb movs     r0, r4
08000fdd adds     r0, #0x85
08000fdf movs     r2, r0
08000fe1 movs     r0, #0x21
08000fe3 strb     r0, [r2]
08000fe5 ldr      r2, [sp, #4]
08000fe7 ldr      r0, [pc, #0x74]
08000fe9 strh     r1, [r2, #0x30]
08000feb ldr      r0, [r0, #0x20]
08000fed strh     r1, [r2, #0x32]
08000fef movs     r2, #0x80
08000ff1 str      r0, [sp]
08000ff3 lsls     r2, r2, #5
08000ff5 cmp      r3, r2
08000ff7 bne      #0x8001003
08000ff9 ldr      r3, [r4, #0x58]
08000ffb cmp      r3, r6
08000ffd bne      #0x8001003
08000fff movs     r6, r5
08001001 movs     r5, r3
08001003 movs     r3, r4
08001005 adds     r3, #0x48
08001007 ldrh     r3, [r3, #0x32]
08001009 movs     r2, r7
0800100b ldr      r1, [sp]
0800100d cmp      r3, #0
0800100f bne      #0x8001029
08001011 movs     r0, #0x40
08001013 bl       #0x8000d15
08001017 cmp      r0, #0
08001019 bne      #0x8001027
0800101b movs     r3, r4
0800101d movs     r2, #0x20
0800101f adds     r3, #0x85
08001021 adds     r4, #0x84
08001023 strb     r2, [r3]
08001025 strb     r0, [r4]
08001027 pop      {r0, r1, r2, r4, r5, r6, r7, pc}
08001029 movs     r0, #0x80
0800102b bl       #0x8000d15
0800102f cmp      r0, #0
08001031 bne      #0x8001027
08001033 ldr      r2, [r4, #0x48]
08001035 cmp      r5, #0
08001037 bne      #0x8001051
08001039 ldrh     r3, [r6]
0800103b adds     r6, #2
0800103d lsls     r3, r3, #0x17
0800103f lsrs     r3, r3, #0x17
08001041 str      r3, [r2, #4]
08001043 movs     r2, r4
08001045 adds     r2, #0x48
08001047 ldrh     r3, [r2, #0x32]
08001049 subs     r3, #1
0800104b uxth     r3, r3
0800104d strh     r3, [r2, #0x32]
0800104f b        #0x8001003
08001051 ldrb     r3, [r5]
08001053 adds     r5, #1
08001055 str      r3, [r2, #4]
08001057 b        #0x8001043
