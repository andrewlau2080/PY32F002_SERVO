void sub_8004e29(unsigned int a0, unsigned int a1, unsigned int a2)
{
}
