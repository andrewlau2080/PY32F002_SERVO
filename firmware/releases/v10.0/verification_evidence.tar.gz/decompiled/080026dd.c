void sub_80026dd(unsigned int a0, unsigned int a1, unsigned int a2)
{
    unsigned int v0;  // r3

    sub_80021d5("ref_stop");
    if (a2 != v0 && a1 > a2)
        sub_800240d(a2, a0 + 24 * a2, 0); /* do not return */
    if (a1 <= v0)
    {
        sub_80021d5("ref_star");
        return;
    }
    sub_800240d(v0, a0 + 24 * v0, 1); /* do not return */
}
