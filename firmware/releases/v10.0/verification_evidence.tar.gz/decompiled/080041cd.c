typedef struct st_80041cd_0 {
    unsigned int field_0;
    char padding_4[65];
    char field_45;
} st_80041cd_0;

int sub_80041cd(unsigned int a0, unsigned int a1, void* *a2)
{
    st_80041cd_0 *v0;  // r4
    unsigned int v1;  // r3
    unsigned int v2;  // r6
    void* v3;  // r1

    v1 = 32 | v0->field_0;
    v0->field_0 = v1;
    v0->field_45 = 120;
    if ((int)(v1 * 0x1000000) >= 0 && (int)(v1 * 0x2000000) < 0)
    {
        v2 = *(short *)*a2;
        *a2 = *a2 + 4;
    }
    else
    {
        v3 = *a2;
        *a2 = v3 + 4;
        v2 = *(int *)v3;
    }
    if (v1 & 1)
        v0->field_0 = v1 | 32;
    if (v2)
        goto LABEL_0x8004209;
    v0->field_0 = v0->field_0 & ~32;
}
