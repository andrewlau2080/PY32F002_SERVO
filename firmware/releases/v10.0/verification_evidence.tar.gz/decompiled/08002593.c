void sub_8002593(void)
{
    unsigned int v1;  // r5
    int v0;  // [bp+0x14]

    if (v1 != 5)
        goto LABEL_0x8002569;
    v0 = "P10";
    sub_800477d(0, 5);
    sub_800224d((sub_8004671(0, 5) & 0xff) * 232 + 0x22 & 0xffff, 239, 180, 28, 0, 0xfffe, 1, v0); /* do not return */
}
