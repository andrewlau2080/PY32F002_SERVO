int sub_8004119(unsigned int a0, unsigned int a1, unsigned int a2, unsigned int a3, unsigned int a4, unsigned int a5, unsigned int a6, unsigned int a7, unsigned int a8, unsigned int a9)
{
    if (a0 == 0xffffffff)
        goto LABEL_0x800411d;
    return sub_8004103(a0, a1, a2, a0 + 1, a4, a5, a6, a7, a8, a9);
}
