void* sub_800459d(unsigned int *a0, void* a1, unsigned int a2)
{
    void* v0;  // r0

    if (!a1)
    {
        return sub_80044d9(a0, a2);
    }
    else if (!a2)
    {
        sub_8004419(a0, a1);
        return NULL;
    }
    else if (sub_8004619() >= a2)
    {
        return a1;
    }
    else
    {
        v0 = sub_80044d9(a0, a2);
        if (v0)
        {
            sub_8003855(v0, a1, a2);
            sub_8004419(a0, a1);
            return v0;
        }
        return v0;
    }
}
