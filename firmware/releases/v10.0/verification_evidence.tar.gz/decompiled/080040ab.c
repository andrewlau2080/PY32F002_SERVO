typedef struct st_80040ab_0 {
    unsigned int field_0;
    char padding_4[16];
    unsigned int field_14;
} st_80040ab_0;

typedef struct st_80040ab_1 {
    void* field_0;
} st_80040ab_1;

int sub_80040ab(unsigned int a0, unsigned int a1, st_80040ab_1 **a2)
{
    st_80040ab_0 *v0;  // r4
    void* *v1;  // r3
    unsigned short v2;  // r1
    void* *v3;  // r3

    if ((int)(v0->field_0 * 0x1000000) >= 0 && (int)(v0->field_0 * 0x2000000) < 0)
    {
        v1 = *a2;
        v2 = v0->field_14;
        *a2 = v1 + 1;
        *(unsigned short *)*v1 = v2;
    }
    v3 = *a2;
    *a2 = v3 + 1;
    *(unsigned int *)*v3 = v0->field_14;
}
