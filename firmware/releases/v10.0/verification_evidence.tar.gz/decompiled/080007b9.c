extern unsigned short g_200003d8;
extern char g_200003da;
extern unsigned short g_200003dc;
extern unsigned int g_50000028;
extern unsigned int g_50000428;

int sub_80007b9(void)
{
    unsigned int v0;  // r0

    g_200003d8 = 0;
    g_200003da = 0;
    g_200003dc = 0;
    g_50000028 = 2;
    g_50000028 = 4;
    g_50000028 = 64;
    g_50000428 = 1;
    return v0;
}
