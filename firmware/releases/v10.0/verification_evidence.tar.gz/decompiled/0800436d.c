void* sub_800436d(void* a0, void* iter, unsigned int a2)
{
    unsigned int v0;  // r3
    unsigned int i;  // r3
    void* v10;  // r4
    unsigned int v12;  // r5
    unsigned int v13;  // r3
    unsigned int v14;  // r3
    unsigned int j;  // r6
    unsigned int v16;  // r3
    unsigned int v17;  // r3
    void* v3;  // r5
    unsigned int v4;  // r5
    unsigned int v5;  // r6
    unsigned int v6;  // r5
    void* v7;  // r4
    void* v8;  // r3
    void* k;  // r3

    if (a0 > iter && iter + a2 > a0)
    {
        v0 = a2 - 1;
        if (!a2)
            return a0;
        do
        {
            i = v0;
            *((char *)a0 + i) = *((char *)iter + i);
            v0 = i - 1;
        } while (1 <= i);
        return a0;
    }
    if (15 >= a2)
    {
        v3 = a0;
        goto LABEL_800438f;
    }
    else
    {
        v4 = iter | a0;
        v5 = 3 & v4;
        if (!(v4 & 3))
        {
            v6 = a2 - 16 >> 4;
            v7 = iter;
            v8 = a0;
            do
            {
                k = v8;
                *(int *)k = *(int *)v7;
                *(int *)&k[4] = (int)v7[4];
                *(int *)&k[8] = (int)v7[8];
                v10 = v7 + 16;
                *(int *)&k[12] = (int)v7[12];
                v7 = v10;
                v8 = k + 16;
            } while (k != v6 * 16 + a0);
            v12 = (v6 + 1) * 16;
            iter += v12;
            v13 = 15 & a2;
            v3 = a0 + v12;
            if (a2 & 12)
            {
                do
                {
                    *(int *)((char *)v3 + v5) = *(int *)((char *)iter + v5);
                    v5 += 4;
                } while (3 < v13 - v5);
                v14 = ((v13 - 4 >> 2) + 1) * 4;
                v3 += v14;
                iter += v14;
                a2 &= 3;
            }
            else
            {
                a2 = v13;
            }
LABEL_800438f:
            j = a2 - 1;
            if (!a2)
                return a0;
            v16 = 0;
        }
        else
        {
            v3 = a0;
            j = a2 - 1;
            v16 = 0;
        }
        do
        {
            v17 = v16;
            *((char *)v3 + v17) = *((char *)iter + v17);
            v16 = v17 + 1;
        } while (j != v17);
        return a0;
    }
}
