void* sub_80042f9(void* iter, char a1, unsigned int a2)
{
    unsigned int v0;  // r4
    unsigned int v1;  // r3
    void* node;  // r0

    v0 = a1;
    if (iter * 0x40000000)
    {
        v1 = a2 - 1;
        if (a2)
        {
            do
            {
                a2 = v1;
                if (*(char *)iter == v0)
                    return iter;
                iter += 1;
                if (!(iter & 0x3))
                    goto LABEL_800431f;
            } while ((v1 = a2 - 1, a2 >= 1));
        }
    }
    else
    {
LABEL_800431f:
        if (3 < a2)
        {
            do
            {
                if ((*(int *)iter ^ ((a1 | a1 * 0x100) * 0x10000 | a1 | a1 * 0x100)) + 0xfefefeff & ~(*(int *)iter ^ ((a1 | a1 * 0x100) * 0x10000 | a1 | a1 * 0x100)) & 0x80808080)
                    goto LABEL_800432b;
            } while ((a2 -= 4, iter += 4, 3 < a2));
        }
        if (a2)
        {
LABEL_800432b:
            node = iter;
            do
            {
                if (*(char *)node == v0)
                    return node;
            } while ((node += 1, iter + a2 != node));
        }
    }
    return NULL;
}
