void sub_8002533(unsigned int a0, unsigned int a1, unsigned int a2, unsigned int a3)
{
    sub_80023dd("M", "IN", "4", a3); /* do not return */
}
