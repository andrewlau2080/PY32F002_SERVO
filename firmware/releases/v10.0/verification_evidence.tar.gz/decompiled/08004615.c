int sub_8004615(unsigned int a0)
{
    return a0;
}
