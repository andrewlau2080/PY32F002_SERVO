080012b7 ldr      r3, [pc, #0x128]
080012b9 ldr      r2, [r3, #4]
080012bb adds     r2, #1
080012bd str      r2, [r3, #4]
080012bf ldr      r2, [sp, #0x7c]
080012c1 subs     r2, #1
080012c3 uxtb     r2, r2
080012c5 str      r2, [sp, #0x7c]
080012c7 ldr      r1, [sp, #0x7c]
080012c9 ldr      r2, [pc, #0x110]
080012cb cmp      r1, #0
080012cd beq      #0x80012d3
080012cf bl       #0x8001d4d
080012d3 ldr      r2, [r2, #0x20]
080012d5 str      r2, [r3, #4]
