typedef struct st_8004419_0 {
    unsigned int field_0;
    struct st_8004419_0 *field_4;
} st_8004419_0;

extern unsigned int g_200007a8;

void sub_8004419(unsigned int *a0, void* a1)
{
    st_8004419_0 *iter;  // r4
    st_8004419_0 *node;  // r3
    st_8004419_0 *v2;  // r3
    st_8004419_0 *v3;  // r2
    st_8004419_0 *v4;  // r1
    st_8004419_0 *v5;  // r0
    st_8004419_0 *v6;  // r3
    unsigned int v7;  // r1
    st_8004419_0 *v8;  // r3

    if (!a1)
        return;
    iter = a1 - 4;
    if ((int)iter->field_0 < NULL)
        iter = (char *)iter + iter->field_0;
    sub_8004611(a0);
    node = g_200007a8;
    if (g_200007a8)
    {
        if (g_200007a8 <= iter)
        {
            while (1)
            {
                v3 = node;
                node = node->field_4;
                if (!node)
                {
                    v4 = (char *)v3 + v3->field_0;
                    if (iter == v4)
                    {
                        v3->field_0 = iter->field_0 + v3->field_0;
                        sub_8004615(a0);
                        return;
                    }
                    if (iter < v4)
                    {
                        *a0 = 12;
                        sub_8004615(a0);
                        return;
                    }
                }
                else if (iter < node)
                {
                    v5 = (char *)v3 + v3->field_0;
                    if (v5 == iter)
                    {
                        v7 = v3->field_0 + iter->field_0;
                        v3->field_0 = v7;
                        if (node == (char *)v3 + v7)
                        {
                            v8 = node->field_4;
                            v3->field_0 = v7 + node->field_0;
                            v3->field_4 = v8;
                            sub_8004615(a0);
                            return;
                        }
                        sub_8004615(a0);
                        return;
                    }
                    else if (v5 > iter)
                    {
                        *a0 = 12;
                        sub_8004615(a0);
                        return;
                    }
                    else if (node == (char *)iter + iter->field_0)
                    {
                        v6 = node->field_4;
                        iter->field_0 = iter->field_0 + node->field_0;
                        iter->field_4 = v6;
                        v3->field_4 = iter;
                        sub_8004615(a0);
                        return;
                    }
                    iter->field_4 = node;
                    v3->field_4 = iter;
                    sub_8004615(a0);
                    return;
                }
            }
        }
        if (g_200007a8 != (char *)iter + iter->field_0)
            goto LABEL_8004443;
        v2 = *(int *)(g_200007a8 + 4);
        iter->field_0 = iter->field_0 + *(int *)g_200007a8;
        iter->field_4 = v2;
    }
    else
    {
LABEL_8004443:
        iter->field_4 = g_200007a8;
    }
    g_200007a8 = iter;
    sub_8004615(a0);
    return;
}
