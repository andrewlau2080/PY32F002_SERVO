08004237 movs     r3, #0x45
08004239 movs     r1, #0x58
0800423b strb     r1, [r4, r3]
0800423d ldr      r3, [r4]
0800423f ldr      r1, [pc, #0xb0]
08004241 mov      fp, r1
08004243 lsls     r1, r3, #0x18
08004245 bpl      #0x80041e3
