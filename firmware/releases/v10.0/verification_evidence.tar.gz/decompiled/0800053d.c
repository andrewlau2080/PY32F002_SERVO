typedef struct st_800053d_0 {
    unsigned short field_0;
    unsigned short field_2;
    unsigned short field_4;
    char field_6;
    char padding_7[1];
    unsigned int field_8;
    unsigned int field_c;
    unsigned int field_10;
    unsigned int field_14;
    char field_18;
    char field_19;
} st_800053d_0;

extern unsigned short g_2000002c;
extern unsigned short g_2000002e;
extern unsigned short g_20000030;
extern unsigned int g_20000384;
extern unsigned int g_2000038c;
extern char g_20000390;
extern char g_20000391;
extern unsigned int g_20000394;
extern unsigned int g_20000398;

st_800053d_0 * sub_800053d(st_800053d_0 *a0, unsigned int a1)
{
    unsigned short v2;  // 4127
    unsigned short v3;  // 4130
    unsigned int v0;  // [bp-0x20]
    unsigned int v1;  // [bp-0x1c]

    v2 = g_2000002c;
    v3 = g_20000030;
    v0 = g_20000384;
    v1 = g_20000398;
    a0->field_6 = g_20000391;
    a0->field_18 = *(int *)0x50000010 * 0x10000000 >> 31;
    a0->field_8 = g_2000038c;
    a0->field_0 = g_2000002e;
    a0->field_10 = v0;
    a0->field_2 = v2;
    a0->field_c = g_20000394;
    a0->field_4 = v3;
    a0->field_14 = v1;
    a0->field_19 = g_20000390 - (g_20000390 - 1) - (1 > g_20000390);
    return a0;
}
