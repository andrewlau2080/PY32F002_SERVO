void sub_80024f5(void)
{
    unsigned int v1;  // r4
    unsigned int v0;  // [bp+0x0]

    v0 = v1;
    sub_80022f1(1, "T", "--", 31);
}
