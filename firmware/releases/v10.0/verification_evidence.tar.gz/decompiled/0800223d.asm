0800223d add      r0, sp, #0x10
0800223f bl       #0x80021d5
08002243 add      sp, #0x40
08002245 pop      {r4, pc}
