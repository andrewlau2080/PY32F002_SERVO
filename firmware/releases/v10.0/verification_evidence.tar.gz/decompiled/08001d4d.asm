08001d4d ldr      r3, [r2, #0x20]
08001d4f bl       #0x80010cf
