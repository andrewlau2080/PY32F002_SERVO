extern unsigned int g_50000028;

void sub_8000a9d(void)
{
    unsigned int v2;  // r4
    unsigned int v3;  // lr
    unsigned int v0;  // [bp-0x8]
    unsigned int v1;  // [bp-0x4]

    v0 = v2;
    v1 = v3;
    sub_80007b9();
    sub_8000a5d();
    g_50000028 = 32;
    while (1)
    ;
}
