int sub_80035e9(void)
{
}
