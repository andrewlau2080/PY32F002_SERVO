void sub_8000155(void)
{
    if (!*0x200002e4)
        return;
    sub_8000115();
    while (*(int *)0x40013800 & 32)
    {
        sub_80000ed(*(int *)0x40013804 & 0xff);
        sub_8000115();
    }
    return;
}
