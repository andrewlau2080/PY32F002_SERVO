extern unsigned int g_50000018;

unsigned int sub_80003d1(void)
{
    unsigned int v0;  // r0

    v0 = sub_800477d(*0x20000340, 500);
    g_50000018 = 32;
    return v0;
}
