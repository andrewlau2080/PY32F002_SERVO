void sub_80023ef(unsigned int a0, unsigned int a1, unsigned int a2, unsigned int a3)
{
    unsigned int v0;  // r5

    sub_80023a9(160, v0, 16, a3); /* do not return */
}
