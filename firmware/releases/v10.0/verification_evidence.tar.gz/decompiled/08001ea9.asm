08001ea9 push     {r4, r5, r6, r7, lr}
08001eab ldr      r4, [pc, #0x230]
08001ead sub      sp, #0x2c
08001eaf movs     r3, r4
08001eb1 adds     r3, #0x44
08001eb3 ldrb     r3, [r3]
08001eb5 cmp      r3, #0
08001eb7 beq      #0x8001ee1
08001eb9 movs     r2, r4
08001ebb movs     r3, #0x24
08001ebd ldr      r1, [r4, #0x48]
08001ebf adds     r2, #0x85
08001ec1 strb     r3, [r2]
08001ec3 ldr      r3, [r1, #0xc]
08001ec5 ldr      r5, [pc, #0x218]
08001ec7 ands     r3, r5
08001ec9 str      r3, [r1, #0xc]
08001ecb movs     r1, r4
08001ecd movs     r3, #0
08001ecf adds     r1, #0x88
08001ed1 str      r3, [r1]
08001ed3 strb     r3, [r2]
08001ed5 movs     r2, r4
08001ed7 adds     r2, #0x86
08001ed9 strb     r3, [r2]
08001edb movs     r2, r4
08001edd adds     r2, #0x84
08001edf strb     r3, [r2]
08001ee1 movs     r3, #0
08001ee3 movs     r2, #0xc
08001ee5 str      r3, [r4, #0x50]
08001ee7 str      r3, [r4, #0x54]
08001ee9 str      r3, [r4, #0x58]
08001eeb str      r3, [r4, #0x60]
08001eed str      r3, [r4, #0x64]
08001eef movs     r3, r4
08001ef1 ldr      r6, [pc, #0x1f0]
08001ef3 str      r2, [r4, #0x5c]
08001ef5 str      r6, [r4, #0x48]
08001ef7 str      r0, [r4, #0x4c]
08001ef9 adds     r3, #0x85
08001efb ldrb     r3, [r3]
08001efd uxtb     r2, r3
08001eff str      r2, [sp, #4]
08001f01 cmp      r3, #0
08001f03 bne      #0x8001f6d
08001f05 movs     r3, r4
08001f07 movs     r7, #1
08001f09 movs     r5, #2
08001f0b movs     r1, #0x80
08001f0d adds     r3, #0x84
08001f0f strb     r2, [r3]
08001f11 ldr      r3, [pc, #0x1d4]
08001f13 lsls     r1, r1, #7
08001f15 ldr      r2, [r3, #0x34]
08001f17 movs     r0, #0xa0
08001f19 orrs     r2, r7
08001f1b str      r2, [r3, #0x34]
08001f1d ldr      r2, [r3, #0x34]
08001f1f lsls     r0, r0, #0x17
08001f21 ands     r2, r7
08001f23 str      r2, [sp, #0x10]
08001f25 ldr      r2, [sp, #0x10]
08001f27 ldr      r2, [r3, #0x34]
08001f29 orrs     r2, r5
08001f2b str      r2, [r3, #0x34]
08001f2d ldr      r2, [r3, #0x34]
08001f2f ands     r2, r5
08001f31 str      r2, [sp, #0xc]
08001f33 ldr      r2, [sp, #0xc]
08001f35 ldr      r2, [r3, #0x40]
08001f37 orrs     r2, r1
08001f39 str      r2, [r3, #0x40]
08001f3b ldr      r3, [r3, #0x40]
08001f3d str      r5, [sp, #0x18]
08001f3f ands     r3, r1
08001f41 str      r3, [sp, #8]
08001f43 ldr      r3, [sp, #8]
08001f45 movs     r3, #0x80
08001f47 add      r1, sp, #0x14
08001f49 str      r3, [sp, #0x14]
08001f4b subs     r3, #0x78
08001f4d str      r3, [sp, #0x24]
08001f4f str      r7, [sp, #0x1c]
08001f51 str      r5, [sp, #0x20]
08001f53 bl       #0x8000925
08001f57 movs     r3, #4
08001f59 str      r3, [sp, #0x14]
08001f5b ldr      r3, [sp, #4]
08001f5d ldr      r0, [pc, #0x18c]
08001f5f add      r1, sp, #0x14
08001f61 str      r5, [sp, #0x18]
08001f63 str      r7, [sp, #0x1c]
08001f65 str      r5, [sp, #0x20]
08001f67 str      r3, [sp, #0x24]
08001f69 bl       #0x8000925
08001f6d movs     r3, r4
08001f6f movs     r2, #0x24
08001f71 adds     r3, #0x85
08001f73 strb     r2, [r3]
08001f75 ldr      r3, [r4, #0x48]
08001f77 ldr      r1, [pc, #0x168]
08001f79 ldr      r2, [r3, #0xc]
08001f7b movs     r5, #0x19
08001f7d ands     r2, r1
08001f7f str      r2, [r3, #0xc]
08001f81 ldr      r2, [r3, #0x10]
08001f83 ldr      r0, [r4, #0x58]
08001f85 ands     r2, r1
08001f87 ldr      r1, [r4, #0x54]
08001f89 orrs     r2, r1
08001f8b str      r2, [r3, #0x10]
08001f8d ldr      r2, [r4, #0x50]
08001f8f ldr      r1, [r3, #0xc]
08001f91 orrs     r2, r0
08001f93 ldr      r0, [r4, #0x5c]
08001f95 orrs     r2, r0
08001f97 ldr      r0, [pc, #0x158]
08001f99 ands     r1, r0
08001f9b orrs     r2, r1
08001f9d str      r2, [r3, #0xc]
08001f9f ldr      r2, [r3, #0x14]
08001fa1 ldr      r0, [pc, #0x150]
08001fa3 ldr      r1, [r4, #0x64]
08001fa5 ands     r2, r0
08001fa7 orrs     r2, r1
08001fa9 str      r2, [r3, #0x14]
08001fab ldr      r2, [r3, #0x14]
08001fad ldr      r0, [pc, #0x148]
08001faf ands     r2, r0
08001fb1 ldr      r0, [r4, #0x60]
08001fb3 orrs     r2, r0
08001fb5 str      r2, [r3, #0x14]
08001fb7 movs     r3, #0x80
08001fb9 lsls     r3, r3, #4
08001fbb cmp      r1, r3
08001fbd beq      #0x8001fc1
08001fbf b        #0x80020a5
08001fc1 bl       #0x80008fd
08001fc5 ldr      r3, [r4, #0x4c]
08001fc7 muls     r0, r5, r0
08001fc9 lsls     r1, r3, #1
08001fcb bl       #0x8004671
08001fcf movs     r1, #0x64
08001fd1 movs     r7, r0
08001fd3 bl       #0x800477d
08001fd7 lsls     r0, r1, #3
08001fd9 adds     r0, #0x32
08001fdb movs     r1, #0x64
08001fdd bl       #0x8004671
08001fe1 ldr      r3, [r4, #0x48]
08001fe3 movs     r5, r0
08001fe5 movs     r1, #0x64
08001fe7 movs     r0, r7
08001fe9 str      r3, [sp, #4]
08001feb bl       #0x8004671
08001fef lsls     r3, r0, #4
08001ff1 movs     r0, #7
08001ff3 ands     r0, r5
08001ff5 adds     r3, r3, r0
08001ff7 movs     r0, #0xf8
08001ff9 lsls     r5, r5, #1
08001ffb lsls     r0, r0, #1
08001ffd ands     r5, r0
08001fff adds     r5, r3, r5
08002001 ldr      r3, [sp, #4]
08002003 str      r5, [r3, #8]
08002005 ldr      r2, [r4, #0x68]
08002007 ldr      r3, [r4, #0x48]
08002009 cmp      r2, #0
0800200b beq      #0x8002031
0800200d lsls     r2, r2, #0x19
0800200f bpl      #0x8002031
08002011 ldr      r2, [r3, #0x14]
08002013 ldr      r0, [pc, #0xe8]
08002015 ldr      r1, [r4, #0x6c]
08002017 ands     r2, r0
08002019 orrs     r2, r1
0800201b str      r2, [r3, #0x14]
0800201d movs     r2, #0x80
0800201f lsls     r2, r2, #5
08002021 cmp      r1, r2
08002023 bne      #0x8002031
08002025 ldr      r2, [r3, #0x14]
08002027 ldr      r1, [pc, #0xd8]
08002029 ands     r2, r1
0800202b ldr      r1, [r4, #0x70]
0800202d orrs     r2, r1
0800202f str      r2, [r3, #0x14]
08002031 ldr      r2, [r3, #0x10]
08002033 ldr      r1, [pc, #0xc0]
08002035 movs     r0, r4
08002037 ands     r2, r1
08002039 movs     r1, #8
0800203b str      r2, [r3, #0x10]
0800203d ldr      r2, [r3, #0x14]
0800203f adds     r0, #0x44
08002041 bics     r2, r1
08002043 str      r2, [r3, #0x14]
08002045 movs     r2, #0x80
08002047 ldr      r1, [r3, #0xc]
08002049 lsls     r2, r2, #6
0800204b orrs     r2, r1
0800204d str      r2, [r3, #0xc]
0800204f movs     r3, r4
08002051 movs     r1, #0
08002053 movs     r2, r4
08002055 adds     r3, #0x88
08002057 str      r1, [r3]
08002059 movs     r3, #0x20
0800205b adds     r2, #0x85
0800205d strb     r3, [r2]
0800205f movs     r2, r4
08002061 adds     r2, #0x86
08002063 strb     r3, [r2]
08002065 movs     r2, #1
08002067 strb     r2, [r0]
08002069 mrs      r0, primask
0800206d cpsid    i
0800206f strb     r1, [r4]
08002071 strb     r1, [r4, #1]
08002073 ldr      r4, [pc, #0x90]
08002075 strb     r1, [r4, #0xc]
08002077 msr      primask, r0
0800207b movs     r0, #0xc6
0800207d ldr      r1, [r6, #0xc]
0800207f lsls     r0, r0, #2
08002081 orrs     r3, r1
08002083 movs     r1, #0x80
08002085 str      r3, [r6, #0xc]
08002087 ldr      r3, [r6, #0x14]
08002089 lsls     r1, r1, #0x17
0800208b orrs     r2, r3
0800208d str      r2, [r6, #0x14]
0800208f ldr      r2, [pc, #0x78]
08002091 ldr      r3, [r2, r0]
08002093 lsls     r3, r3, #8
08002095 lsrs     r3, r3, #8
08002097 orrs     r3, r1
08002099 str      r3, [r2, r0]
0800209b movs     r3, #0x80
0800209d lsls     r3, r3, #0x14
0800209f str      r3, [r2]
080020a1 add      sp, #0x2c
080020a3 pop      {r4, r5, r6, r7, pc}
080020a5 bl       #0x80008fd
080020a9 ldr      r3, [r4, #0x4c]
080020ab muls     r0, r5, r0
080020ad lsls     r1, r3, #2
080020af bl       #0x8004671
080020b3 movs     r1, #0x64
080020b5 movs     r5, r0
080020b7 bl       #0x800477d
080020bb lsls     r0, r1, #4
080020bd adds     r0, #0x32
080020bf movs     r1, #0x64
080020c1 bl       #0x8004671
080020c5 movs     r1, #0x64
080020c7 str      r0, [sp, #4]
080020c9 movs     r0, r5
080020cb bl       #0x8004671
080020cf ldr      r3, [sp, #4]
080020d1 ldr      r7, [r4, #0x48]
080020d3 lsls     r0, r0, #4
080020d5 adds     r0, r3, r0
080020d7 str      r0, [r7, #8]
080020d9 b        #0x8002005
