unsigned int sub_80000c1(unsigned int a0)
{
    unsigned int v0;  // r3
    unsigned int i;  // r2
    unsigned int v2;  // r1

    v0 = 0;
    for (i = *(int *)0xe000e018; v0 < a0; i = v2)
    {
        v2 = *(int *)0xe000e018;
        v0 = (i < (unsigned int)*(int *)0xe000e018 ? i + *(int *)0xe000e014 + 1 - *(int *)0xe000e018 + v0 : v0 + i - *(int *)0xe000e018);
    }
    return a0;
}
