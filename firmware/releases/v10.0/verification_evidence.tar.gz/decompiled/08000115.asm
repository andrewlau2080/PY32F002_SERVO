08000115 ldr      r3, [pc, #0x30]
08000117 sub      sp, #8
08000119 movs     r2, r3
0800011b adds     r2, #0x44
0800011d ldrb     r2, [r2]
0800011f cmp      r2, #0
08000121 beq      #0x8000145
08000123 ldr      r2, [pc, #0x28]
08000125 ldr      r1, [r2]
08000127 str      r1, [sp]
08000129 ldr      r1, [sp]
0800012b lsls     r1, r1, #0x1c
0800012d beq      #0x8000145
0800012f ldr      r2, [r2, #4]
08000131 adds     r3, #0x88
08000133 str      r2, [sp, #4]
08000135 ldr      r2, [sp]
08000137 ldr      r2, [sp, #4]
08000139 movs     r2, #0
0800013b str      r2, [r3]
0800013d ldr      r2, [pc, #0x10]
0800013f ldr      r3, [r2, #0xc]
08000141 adds     r3, #1
08000143 str      r3, [r2, #0xc]
08000145 add      sp, #8
08000147 bx       lr
