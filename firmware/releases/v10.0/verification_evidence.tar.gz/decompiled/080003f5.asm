080003f5 push     {r0, r1, r2, r4, r5, r6, r7, lr}
080003f7 movs     r4, #2
080003f9 ldr      r3, [pc, #0x12c]
080003fb ldr      r1, [pc, #0x130]
080003fd ldr      r2, [r3, #0x20]
080003ff str      r2, [sp, #4]
08000401 ldr      r2, [r1, #0x10]
08000403 tst      r2, r4
08000405 beq      #0x8000453
08000407 movs     r6, r3
08000409 ldr      r2, [r1, #0x10]
0800040b adds     r6, #0x68
0800040d bics     r2, r4
0800040f str      r2, [r1, #0x10]
08000411 ldr      r5, [r1, #0x34]
08000413 ldr      r2, [r3, #0x64]
08000415 movs     r7, r6
08000417 adds     r2, #1
08000419 str      r2, [r3, #0x64]
0800041b ldrb     r2, [r6]
0800041d uxth     r5, r5
0800041f cmp      r2, #0
08000421 bne      #0x8000455
08000423 movs     r2, r3
08000425 adds     r2, #0x69
08000427 ldrb     r2, [r2]
08000429 cmp      r2, #0
0800042b beq      #0x8000439
0800042d movs     r2, r3
0800042f adds     r2, #0x6a
08000431 ldrh     r2, [r2]
08000433 subs     r2, r5, r2
08000435 uxth     r2, r2
08000437 str      r2, [r3, #0x6c]
08000439 movs     r2, r3
0800043b movs     r0, r3
0800043d adds     r2, #0x6a
0800043f strh     r5, [r2]
08000441 movs     r2, #1
08000443 adds     r3, #0x68
08000445 adds     r0, #0x69
08000447 strb     r2, [r0]
08000449 strb     r2, [r3]
0800044b movs     r3, #2
0800044d ldr      r2, [r1, #0x20]
0800044f orrs     r3, r2
08000451 str      r3, [r1, #0x20]
08000453 pop      {r0, r1, r2, r4, r5, r6, r7, pc}
08000455 movs     r2, r3
08000457 movs     r6, #0
08000459 adds     r2, #0x6a
0800045b ldrh     r2, [r2]
0800045d strb     r6, [r7]
0800045f mov      ip, r6
08000461 ldr      r6, [r1, #0x20]
08000463 uxth     r0, r2
08000465 subs     r2, r5, r2
08000467 bics     r6, r4
08000469 uxth     r2, r2
0800046b str      r6, [r1, #0x20]
0800046d movs     r1, r2
0800046f movs     r4, #0x96
08000471 subs     r1, #0x2d
08000473 subs     r1, #0xff
08000475 uxth     r1, r1
08000477 lsls     r4, r4, #4
08000479 cmp      r1, r4
0800047b bhi      #0x8000453
0800047d ldr      r1, [r3, #0x6c]
0800047f cmp      r2, r1
08000481 bhs      #0x8000453
08000483 movs     r1, #0xfa
08000485 ldr      r4, [r3, #0x6c]
08000487 lsls     r1, r1, #1
08000489 cmp      r4, r1
0800048b blo      #0x8000453
0800048d ldr      r1, [r3, #0x6c]
0800048f ldr      r6, [pc, #0xa0]
08000491 cmp      r1, r6
08000493 bhi      #0x8000453
08000495 movs     r1, r3
08000497 ldr      r4, [pc, #0x9c]
08000499 adds     r1, #0x70
0800049b strh     r2, [r4, #0x2c]
0800049d ldrb     r1, [r1]
0800049f cmp      r1, ip
080004a1 beq      #0x80004d1
080004a3 ldrh     r1, [r4, #0x2e]
080004a5 mov      ip, r1
080004a7 uxth     r1, r1
080004a9 cmp      r2, ip
080004ab blo      #0x800051b
080004ad subs     r1, r2, r1
080004af uxth     r1, r1
080004b1 cmp      r1, #8
080004b3 bls      #0x80004d1
080004b5 movs     r1, r3
080004b7 adds     r1, #0x71
080004b9 ldrb     r1, [r1]
080004bb cmp      r1, #0
080004bd beq      #0x80004e5
080004bf ldrh     r1, [r4, #0x30]
080004c1 mov      ip, r1
080004c3 uxth     r1, r1
080004c5 cmp      r2, ip
080004c7 blo      #0x8000521
080004c9 subs     r5, r2, r1
080004cb uxth     r5, r5
080004cd cmp      r5, #8
080004cf bhi      #0x80004e5
080004d1 ldrh     r1, [r4, #0x32]
080004d3 cmp      r2, r1
080004d5 bhs      #0x80004d9
080004d7 strh     r2, [r4, #0x32]
080004d9 movs     r1, r3
080004db adds     r1, #0x72
080004dd ldrh     r0, [r1]
080004df cmp      r2, r0
080004e1 bls      #0x80004e5
080004e3 strh     r2, [r1]
080004e5 ldr      r0, [r3, #0x6c]
080004e7 ldr      r1, [pc, #0x50]
080004e9 cmp      r0, r1
080004eb bls      #0x8000453
080004ed ldr      r1, [r3, #0x6c]
080004ef cmp      r1, r6
080004f1 bhi      #0x8000453
080004f3 movs     r1, r3
080004f5 movs     r0, #0
080004f7 adds     r1, #0x71
080004f9 strh     r2, [r4, #0x2e]
080004fb strh     r2, [r4, #0x30]
080004fd strb     r0, [r1]
080004ff movs     r1, r3
08000501 adds     r0, #1
08000503 adds     r1, #0x70
08000505 strb     r0, [r1]
08000507 movs     r1, r3
08000509 adds     r1, #0x72
0800050b strh     r2, [r4, #0x32]
0800050d strh     r2, [r1]
0800050f ldr      r2, [sp, #4]
08000511 str      r2, [r3, #0x74]
08000513 ldr      r2, [r3, #0x78]
08000515 adds     r2, r2, r0
08000517 str      r2, [r3, #0x78]
08000519 b        #0x8000453
0800051b adds     r1, r0, r1
0800051d subs     r1, r1, r5
0800051f b        #0x80004af
08000521 adds     r0, r0, r1
08000523 subs     r5, r0, r5
08000525 b        #0x80004cb
