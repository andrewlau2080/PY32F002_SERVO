unsigned int sub_80007ed(char *a0)
{
    unsigned int v0;  // r2
    unsigned int v1;  // r3
    unsigned int v2;  // r1
    unsigned int v3;  // r3
    unsigned int v4;  // r1
    unsigned int v5;  // r3

    v0 = 0;
    v1 = 0xfffffffe;
    do
    {
        if (v0 >= 124 && 128 > v0)
        {
            v2 = 8;
            do
            {
                v3 = v1 >> 1;
                if (v1 & 1)
                    v3 ^= 3988292384;
            } while ((v1 = v3, v2 -= 1, v2));
        }
        else
        {
            v1 ^= a0[v0];
            v4 = 8;
            do
            {
                v5 = v1 >> 1;
                if (v1 & 1)
                    v5 ^= 3988292384;
            } while ((v1 = v5, v4 -= 1, v4));
        }
    } while ((v0 += 1, v0 != 128));
    return ~v1;
}
