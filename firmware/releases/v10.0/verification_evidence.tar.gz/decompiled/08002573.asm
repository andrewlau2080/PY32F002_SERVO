08002573 ldr      r2, [pc, #0x11c]
08002575 rsbs     r3, r3, #0
08002577 ands     r3, r2
08002579 ldr      r2, [pc, #0x118]
0800257b muls     r1, r5, r1
0800257d adds     r3, r3, r2
0800257f movs     r2, #0xde
08002581 adds     r1, #0x26
08002583 str      r3, [sp]
08002585 movs     r0, #0x12
08002587 movs     r3, #0x26
08002589 uxth     r1, r1
0800258b lsls     r2, r2, #1
0800258d adds     r5, #1
0800258f bl       #0x8002221
