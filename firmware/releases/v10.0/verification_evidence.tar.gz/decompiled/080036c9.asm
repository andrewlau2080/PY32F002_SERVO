080036c9 ldr      r2, [pc, #8]
080036cb ldr      r3, [r2, #0x20]
080036cd adds     r3, #1
080036cf str      r3, [r2, #0x20]
080036d1 bx       lr
