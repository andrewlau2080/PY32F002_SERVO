080003d1 movs     r1, #0xfa
080003d3 ldr      r3, [pc, #0x1c]
080003d5 push     {r4, lr}
080003d7 ldr      r0, [r3, #0x20]
080003d9 lsls     r1, r1, #1
080003db bl       #0x800477d
080003df movs     r3, #0xa0
080003e1 movs     r2, #0x20
080003e3 lsls     r3, r3, #0x17
080003e5 cmp      r1, #0x27
080003e7 bls      #0x80003ed
080003e9 str      r2, [r3, #0x18]
080003eb pop      {r4, pc}
080003ed str      r2, [r3, #0x28]
080003ef b        #0x80003eb
