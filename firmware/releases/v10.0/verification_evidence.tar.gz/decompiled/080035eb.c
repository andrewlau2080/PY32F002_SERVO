int sub_80035eb(void)
{
}
