typedef struct st_8003be5_0 {
    char padding_0[4];
    unsigned int field_4;
} st_8003be5_0;

typedef struct st_8003be5_1 {
    struct st_8003be5_0 *field_0;
    unsigned int field_4;
    unsigned int field_8;
} st_8003be5_1;

unsigned int sub_8003be5(unsigned int *a0, void* a1, st_8003be5_1 *a2)
{
    unsigned int v7;  // r4
    unsigned int v8;  // r5
    unsigned int v17;  // r6
    unsigned int v18;  // r8
    unsigned int v19;  // r3
    unsigned int v20;  // r11
    int v21;  // r2
    int v22;  // r0
    int v23;  // r8
    void* v24;  // r4
    int v25;  // r3
    unsigned int v26;  // r3
    unsigned int v9;  // r6
    unsigned int v10;  // r7
    unsigned int v11;  // r8
    unsigned int v12;  // r9
    unsigned int v13;  // r10
    st_8003be5_0 *iter;  // r7
    unsigned int v15;  // r0
    unsigned int v16;  // r4
    unsigned int v0;  // [bp-0x24]
    unsigned int v1;  // [bp-0x20]
    unsigned int v2;  // [bp-0x1c]
    unsigned int v3;  // [bp-0x14]
    unsigned int v4;  // [bp-0x10]
    unsigned int v5;  // [bp-0xc]
    unsigned int v6;  // [bp-0x8]

    v3 = v7;
    v4 = v8;
    v5 = v9;
    v6 = v10;
    v0 = v11;
    v1 = v12;
    v2 = v13;
    if (a2->field_8)
    {
        iter = a2->field_0;
        v15 = *(int *)a1;
        v16 = (int)a1[8];
        while (1)
        {
            v17 = iter->field_4;
            iter += 1;
            if (!v17)
                continue;
            v18 = v16;
            if (v16 <= v17)
            {
                v19 = (short)a1[12];
                if (v19 & 1152)
                {
                    v20 = v15 - (int)a1[16];
                    v21 = (int)a1[20] * 3 / 2;
                    v22 = v17 + 1 + v20;
                    v23 = v21;
                    if ((unsigned int)v22 > (unsigned int)v23)
                    {
                        v23 = v22;
                        v21 = v23;
                    }
                    if (v19 & 0x400)
                    {
                        v24 = sub_80044d9(a0, v21);
                        if (!v24)
                        {
                            *a0 = 12;
                            *(unsigned short *)&a1[12] = (short)a1[12] | 64;
                            a2->field_8 = 0;
                            a2->field_4 = 0;
                            return 0xfffffffe;
                        }
                        sub_8003855(v24, (int)a1[16], v20);
                        *(unsigned short *)&a1[12] = (short)a1[12] & 0xfffffb7f | 128;
                    }
                    else
                    {
                        v24 = sub_800459d(a0);
                        if (!v24)
                        {
                            sub_8004419(a0, (int)a1[16]);
                            *a0 = 12;
                            *(unsigned short *)&a1[12] = (short)a1[12] | 64;
                            a2->field_8 = 0;
                            a2->field_4 = 0;
                            return 0xfffffffe;
                        }
                    }
                    v25 = v23;
                    *(void* *)&a1[16] = v24;
                    v18 = v17;
                    v16 = v17;
                    *(int *)&a1[20] = v25;
                    *(void* *)a1 = v24 + v20;
                    *(unsigned int *)&a1[8] = v25 - v20;
                }
            }
            else
            {
                v16 = v17;
                v18 = v17;
            }
            sub_800436d();
            v16 = (int)a1[8] - v16;
            v26 = a2->field_8;
            v15 = *(int *)a1 + v18;
            *(unsigned int *)&a1[8] = v16;
            *(unsigned int *)a1 = v15;
            a2->field_8 = v26 - v17;
            if (v26 == v17)
                break;
        }
    }
    a2->field_4 = 0;
    return 0;
}
