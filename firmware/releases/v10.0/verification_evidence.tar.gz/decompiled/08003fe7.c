int sub_8003fe7(void)
{
    int v0;  // r8
    int v1;  // r5

    if (v0 <= v1 + 1)
        goto LABEL_0x8004055;
    else
        goto LABEL_0x8003fed;
}
