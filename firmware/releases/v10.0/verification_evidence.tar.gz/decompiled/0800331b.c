void sub_800331b(unsigned int a0, unsigned int a1, unsigned int a2, unsigned int a3, unsigned int a4, unsigned int a5, unsigned int a6, unsigned int a7, unsigned int a8, int a9)
{
    char v0;  // [bp+0x7c]

    sub_8002371(3, &v0, (a9 >> 31 & 63457) + 31, 63457); /* do not return */
}
