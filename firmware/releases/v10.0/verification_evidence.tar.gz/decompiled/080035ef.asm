080035ef ldr      r3, [pc, #0xa8]
080035f1 b        #0x80035db
