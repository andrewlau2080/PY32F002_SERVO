08003537 movs     r3, #2
08003539 rsbs     r3, r3, #0
0800353b strh     r3, [r7, #8]
0800353d strh     r3, [r7, #0xa]
0800353f b        #0x80032b3
