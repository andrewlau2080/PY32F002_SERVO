080024b1 push     {r4, r5, r6, r7, lr}
080024b3 movs     r5, r0
080024b5 sub      sp, #0x1c
080024b7 ldr      r0, [pc, #0x184]
080024b9 bl       #0x80021d5
080024bd ldrb     r4, [r5]
080024bf cmp      r4, #0x1e
080024c1 bne      #0x80024c5
080024c3 b        #0x800261f
080024c5 bhi      #0x8002543
080024c7 cmp      r4, #1
080024c9 beq      #0x800255d
080024cb cmp      r4, #0xd
080024cd bne      #0x80024d1
080024cf b        #0x800260b
080024d1 ldr      r3, [pc, #0x16c]
080024d3 ldr      r1, [pc, #0x170]
080024d5 adds     r3, #0x7b
080024d7 ldrb     r3, [r3]
080024d9 cmp      r3, #0
080024db beq      #0x80024df
080024dd ldr      r1, [pc, #0x168]
080024df movs     r4, #0
080024e1 ldr      r0, [pc, #0x168]
080024e3 bl       #0x8002291
08002543 cmp      r4, #0x28
08002545 bne      #0x8002549
08002547 b        #0x800262f
08002549 cmp      r4, #0x46
0800254b bne      #0x80024d1
0800254d ldrb     r3, [r5, #1]
0800254f ldr      r2, [pc, #0x12c]
08002551 str      r3, [sp]
08002553 ldr      r1, [pc, #0x12c]
08002555 movs     r3, #5
08002557 ldr      r0, [pc, #0x12c]
08002559 adds     r2, #0x30
0800255b b        #0x8002619
0800255d ldr      r1, [pc, #0x128]
0800255f ldr      r0, [pc, #0x12c]
08002561 bl       #0x8002291
0800260b ldrb     r3, [r5, #1]
0800260d ldr      r2, [pc, #0xa8]
0800260f str      r3, [sp]
08002611 movs     r3, #5
08002613 ldr      r1, [pc, #0xa8]
08002615 ldr      r0, [pc, #0xa8]
08002617 adds     r2, #0x38
08002619 bl       #0x8002469
0800261f ldrb     r3, [r5, #1]
08002621 ldr      r2, [pc, #0xa0]
08002623 str      r3, [sp]
08002625 ldr      r1, [pc, #0xa0]
08002627 movs     r3, #5
08002629 ldr      r0, [pc, #0xa0]
0800262b adds     r2, #0x40
0800262d b        #0x8002619
0800262f ldrb     r3, [r5, #1]
08002631 ldr      r2, [pc, #0x9c]
08002633 str      r3, [sp]
08002635 ldr      r1, [pc, #0x9c]
08002637 movs     r3, #6
08002639 ldr      r0, [pc, #0x9c]
0800263b b        #0x8002619
