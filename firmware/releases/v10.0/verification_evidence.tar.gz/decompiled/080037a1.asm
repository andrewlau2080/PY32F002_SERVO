080037a1 movs     r2, #0x2f
080037a3 ldr      r3, [pc, #0x30]
080037a5 push     {r4, r5, r6, lr}
080037a7 ldr      r5, [r3]
080037a9 tst      r5, r2
080037ab beq      #0x80037d1
080037ad ldr      r4, [r3, #4]
080037af lsls     r3, r5, #0x1a
080037b1 bpl      #0x80037c5
080037b3 uxtb     r4, r4
080037b5 movs     r0, r4
080037b7 bl       #0x80000ed
080037bb ldr      r3, [pc, #0x1c]
080037bd strb     r4, [r3, #0x1c]
080037bf ldr      r2, [r3, #8]
080037c1 adds     r2, #1
080037c3 str      r2, [r3, #8]
080037c5 lsls     r3, r5, #0x1c
080037c7 beq      #0x80037d1
080037c9 ldr      r2, [pc, #0x10]
080037cb ldr      r3, [r2, #0xc]
080037cd adds     r3, #1
080037cf str      r3, [r2, #0xc]
080037d1 pop      {r4, r5, r6, pc}
