08000d69 movs     r3, #0
08000d6b push     {r4, r5, r6, r7, lr}
08000d6d ldr      r4, [pc, #0xd8]
08000d6f sub      sp, #0x14
08000d71 str      r3, [sp, #0xc]
08000d73 movs     r3, r4
08000d75 adds     r3, #0x6c
08000d77 ldrb     r2, [r3]
08000d79 movs     r5, r0
08000d7b ldr      r6, [r4, #0x68]
08000d7d movs     r0, #2
08000d7f cmp      r2, #1
08000d81 beq      #0x8000de3
08000d83 subs     r0, #1
08000d85 strb     r0, [r3]
08000d87 ldr      r3, [r4, #0x40]
08000d89 movs     r2, #4
08000d8b ldr      r7, [r3, #8]
08000d8d movs     r1, r7
08000d8f ands     r1, r2
08000d91 str      r1, [sp, #4]
08000d93 tst      r7, r2
08000d95 bne      #0x8000e3d
08000d97 ldr      r7, [r5]
08000d99 ldr      r1, [pc, #0xb0]
08000d9b movs     r2, r7
08000d9d mov      ip, r1
08000d9f ldr      r1, [r5, #4]
08000da1 lsls     r0, r7
08000da3 subs     r2, #0xb
08000da5 cmp      r1, ip
08000da7 beq      #0x8000e1b
08000da9 ldr      r1, [r3, #0x28]
08000dab orrs     r0, r1
08000dad movs     r1, #0x80
08000daf str      r0, [r3, #0x28]
08000db1 lsls     r1, r1, #0x15
08000db3 cmp      r6, r1
08000db5 beq      #0x8000dd7
08000db7 subs     r6, #1
08000db9 cmp      r6, #6
08000dbb bls      #0x8000dd7
08000dbd movs     r0, #7
08000dbf ldr      r1, [r5, #8]
08000dc1 ldr      r5, [r3, #0x14]
08000dc3 ands     r5, r0
08000dc5 cmp      r1, r5
08000dc7 beq      #0x8000dd7
08000dc9 ldr      r5, [r3, #0x14]
08000dcb ands     r1, r0
08000dcd bics     r5, r0
08000dcf str      r5, [r3, #0x14]
08000dd1 ldr      r5, [r3, #0x14]
08000dd3 orrs     r1, r5
08000dd5 str      r1, [r3, #0x14]
08000dd7 cmp      r2, #1
08000dd9 bls      #0x8000de7
08000ddb movs     r0, #0
08000ddd movs     r3, #0
08000ddf adds     r4, #0x6c
08000de1 strb     r3, [r4]
08000de3 add      sp, #0x14
08000de5 pop      {r4, r5, r6, r7, pc}
08000de7 ldr      r2, [pc, #0x68]
08000de9 movs     r1, #0x80
08000deb ldr      r3, [r2]
08000ded cmp      r7, #0xb
08000def beq      #0x8000e17
08000df1 lsls     r1, r1, #0xf
08000df3 orrs     r3, r1
08000df5 str      r3, [r2]
08000df7 cmp      r7, #0xb
08000df9 bne      #0x8000ddb
08000dfb ldr      r3, [pc, #0x58]
08000dfd ldr      r1, [pc, #0x58]
08000dff ldr      r0, [r3, #0x38]
08000e01 bl       #0x8004671
08000e05 movs     r3, #0xa
08000e07 muls     r3, r0, r3
08000e09 str      r3, [sp, #0xc]
08000e0b ldr      r3, [sp, #0xc]
08000e0d cmp      r3, #0
08000e0f beq      #0x8000ddb
08000e11 ldr      r3, [sp, #0xc]
08000e13 subs     r3, #1
08000e15 b        #0x8000e09
08000e17 lsls     r1, r1, #0x10
08000e19 b        #0x8000df3
08000e1b ldr      r5, [r3, #0x28]
08000e1d bics     r5, r0
08000e1f str      r5, [r3, #0x28]
08000e21 cmp      r2, #1
08000e23 bhi      #0x8000ddb
08000e25 rsbs     r3, r2, #0
08000e27 adcs     r2, r3
08000e29 rsbs     r2, r2, #0
08000e2b ldr      r0, [pc, #0x24]
08000e2d lsrs     r2, r2, #0x16
08000e2f lsls     r3, r2, #0x16
08000e31 ldr      r2, [pc, #0x28]
08000e33 ldr      r5, [r0]
08000e35 adds     r3, r3, r2
08000e37 ands     r3, r5
08000e39 str      r3, [r0]
08000e3b b        #0x8000ddb
08000e3d movs     r3, #0x20
08000e3f ldr      r2, [r4, #0x70]
08000e41 orrs     r3, r2
08000e43 str      r3, [r4, #0x70]
08000e45 b        #0x8000ddd
