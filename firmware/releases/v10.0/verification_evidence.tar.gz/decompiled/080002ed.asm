080002ed movs     r1, #0x7f
080002ef push     {r4, r5, r6, lr}
080002f1 ldr      r4, [pc, #0xc4]
080002f3 ldr      r6, [pc, #0xc8]
080002f5 movs     r5, #0
080002f7 strb     r1, [r6, #0x12]
080002f9 movs     r1, r4
080002fb adds     r1, #0x2c
080002fd strb     r5, [r1]
080002ff movs     r1, r4
08000301 adds     r1, #0x34
08000303 strb     r5, [r1]
08000305 movs     r1, r4
08000307 movs     r3, #1
08000309 adds     r1, #0x3c
0800030b rsbs     r3, r3, #0
0800030d strb     r5, [r1]
0800030f adds     r1, r4, #2
08000311 strh     r3, [r1, #0x3e]
08000313 adds     r1, r4, #4
08000315 strh     r5, [r1, #0x3e]
08000317 movs     r1, r4
08000319 adds     r1, #0x44
0800031b strb     r5, [r1]
0800031d ldr      r1, [pc, #0xa0]
0800031f ldr      r2, [pc, #0xa4]
08000321 ldr      r1, [r1, #8]
08000323 strh     r3, [r6]
08000325 str      r1, [r6, #0x14]
08000327 movs     r1, r4
08000329 adds     r1, #8
0800032b strh     r5, [r1, #0x3e]
0800032d ldr      r1, [pc, #0x98]
0800032f strh     r3, [r6, #2]
08000331 strh     r1, [r6, #0x1c]
08000333 movs     r1, r4
08000335 adds     r1, #0x4c
08000337 strb     r5, [r1]
08000339 movs     r1, r4
0800033b adds     r1, #0x4d
0800033d str      r3, [r6, #4]
0800033f strh     r3, [r6, #8]
08000341 strh     r3, [r6, #0xa]
08000343 strh     r3, [r6, #0xc]
08000345 strh     r2, [r6, #0xe]
08000347 strh     r2, [r6, #0x10]
08000349 strb     r3, [r6, #0x13]
0800034b strh     r5, [r4, #0x38]
0800034d str      r5, [r4, #0x30]
0800034f strh     r5, [r4, #0x3a]
08000351 strh     r3, [r6, #0x18]
08000353 strh     r3, [r6, #0x1a]
08000355 str      r5, [r4, #0x48]
08000357 strh     r3, [r4, #0x3e]
08000359 strb     r5, [r1]
0800035b strh     r2, [r6, #0x26]
0800035d movs     r2, r6
0800035f adds     r2, #0x28
08000361 strh     r3, [r6, #0x1e]
08000363 strh     r3, [r6, #0x20]
08000365 strh     r3, [r6, #0x22]
08000367 strh     r3, [r6, #0x24]
08000369 strb     r3, [r2]
0800036b movs     r3, r4
0800036d adds     r3, #0x52
0800036f strb     r5, [r3]
08000371 movs     r3, r4
08000373 adds     r3, #0x53
08000375 strb     r5, [r3]
08000377 movs     r3, r4
08000379 adds     r3, #0x54
0800037b strb     r5, [r3]
0800037d movs     r3, r4
0800037f adds     r3, #0x55
08000381 strb     r5, [r3]
08000383 movs     r1, r4
08000385 movs     r3, r4
08000387 adds     r1, #0x4e
08000389 adds     r3, #0x56
0800038b strh     r5, [r1]
0800038d strb     r5, [r3]
0800038f movs     r1, r4
08000391 movs     r3, r4
08000393 adds     r1, #0x50
08000395 adds     r3, #0x57
08000397 strb     r5, [r3]
08000399 strh     r5, [r1]
0800039b bl       #0x80002d9
0800039f ldr      r3, [pc, #0x2c]
080003a1 str      r5, [r4, #0x58]
080003a3 strh     r3, [r6, #0x2a]
080003a5 movs     r3, r4
080003a7 adds     r3, #0x60
080003a9 strb     r5, [r3]
080003ab ldr      r3, [r4, #0x20]
080003ad str      r5, [r4, #0x5c]
080003af str      r3, [r4, #0x28]
080003b1 adds     r4, #5
080003b3 strb     r5, [r4, #0x1f]
080003b5 pop      {r4, r5, r6, pc}
