void sub_8002573(unsigned int a0, unsigned short a1, unsigned int a2, unsigned int a3)
{
    unsigned short v1;  // r5
    unsigned int v0;  // [bp+0x0]

    v0 = (-a3 & 0xffffefbf) + 0xffff;
    sub_8002221(18, a1 * v1 + 38 & 0xffff, 444, 38); /* do not return */
}
