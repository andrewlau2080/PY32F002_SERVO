0800244b add      sp, #0x30
0800244d pop      {r4, r5, r6, pc}
