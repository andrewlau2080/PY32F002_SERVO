080008fd ldr      r3, [pc, #0x18]
080008ff ldr      r2, [pc, #0x1c]
08000901 ldr      r3, [r3, #8]
08000903 lsls     r3, r3, #0x11
08000905 lsrs     r3, r3, #0x1d
08000907 lsls     r3, r3, #2
08000909 adds     r3, r2, r3
0800090b movs     r2, #0x1f
0800090d ldr      r3, [r3, #0x14]
0800090f ands     r3, r2
08000911 ldr      r2, [pc, #0xc]
08000913 ldr      r0, [r2, #0x38]
08000915 lsrs     r0, r3
08000917 bx       lr
