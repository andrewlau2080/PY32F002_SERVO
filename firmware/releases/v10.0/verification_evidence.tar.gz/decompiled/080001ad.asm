080001ad cmp      r2, r1
080001af bhs      #0x80001cf
080001b1 movs     r1, #0x18
080001b3 muls     r2, r1, r2
080001b5 adds     r0, r0, r2
080001b7 ldr      r2, [r0, #0x14]
080001b9 muls     r3, r2, r3
080001bb ldr      r2, [r0, #8]
080001bd adds     r3, r3, r2
080001bf ldr      r2, [r0, #0xc]
080001c1 cmp      r3, r2
080001c3 blt      #0x80001cd
080001c5 ldr      r2, [r0, #0x10]
080001c7 cmp      r2, r3
080001c9 ble      #0x80001cd
080001cb movs     r2, r3
080001cd str      r2, [r0, #8]
080001cf bx       lr
