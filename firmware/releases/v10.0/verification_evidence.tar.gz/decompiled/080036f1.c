int sub_80036f1(void)
{
    unsigned int v0;  // r0

    return v0;
}
