int sub_8004951(unsigned int a0, unsigned int a1)
{
    if (!a1)
        return (unsigned int)sub_8004947(a0);
    return sub_8004785(a0, a1);
}
