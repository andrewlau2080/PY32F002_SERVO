0800365b ldr      r3, [pc, #0x5c]
0800365d b        #0x80035db
