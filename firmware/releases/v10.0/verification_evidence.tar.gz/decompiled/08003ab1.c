void* sub_8003ab1(void* a0)
{
    void* v0;  // r3
    void* v1;  // r3
    void* v2;  // r3

    if (a0 * 0x40000000)
    {
        v0 = a0;
        do
        {
            if (!*(char *)v0)
                return v0 - a0;
        } while ((v0 += 1, v0 & 0x3));
    }
    else
    {
        v0 = a0;
    }
    v1 = v0;
    if (!(*(int *)v1 + 0xfefefeff & ~*(int *)v1 & 0x80808080))
    {
        do
        {
            v2 = v0 + 4;
            v1 = v2;
        } while (!((int)v0[4] + 0xfefefeff & ~(int)v0[4] & 0x80808080) && (v0 = v2 + 4, v1 = v0, !((int)v2[4] + 0xfefefeff & ~(int)v2[4] & 0x80808080)));
    }
    while (1)
    {
        v0 = v1;
        if (!*(char *)v0)
            break;
        v1 = v0 + 1;
    }
    return v0 - a0;
}
