08003855 push     {r4, r5, r6, r7, lr}
08003857 mov      lr, r8
08003859 push     {lr}
0800385b cmp      r2, #0xf
0800385d bls      #0x80038e3
0800385f movs     r7, #3
08003861 movs     r5, r1
08003863 movs     r6, r7
08003865 orrs     r5, r0
08003867 movs     r4, r1
08003869 movs     r3, r0
0800386b ands     r6, r5
0800386d tst      r7, r5
0800386f bne      #0x80038ed
08003871 movs     r5, r2
08003873 subs     r5, #0x10
08003875 lsrs     r5, r5, #4
08003877 mov      r8, r5
08003879 lsls     r5, r5, #4
0800387b mov      ip, r5
0800387d add      ip, r0
0800387f ldr      r7, [r4]
08003881 movs     r5, r3
08003883 str      r7, [r3]
08003885 ldr      r7, [r4, #4]
08003887 str      r7, [r3, #4]
08003889 ldr      r7, [r4, #8]
0800388b str      r7, [r3, #8]
0800388d ldr      r7, [r4, #0xc]
0800388f adds     r4, #0x10
08003891 str      r7, [r3, #0xc]
08003893 adds     r3, #0x10
08003895 cmp      r5, ip
08003897 bne      #0x800387f
08003899 mov      r5, r8
0800389b movs     r3, #0xf
0800389d movs     r4, #0xc
0800389f adds     r5, #1
080038a1 lsls     r5, r5, #4
080038a3 adds     r1, r1, r5
080038a5 ands     r3, r2
080038a7 adds     r5, r0, r5
080038a9 tst      r4, r2
080038ab beq      #0x80038f3
080038ad ldr      r4, [r1, r6]
080038af str      r4, [r5, r6]
080038b1 adds     r6, #4
080038b3 subs     r4, r3, r6
080038b5 cmp      r4, #3
080038b7 bhi      #0x80038ad
080038b9 subs     r3, #4
080038bb lsrs     r3, r3, #2
080038bd adds     r3, #1
080038bf lsls     r3, r3, #2
080038c1 adds     r5, r5, r3
080038c3 adds     r1, r1, r3
080038c5 movs     r3, #3
080038c7 ands     r2, r3
080038c9 subs     r6, r2, #1
080038cb cmp      r2, #0
080038cd beq      #0x80038dd
080038cf movs     r3, #0
080038d1 ldrb     r4, [r1, r3]
080038d3 movs     r2, r3
080038d5 strb     r4, [r5, r3]
080038d7 adds     r3, #1
080038d9 cmp      r6, r2
080038db bne      #0x80038d1
080038dd pop      {r7}
080038df mov      r8, r7
080038e1 pop      {r4, r5, r6, r7, pc}
080038e3 movs     r5, r0
080038e5 subs     r6, r2, #1
080038e7 cmp      r2, #0
080038e9 bne      #0x80038cf
080038eb b        #0x80038dd
080038ed movs     r5, r0
080038ef subs     r6, r2, #1
080038f1 b        #0x80038cf
080038f3 movs     r2, r3
080038f5 b        #0x80038e5
