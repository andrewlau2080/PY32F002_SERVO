void sub_80025e9(unsigned int a0, unsigned int a1, unsigned int a2, unsigned int a3)
{
    unsigned int v0;  // r6

    if (v0 != 10)
        goto LABEL_0x800259d;
    sub_80023dd("MN", "BK", "ENT", a3); /* do not return */
}
