void sub_8003a1d(char *a0, int a1, int a2, unsigned int a3)
{
    unsigned int v9;  // r4
    unsigned int v10;  // lr
    char *v0;  // [bp-0x7c]
    char *v1;  // [bp-0x78]
    int v2;  // [bp-0x70], Other Possible Types: unsigned int
    unsigned short v3;  // [bp-0x6c]
    unsigned short v4;  // [bp-0x6a]
    char *v5;  // [bp-0x68]
    int v6;  // [bp-0x64], Other Possible Types: unsigned int
    unsigned int v7;  // [bp-0x10]
    unsigned int v8;  // [bp-0x4]

    v8 = a3;
    v7 = v9;
    if (a1 >= 0)
    {
        v3 = 520;
        v1 = a0;
        v5 = a0;
        if (a1)
        {
            v4 = 0xfffe;
            v2 = a1 - 1;
            v6 = v2;
            v0 = &v8;
            if ((int)sub_8003cf9(*0x2000023c, &v1, a2, &v8) < -0x1)
                *(unsigned int *)*(int *)0x2000023c = 139;
            *v1 = 0;
        }
        else
        {
            v4 = 0xfffe;
            v2 = 0;
            v6 = 0;
            v0 = &v8;
            if ((int)sub_8003cf9(*0x2000023c, &v1, a2, &v8) < -0x1)
                *(unsigned int *)*(int *)0x2000023c = 139;
        }
    }
    else
    {
        *(unsigned int *)*(int *)0x2000023c = 139;
    }
    goto *((void *)(v10));
}
