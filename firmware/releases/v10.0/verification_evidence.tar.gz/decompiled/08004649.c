int sub_8004649(unsigned int a0, unsigned int a1)
{
    return a0;
}
