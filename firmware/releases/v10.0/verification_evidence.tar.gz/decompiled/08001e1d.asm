08001e1d push     {r4, r5, r6, lr}
08001e1f movs     r6, #0xfa
08001e21 movs     r5, r0
08001e23 movs     r4, #0
08001e25 lsls     r6, r6, #2
08001e27 bl       #0x80010b5
08001e2b ldr      r3, [pc, #0x18]
08001e2d movs     r1, r6
08001e2f ldr      r0, [r3, #0x38]
08001e31 bl       #0x8004671
08001e35 adds     r4, #1
08001e37 bl       #0x80000c1
08001e3b cmp      r5, r4
08001e3d bne      #0x8001e27
08001e3f bl       #0x80010b5
08001e43 pop      {r4, r5, r6, pc}
