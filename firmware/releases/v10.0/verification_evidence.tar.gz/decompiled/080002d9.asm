080002d9 ldr      r3, [pc, #0xc]
080002db movs     r2, #0
080002dd movs     r1, r3
080002df adds     r3, #0x36
080002e1 adds     r1, #0x35
080002e3 strb     r2, [r1]
080002e5 strb     r2, [r3]
080002e7 bx       lr
