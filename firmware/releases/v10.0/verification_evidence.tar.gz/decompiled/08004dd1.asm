08004dd1 lsls     r0, r4, #2
08004dd3 movs     r0, r0
08004dd5 movs     r4, r0
08004dd7 movs     r0, r0
08004dd9 ldr      r4, [pc, #0x144]
08004ddb lsrs     r0, r0, #0x20
08004ddd ldr      r4, [pc, #0xc0]
08004ddf lsrs     r0, r0, #0x20
