080035eb ldr      r3, [pc, #0xa8]
080035ed b        #0x800359b
