extern char g_20000355;
extern char g_20000356;
extern unsigned short g_20000370;
extern char g_20000372;
extern char g_20000373;
extern char g_20000376;
extern char g_20000377;
extern char g_2000041e;
extern unsigned int g_20000420;

void sub_800146f(unsigned int a0, unsigned int a1, unsigned int a2, unsigned int a3, unsigned int a4, unsigned int a5, unsigned int a6, unsigned int a7, unsigned int a8, unsigned int a9, unsigned int a10, unsigned int a11, unsigned int a12, unsigned int a13, unsigned int a14, unsigned int a15, unsigned int a16, unsigned int a17, unsigned int a18, unsigned int a19, unsigned int a20, unsigned int a21, unsigned int a22, unsigned int a23, unsigned int a24, unsigned int a25, unsigned int a26, unsigned int a27, unsigned int a28, unsigned int a29, unsigned int a30, unsigned int a31)
{
    unsigned int v0;  // r2
    unsigned int v1;  // r6
    unsigned int v2;  // r4
    unsigned int v3;  // r5

    g_20000377 = 2;
    v0 = 1;
    if (v1 >= v2)
        v0 = -(v1 > v2);
    g_20000372 = v0;
    g_20000373 = v0;
    g_20000370 = 0;
    g_20000376 = 0;
    g_2000041e = 0;
    if (700 <= v3 && v0)
    {
        g_20000356 = v0;
        g_20000355 = 1;
        g_20000420 = a31;
    }
    sub_80002d9();
}
