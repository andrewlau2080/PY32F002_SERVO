08000255 movs     r2, #0xfa
08000257 movs     r3, r0
08000259 push     {r4, lr}
0800025b movs     r0, #0xfa
0800025d lsls     r2, r2, #1
0800025f cmp      r3, r2
08000261 bls      #0x800028b
08000263 ldr      r2, [pc, #0x48]
08000265 cmp      r3, r2
08000267 bhi      #0x80002a7
08000269 movs     r2, #0xaf
0800026b ldr      r1, [pc, #0x44]
0800026d lsls     r2, r2, #3
0800026f cmp      r3, r1
08000271 bhi      #0x800028d
08000273 subs     r3, #0xf5
08000275 subs     r3, #0xff
08000277 movs     r0, r3
08000279 muls     r0, r2, r0
0800027b subs     r1, #0xf5
0800027d adds     r0, #0xf5
0800027f adds     r0, #0xff
08000281 subs     r1, #0xff
08000283 bl       #0x8004671
08000287 adds     r0, #0xfa
08000289 uxth     r0, r0
0800028b pop      {r4, pc}
0800028d ldr      r1, [pc, #0x24]
0800028f adds     r3, r3, r1
08000291 movs     r1, #0xfa
08000293 muls     r3, r2, r3
08000295 adds     r3, #0xf5
08000297 adds     r3, #0xff
08000299 movs     r0, r3
0800029b lsls     r1, r1, #2
0800029d bl       #0x8004671
080002a1 ldr      r3, [pc, #0x14]
080002a3 adds     r0, r0, r3
080002a5 b        #0x8000289
080002a7 ldr      r0, [pc, #0x14]
080002a9 b        #0x800028b
