int sub_8002105(unsigned int a0, int a1, unsigned int a2)
{
    unsigned int v0;  // [bp+0x0]

    v0 = 0 + a2;
    sub_8002221(18, a1 + 40, 444); /* do not return */
}
