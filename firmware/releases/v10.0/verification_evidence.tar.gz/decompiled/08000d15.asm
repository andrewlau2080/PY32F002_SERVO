08000d15 ldr      r3, [pc, #0x44]
08000d17 push     {r4, r5, r6, lr}
08000d19 ldr      r4, [r3, #0x48]
08000d1b ldr      r6, [pc, #0x44]
08000d1d ldr      r5, [r4]
08000d1f ands     r5, r0
08000d21 cmp      r0, r5
08000d23 bne      #0x8000d29
08000d25 movs     r0, #0
08000d27 b        #0x8000d59
08000d29 ldr      r5, [r6, #0x20]
08000d2b subs     r5, r5, r1
08000d2d cmp      r2, r5
08000d2f bhs      #0x8000d1d
08000d31 ldr      r2, [r4, #0xc]
08000d33 ldr      r1, [pc, #0x30]
08000d35 movs     r0, #3
08000d37 ands     r2, r1
08000d39 str      r2, [r4, #0xc]
08000d3b ldr      r2, [r4, #0x14]
08000d3d adds     r1, #0xa3
08000d3f adds     r1, #0xff
08000d41 bics     r2, r1
08000d43 movs     r1, r3
08000d45 str      r2, [r4, #0x14]
08000d47 movs     r2, #0x20
08000d49 adds     r1, #0x85
08000d4b strb     r2, [r1]
08000d4d movs     r1, r3
08000d4f adds     r1, #0x86
08000d51 strb     r2, [r1]
08000d53 movs     r2, #0
08000d55 adds     r3, #0x84
08000d57 strb     r2, [r3]
08000d59 pop      {r4, r5, r6, pc}
