extern unsigned short g_20000358;
extern char g_2000035c;

int sub_8001061(unsigned short a0, unsigned int a1, unsigned int a2, unsigned short a3, unsigned short a4, char a5, char a6)
{
    sub_80007b9();
    g_20000358 = 0;
    sub_80002c1();
    g_2000035c = a5;
    return (unsigned int)sub_80005a1(a0, a1, a2, a3, a4, 0, a6);
}
