void sub_80001ad(unsigned int a0, unsigned int a1, unsigned int a2, unsigned int a3)
{
    unsigned int *v0;  // r0
    unsigned int v1;  // r3
    unsigned int v2;  // r2

    if (a1 <= a2)
        return;
    v0 = a0 + a2 * 24;
    v1 = a3 * v0[5] + v0[2];
    v2 = v0[3];
    if ((int)v1 >= (int)v0[3])
    {
        v2 = v0[4];
        if ((int)v0[4] > (int)v1)
            v2 = v1;
    }
    v0[2] = v2;
    return;
}
