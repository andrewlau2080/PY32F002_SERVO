void sub_800248d(unsigned int a0, unsigned int a1, unsigned int a2, unsigned int a3)
{
    unsigned int v0;  // r6
    unsigned int v1;  // r4

    if (v0 != v1 && v1 != 5)
        sub_8002479(); /* do not return */
    sub_80023dd(L"-AEWH义爀晥獟慴r敳摮祸ㄽ戀捫摭〽戀畡獤┽畬戀畡㵤氥u佌匀䠀IB呓堀䄀D楤㵭〱0慰敧〠琀睳㈠㔵〬琀睳┠Ⱶ0甥┠⁵甥─\u2064甥─╳⁵搥─\u2073搥倀〱倀〲倀〵倀〶倀〸倀〹䠀摢挀瑮䠀敶l㑱刀汥䰀業n浌硡䈀業n杂䈀慭x療䈀摨嘀慭x捁c䙆䬀v汓睥䤀癮䐀物䠀z慍x瑓a瑓m獭", "BK", "+", a3); /* do not return */
}
