08003a1d push     {r2, r3}
08003a1f push     {r4, lr}
08003a21 ldr      r3, [pc, #0x78]
08003a23 sub      sp, #0x70
08003a25 ldr      r4, [r3]
08003a27 cmp      r1, #0
08003a29 blt      #0x8003a91
08003a2b movs     r3, #0x82
08003a2d mov      r2, sp
08003a2f lsls     r3, r3, #2
08003a31 strh     r3, [r2, #0x14]
08003a33 str      r0, [sp, #8]
08003a35 str      r0, [sp, #0x18]
08003a37 cmp      r1, #0
08003a39 beq      #0x8003a65
08003a3b movs     r3, #1
08003a3d subs     r1, #1
08003a3f rsbs     r3, r3, #0
08003a41 strh     r3, [r2, #0x16]
08003a43 str      r1, [sp, #0x10]
08003a45 add      r3, sp, #0x7c
08003a47 str      r1, [sp, #0x1c]
08003a49 movs     r0, r4
08003a4b ldr      r2, [sp, #0x78]
08003a4d add      r1, sp, #8
08003a4f str      r3, [sp, #4]
08003a51 bl       #0x8003cf9
08003a55 adds     r3, r0, #1
08003a57 bge      #0x8003a5d
08003a59 movs     r3, #0x8b
08003a5b str      r3, [r4]
08003a5d movs     r3, #0
08003a5f ldr      r2, [sp, #8]
08003a61 strb     r3, [r2]
08003a63 b        #0x8003a87
08003a65 movs     r3, #1
08003a67 mov      r2, sp
08003a69 rsbs     r3, r3, #0
08003a6b strh     r3, [r2, #0x16]
08003a6d str      r1, [sp, #0x10]
08003a6f add      r3, sp, #0x7c
08003a71 str      r1, [sp, #0x1c]
08003a73 movs     r0, r4
08003a75 ldr      r2, [sp, #0x78]
08003a77 add      r1, sp, #8
08003a79 str      r3, [sp, #4]
08003a7b bl       #0x8003cf9
08003a7f adds     r3, r0, #1
08003a81 bge      #0x8003a87
08003a83 movs     r3, #0x8b
08003a85 str      r3, [r4]
08003a87 add      sp, #0x70
08003a89 pop      {r4}
08003a8b pop      {r3}
08003a8d add      sp, #8
08003a8f bx       r3
08003a91 movs     r3, #0x8b
08003a93 movs     r0, #1
08003a95 str      r3, [r4]
08003a97 rsbs     r0, r0, #0
08003a99 b        #0x8003a87
