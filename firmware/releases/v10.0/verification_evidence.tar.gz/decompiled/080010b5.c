int sub_80010b5(void)
{
    unsigned int v2;  // r0
    unsigned int v0;  // [bp-0x8c]
    unsigned int v1;  // [bp-0x44]

    v0 = *0x2000041a;
    if (!*0x2000041a)
        return v2;
    v1 = 4;
    return sub_80010cf();
}
