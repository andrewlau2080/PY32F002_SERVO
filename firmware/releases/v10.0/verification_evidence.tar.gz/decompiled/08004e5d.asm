08004e5d lsls     r4, r4, #1
08004e5f movs     r0, r0
08004e61 lsls     r0, r5, #0xf
08004e63 movs     r0, r0
08004e65 movs     r2, r1
08004e67 movs     r0, r0
08004e69 lsls     r0, r5, #0xf
08004e6b movs     r0, r0
08004e6d ldr      r4, [pc, #0x1a4]
08004e6f lsrs     r0, r0, #0x20
08004e71 ldr      r3, [pc, #0x34]
08004e73 lsrs     r0, r0, #0x20
