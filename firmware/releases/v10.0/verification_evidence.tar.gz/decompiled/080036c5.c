int sub_80036c5(void)
{
    unsigned int v0;  // r0

    return v0;
}
