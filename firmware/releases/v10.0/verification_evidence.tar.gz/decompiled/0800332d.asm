0800332d ldr      r2, [pc, #0x74]
0800332f ldr      r3, [sp, #0x14]
08003331 strh     r3, [r2, #0xe]
08003333 ldr      r3, [pc, #0x80]
08003335 adds     r3, #0x50
08003337 ldrh     r3, [r3]
08003339 strh     r3, [r2, #0x24]
