0800083d movs     r1, #0xfa
0800083f push     {r4, r5, r6, lr}
08000841 ldr      r5, [pc, #0x48]
08000843 movs     r4, r0
08000845 lsls     r1, r1, #2
08000847 ldr      r0, [r5, #0x38]
08000849 bl       #0x8004671
0800084d movs     r3, #0x80
0800084f subs     r0, #1
08000851 lsls     r3, r3, #0x11
08000853 cmp      r0, r3
08000855 blo      #0x800085b
08000857 movs     r0, #1
08000859 pop      {r4, r5, r6, pc}
0800085b ldr      r1, [pc, #0x34]
0800085d ldr      r2, [pc, #0x34]
0800085f str      r0, [r1, #4]
08000861 movs     r0, #0xc0
08000863 ldr      r3, [r2, #0x20]
08000865 lsls     r0, r0, #0x18
08000867 lsls     r3, r3, #8
08000869 lsrs     r3, r3, #8
0800086b orrs     r3, r0
0800086d str      r3, [r2, #0x20]
0800086f movs     r0, #0
08000871 movs     r3, #7
08000873 str      r0, [r1, #8]
08000875 str      r3, [r1]
08000877 cmp      r4, #3
08000879 bhi      #0x8000857
0800087b ldr      r3, [r2, #0x20]
0800087d lsls     r1, r4, #0x1e
0800087f lsls     r3, r3, #8
08000881 lsrs     r3, r3, #8
08000883 orrs     r3, r1
08000885 str      r3, [r2, #0x20]
08000887 str      r4, [r5, #0x3c]
08000889 b        #0x8000859
