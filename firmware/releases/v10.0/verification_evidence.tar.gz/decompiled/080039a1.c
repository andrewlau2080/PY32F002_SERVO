void sub_80039a1(unsigned int *a0, char *a1, int a2, int a3)
{
    unsigned int v9;  // r4
    unsigned int v10;  // lr
    char *v0;  // [bp-0x7c]
    char *v1;  // [bp-0x78]
    int v2;  // [bp-0x70], Other Possible Types: unsigned int
    unsigned short v3;  // [bp-0x6c]
    unsigned short v4;  // [bp-0x6a]
    char *v5;  // [bp-0x68]
    int v6;  // [bp-0x64], Other Possible Types: unsigned int
    unsigned int v7;  // [bp-0xc]
    char v8;  // [bp+0x0]

    v7 = v9;
    if (a2 >= 0)
    {
        v3 = 520;
        v1 = a1;
        v5 = a1;
        if (a2)
        {
            v4 = 0xfffe;
            v2 = a2 - 1;
            v6 = v2;
            if ((int)sub_8003cf9(a0, &v1, a3, &v8) < -0x1)
                *a0 = 139;
            *v1 = 0;
        }
        else
        {
            v4 = 0xfffe;
            v2 = 0;
            v6 = 0;
            v0 = &v8;
            if ((int)sub_8003cf9(a0, &v1, a3, &v8) < -0x1)
                *a0 = 139;
        }
    }
    else
    {
        *a0 = 139;
    }
    goto *((void *)(v10));
}
