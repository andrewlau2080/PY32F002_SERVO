typedef struct st_800240d_0 {
    char padding_0[4];
    struct st_800240d_1 *field_4;
} st_800240d_0;

typedef struct st_800240d_1 {
    char field_0;
} st_800240d_1;

void sub_8002479(void)
{
    unsigned int v0;  // r4
    st_800240d_0 *v1;  // r5
    unsigned int v2;  // r7

    sub_800240d(v0, v1, v2 - v0 + -(v2 - v0) + (v2 - v0 <= 0) & 0xff); /* do not return */
}
