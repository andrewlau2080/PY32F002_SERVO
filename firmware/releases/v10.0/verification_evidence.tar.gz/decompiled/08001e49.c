extern unsigned int g_50000018;
extern unsigned int g_50000028;

int sub_8001e49(int a0, unsigned int a1)
{
    int v1;  // r4
    int v2;  // r6
    int v3;  // r1
    int v4;  // r0
    int i;  // [bp-0x1c], Other Possible Types: unsigned int

    i = a1;
    v1 = 0;
    v2 = 20;
    i = a0;
    do
    {
        v3 = v1;
        if (*(int *)0x20000428)
        {
            v3 = 120;
            sub_800477d(v1, 120);
        }
        v4 = v2;
        if (!*(int *)0x20000428)
            v4 = 40;
        if ((unsigned int)v4 > (unsigned int)v3)
            g_50000028 = 32;
        else
            g_50000018 = 32;
        sub_80010b5();
        sub_80000c1(sub_8004671(*0x20000038, 1000));
        v1 += 1;
    } while (i != v1);
    sub_80010b5();
    return a0;
}
