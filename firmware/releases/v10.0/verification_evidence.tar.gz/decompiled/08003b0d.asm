08003b0d push     {r4, r5, r6, r7, lr}
08003b0f mov      lr, sl
08003b11 mov      r7, sb
08003b13 mov      r6, r8
08003b15 push     {r6, r7, lr}
08003b17 ldr      r7, [r1, #8]
08003b19 mov      sl, r0
08003b1b movs     r4, r1
08003b1d movs     r6, r2
08003b1f movs     r5, r3
08003b21 cmp      r7, r3
08003b23 bhi      #0x8003b9d
08003b25 movs     r2, #0x90
08003b27 ldrh     r3, [r1, #0xc]
08003b29 lsls     r2, r2, #3
08003b2b tst      r3, r2
08003b2d bne      #0x8003b55
08003b2f movs     r5, r7
08003b31 ldr      r0, [r1]
08003b33 movs     r2, r5
08003b35 movs     r1, r6
08003b37 bl       #0x800436d
08003b3b ldr      r3, [r4, #8]
08003b3d movs     r0, #0
08003b3f subs     r7, r3, r7
08003b41 ldr      r3, [r4]
08003b43 str      r7, [r4, #8]
08003b45 mov      ip, r3
08003b47 add      r5, ip
08003b49 str      r5, [r4]
08003b4b pop      {r5, r6, r7}
08003b4d mov      sl, r7
08003b4f mov      sb, r6
08003b51 mov      r8, r5
08003b53 pop      {r4, r5, r6, r7, pc}
08003b55 ldr      r1, [r1, #0x10]
08003b57 ldr      r2, [r4]
08003b59 ldr      r0, [r4, #0x14]
08003b5b subs     r2, r2, r1
08003b5d mov      sb, r2
08003b5f lsls     r2, r0, #1
08003b61 adds     r2, r2, r0
08003b63 lsrs     r0, r2, #0x1f
08003b65 adds     r2, r0, r2
08003b67 adds     r0, r5, #1
08003b69 asrs     r2, r2, #1
08003b6b add      r0, sb
08003b6d mov      r8, r2
08003b6f cmp      r0, r2
08003b71 bls      #0x8003b77
08003b73 mov      r8, r0
08003b75 movs     r2, r0
08003b77 lsls     r3, r3, #0x15
08003b79 bpl      #0x8003ba3
08003b7b movs     r1, r2
08003b7d mov      r0, sl
08003b7f bl       #0x80044d9
08003b83 subs     r7, r0, #0
08003b85 beq      #0x8003bcb
08003b87 mov      r2, sb
08003b89 ldr      r1, [r4, #0x10]
08003b8b bl       #0x8003855
08003b8f ldrh     r3, [r4, #0xc]
08003b91 ldr      r2, [pc, #0x4c]
08003b93 ands     r3, r2
08003b95 movs     r2, #0x80
08003b97 orrs     r3, r2
08003b99 strh     r3, [r4, #0xc]
08003b9b b        #0x8003bad
08003b9d movs     r7, r3
08003b9f ldr      r0, [r1]
08003ba1 b        #0x8003b33
08003ba3 mov      r0, sl
08003ba5 bl       #0x800459d
08003ba9 subs     r7, r0, #0
08003bab beq      #0x8003bc3
08003bad movs     r0, r7
08003baf mov      r3, r8
08003bb1 mov      r2, sb
08003bb3 add      r0, sb
08003bb5 str      r3, [r4, #0x14]
08003bb7 subs     r3, r3, r2
08003bb9 str      r7, [r4, #0x10]
08003bbb str      r0, [r4]
08003bbd movs     r7, r5
08003bbf str      r3, [r4, #8]
08003bc1 b        #0x8003b33
08003bc3 mov      r0, sl
08003bc5 ldr      r1, [r4, #0x10]
08003bc7 bl       #0x8004419
08003bcb movs     r3, #0xc
08003bcd mov      r2, sl
08003bcf str      r3, [r2]
08003bd1 movs     r2, #0x40
08003bd3 movs     r0, #1
08003bd5 ldrh     r3, [r4, #0xc]
08003bd7 rsbs     r0, r0, #0
08003bd9 orrs     r3, r2
08003bdb strh     r3, [r4, #0xc]
08003bdd b        #0x8003b4b
