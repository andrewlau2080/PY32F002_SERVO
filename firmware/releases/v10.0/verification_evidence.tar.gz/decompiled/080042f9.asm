080042f9 push     {r4, r5, r6, lr}
080042fb uxtb     r4, r1
080042fd lsls     r3, r0, #0x1e
080042ff beq      #0x800431d
08004301 subs     r3, r2, #1
08004303 cmp      r2, #0
08004305 beq      #0x8004327
08004307 movs     r5, #3
08004309 b        #0x8004315
0800430b adds     r0, #1
0800430d tst      r0, r5
0800430f beq      #0x800431f
08004311 subs     r3, #1
08004313 blo      #0x8004327
08004315 ldrb     r2, [r0]
08004317 cmp      r2, r4
08004319 bne      #0x800430b
0800431b pop      {r4, r5, r6, pc}
0800431d movs     r3, r2
0800431f cmp      r3, #3
08004321 bhi      #0x800433d
08004323 cmp      r3, #0
08004325 bne      #0x800432b
08004327 movs     r0, #0
08004329 b        #0x800431b
0800432b adds     r3, r0, r3
0800432d b        #0x8004335
0800432f adds     r0, #1
08004331 cmp      r3, r0
08004333 beq      #0x8004327
08004335 ldrb     r2, [r0]
08004337 cmp      r2, r4
08004339 bne      #0x800432f
0800433b b        #0x800431b
0800433d movs     r5, #0xff
0800433f ands     r1, r5
08004341 lsls     r5, r1, #8
08004343 orrs     r1, r5
08004345 lsls     r5, r1, #0x10
08004347 ldr      r6, [pc, #0x1c]
08004349 orrs     r5, r1
0800434b ldr      r2, [r0]
0800434d ldr      r1, [pc, #0x18]
0800434f eors     r2, r5
08004351 adds     r1, r2, r1
08004353 bics     r1, r2
08004355 tst      r1, r6
08004357 bne      #0x800432b
08004359 subs     r3, #4
0800435b adds     r0, #4
0800435d cmp      r3, #3
0800435f bhi      #0x800434b
08004361 b        #0x8004323
