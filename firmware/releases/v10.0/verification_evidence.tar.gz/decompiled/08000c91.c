extern unsigned int g_40021034;

void sub_8000c91(char *a0, unsigned int a1)
{
    unsigned int v0;  // [bp-0x30]
    unsigned int v1;  // [bp-0x2c]
    unsigned int v2;  // [bp-0x28]
    char v3;  // [bp-0x24], Other Possible Types: unsigned int
    unsigned int v4;  // [bp-0x20]
    unsigned int v5;  // [bp-0x1c]
    unsigned int v6;  // [bp-0x18]

    sub_80038f9(&v3, 0, 20);
    switch (a0)
    {
    case 1342177280:
        g_40021034 = g_40021034 | 1;
        v2 = g_40021034 & 1;
        break;
    case 1342178304:
        g_40021034 = g_40021034 | 2;
        v1 = g_40021034 & 2;
        break;
    case 1342182400:
        g_40021034 = g_40021034 | 32;
        v0 = g_40021034 & 32;
        break;
    default:
        goto LABEL_8000cbd;
    }
LABEL_8000cbd:
    v4 = 1;
    v3 = a1;
    v5 = 2;
    v6 = 2;
    sub_8000925(a0, &v3);
    return;
}
