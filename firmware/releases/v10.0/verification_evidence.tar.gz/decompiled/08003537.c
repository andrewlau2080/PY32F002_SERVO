int sub_8003537(void)
{
    unsigned short *v0;  // r7

    v0[4] = 0xfffd;
    v0[5] = 0xfffd;
}
