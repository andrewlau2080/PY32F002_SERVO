08002405 pop      {r4, r5, r6, pc}
