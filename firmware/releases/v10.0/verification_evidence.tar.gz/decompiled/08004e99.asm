08004e99 movs     r1, r0
08004e9b movs     r0, r0
08004e9d ldr      r4, [pc, #0x1c4]
08004e9f lsrs     r0, r0, #0x20
