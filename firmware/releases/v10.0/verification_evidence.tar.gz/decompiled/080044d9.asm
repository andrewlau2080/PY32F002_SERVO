080044d9 push     {r3, r4, r5, r6, r7, lr}
080044db movs     r3, #3
080044dd adds     r5, r1, #3
080044df bics     r5, r3
080044e1 adds     r5, #8
080044e3 movs     r6, r0
080044e5 cmp      r5, #0xc
080044e7 bhs      #0x8004539
080044e9 movs     r5, #0xc
080044eb cmp      r1, r5
080044ed bhi      #0x800453d
080044ef movs     r0, r6
080044f1 bl       #0x8004611
080044f5 ldr      r7, [pc, #0xa0]
080044f7 ldr      r2, [r7]
080044f9 cmp      r2, #0
080044fb beq      #0x800454d
080044fd movs     r4, r2
080044ff b        #0x800450b
08004501 ldr      r3, [r4, #4]
08004503 movs     r2, r4
08004505 cmp      r3, #0
08004507 beq      #0x800454d
08004509 movs     r4, r3
0800450b ldr      r3, [r4]
0800450d subs     r3, r3, r5
0800450f bmi      #0x8004501
08004511 cmp      r3, #0xb
08004513 bhi      #0x8004545
08004515 ldr      r3, [r4, #4]
08004517 cmp      r4, r2
08004519 beq      #0x8004587
0800451b str      r3, [r2, #4]
0800451d movs     r0, r6
0800451f bl       #0x8004615
08004523 movs     r0, r4
08004525 movs     r2, #7
08004527 adds     r0, #0xb
08004529 adds     r3, r4, #4
0800452b bics     r0, r2
0800452d subs     r2, r0, r3
0800452f cmp      r0, r3
08004531 beq      #0x8004543
08004533 subs     r3, r3, r0
08004535 str      r3, [r4, r2]
08004537 b        #0x8004543
08004539 cmp      r5, #0
0800453b bge      #0x80044eb
0800453d movs     r3, #0xc
0800453f movs     r0, #0
08004541 str      r3, [r6]
08004543 pop      {r3, r4, r5, r6, r7, pc}
08004545 str      r3, [r4]
08004547 adds     r4, r4, r3
08004549 str      r5, [r4]
0800454b b        #0x800451d
0800454d ldr      r3, [r7, #4]
0800454f cmp      r3, #0
08004551 beq      #0x800458b
08004553 movs     r1, r5
08004555 movs     r0, r6
08004557 bl       #0x80045ed
0800455b adds     r3, r0, #1
0800455d beq      #0x8004579
0800455f movs     r3, #3
08004561 adds     r4, r0, #3
08004563 bics     r4, r3
08004565 cmp      r0, r4
08004567 beq      #0x8004575
08004569 subs     r1, r4, r0
0800456b movs     r0, r6
0800456d bl       #0x80045ed
08004571 adds     r3, r0, #1
08004573 beq      #0x8004579
08004575 str      r5, [r4]
08004577 b        #0x800451d
08004579 movs     r3, #0xc
0800457b movs     r0, r6
0800457d str      r3, [r6]
0800457f bl       #0x8004615
08004583 movs     r0, #0
08004585 b        #0x8004543
08004587 str      r3, [r7]
08004589 b        #0x800451d
0800458b movs     r1, #0
0800458d movs     r0, r6
0800458f bl       #0x80045ed
08004593 str      r0, [r7, #4]
08004595 b        #0x8004553
