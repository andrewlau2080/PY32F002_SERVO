void sub_8004771(unsigned int a0)
{
    unsigned int v0;  // [bp-0x8]

    v0 = a0;
    sub_8004959(0);
    return;
}
