08004671 movs     r2, #0
08004673 lsrs     r3, r0, #1
08004675 cmp      r3, r1
08004677 blo      #0x8004763
08004679 lsrs     r3, r0, #4
0800467b cmp      r3, r1
0800467d blo      #0x800473f
0800467f lsrs     r3, r0, #8
08004681 cmp      r3, r1
08004683 blo      #0x800470f
08004685 lsrs     r3, r0, #0xc
08004687 cmp      r3, r1
08004689 blo      #0x80046dd
0800468b lsrs     r3, r0, #0x10
0800468d cmp      r3, r1
0800468f blo      #0x80046ad
08004691 movs     r2, #0xff
08004693 lsls     r1, r1, #8
08004695 rev      r2, r2
08004697 lsrs     r3, r0, #0x10
08004699 cmp      r3, r1
0800469b blo      #0x80046a3
0800469d asrs     r2, r2, #8
0800469f lsls     r1, r1, #8
080046a1 beq      #0x800476f
080046a3 lsrs     r3, r0, #0xc
080046a5 cmp      r3, r1
080046a7 blo      #0x80046dd
080046a9 b        #0x80046ad
080046ab lsrs     r1, r1, #8
080046ad lsrs     r3, r0, #0xf
080046af cmp      r3, r1
080046b1 blo      #0x80046b7
080046b3 lsls     r3, r1, #0xf
080046b5 subs     r0, r0, r3
080046b7 adcs     r2, r2
080046b9 lsrs     r3, r0, #0xe
080046bb cmp      r3, r1
080046bd blo      #0x80046c3
080046bf lsls     r3, r1, #0xe
080046c1 subs     r0, r0, r3
080046c3 adcs     r2, r2
080046c5 lsrs     r3, r0, #0xd
080046c7 cmp      r3, r1
080046c9 blo      #0x80046cf
080046cb lsls     r3, r1, #0xd
080046cd subs     r0, r0, r3
080046cf adcs     r2, r2
080046d1 lsrs     r3, r0, #0xc
080046d3 cmp      r3, r1
080046d5 blo      #0x80046db
080046d7 lsls     r3, r1, #0xc
080046d9 subs     r0, r0, r3
080046db adcs     r2, r2
080046dd lsrs     r3, r0, #0xb
080046df cmp      r3, r1
080046e1 blo      #0x80046e7
080046e3 lsls     r3, r1, #0xb
080046e5 subs     r0, r0, r3
080046e7 adcs     r2, r2
080046e9 lsrs     r3, r0, #0xa
080046eb cmp      r3, r1
080046ed blo      #0x80046f3
080046ef lsls     r3, r1, #0xa
080046f1 subs     r0, r0, r3
080046f3 adcs     r2, r2
080046f5 lsrs     r3, r0, #9
080046f7 cmp      r3, r1
080046f9 blo      #0x80046ff
080046fb lsls     r3, r1, #9
080046fd subs     r0, r0, r3
080046ff adcs     r2, r2
08004701 lsrs     r3, r0, #8
08004703 cmp      r3, r1
08004705 blo      #0x800470b
08004707 lsls     r3, r1, #8
08004709 subs     r0, r0, r3
0800470b adcs     r2, r2
0800470d bhs      #0x80046ab
0800470f lsrs     r3, r0, #7
08004711 cmp      r3, r1
08004713 blo      #0x8004719
08004715 lsls     r3, r1, #7
08004717 subs     r0, r0, r3
08004719 adcs     r2, r2
0800471b lsrs     r3, r0, #6
0800471d cmp      r3, r1
0800471f blo      #0x8004725
08004721 lsls     r3, r1, #6
08004723 subs     r0, r0, r3
08004725 adcs     r2, r2
08004727 lsrs     r3, r0, #5
08004729 cmp      r3, r1
0800472b blo      #0x8004731
0800472d lsls     r3, r1, #5
0800472f subs     r0, r0, r3
08004731 adcs     r2, r2
08004733 lsrs     r3, r0, #4
08004735 cmp      r3, r1
08004737 blo      #0x800473d
08004739 lsls     r3, r1, #4
0800473b subs     r0, r0, r3
0800473d adcs     r2, r2
0800473f lsrs     r3, r0, #3
08004741 cmp      r3, r1
08004743 blo      #0x8004749
08004745 lsls     r3, r1, #3
08004747 subs     r0, r0, r3
08004749 adcs     r2, r2
0800474b lsrs     r3, r0, #2
0800474d cmp      r3, r1
0800474f blo      #0x8004755
08004751 lsls     r3, r1, #2
08004753 subs     r0, r0, r3
08004755 adcs     r2, r2
08004757 lsrs     r3, r0, #1
08004759 cmp      r3, r1
0800475b blo      #0x8004761
0800475d lsls     r3, r1, #1
0800475f subs     r0, r0, r3
08004761 adcs     r2, r2
08004763 subs     r1, r0, r1
08004765 bhs      #0x8004769
08004767 mov      r1, r0
08004769 adcs     r2, r2
0800476b mov      r0, r2
0800476d bx       lr
0800476f b        #0x8004771
