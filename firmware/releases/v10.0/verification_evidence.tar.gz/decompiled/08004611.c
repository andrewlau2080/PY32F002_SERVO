int sub_8004611(unsigned int a0)
{
    return a0;
}
