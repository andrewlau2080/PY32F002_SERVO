typedef struct st_8003f35_0 {
    unsigned int field_0;
    char padding_4[4];
    int field_8;
    unsigned int field_c;
    int field_10;
    char padding_14[47];
    char field_43;
    char padding_44[1];
    char field_45;
} st_8003f35_0;

void sub_8003f35(unsigned int a0, st_8003f35_0 *a1, int *a2, unsigned int a3)
{
    unsigned int v10;  // r4
    unsigned int v11;  // r5
    unsigned int v20;  // r3
    unsigned int v21;  // r2
    unsigned int v22;  // r3
    unsigned int v23;  // r3
    unsigned int v12;  // r6
    unsigned int v13;  // r7
    unsigned int v14;  // lr
    unsigned int v15;  // r8
    unsigned int v16;  // r9
    unsigned int v17;  // r10
    unsigned int v18;  // r2
    unsigned int v19;  // r1
    unsigned int v0;  // [bp-0x28]
    unsigned int v1;  // [bp-0x24]
    unsigned int v2;  // [bp-0x20]
    unsigned int v3;  // [bp-0x18]
    unsigned int v4;  // [bp-0x14]
    unsigned int v5;  // [bp-0x10]
    unsigned int v6;  // [bp-0xc]
    unsigned int v7;  // [bp-0x8]
    unsigned int v8;  // [bp-0x4]
    unsigned int *v9;  // [bp+0x0]

    v3 = a3;
    v4 = v10;
    v5 = v11;
    v6 = v12;
    v7 = v13;
    v8 = v14;
    v0 = v15;
    v1 = v16;
    v2 = v17;
    v18 = a1->field_10;
    if (a1->field_8 > a1->field_10)
        v18 = a1->field_8;
    *a2 = v18;
    if (a1->field_43)
        *a2 = v18 + 1;
    v19 = a1->field_0;
    if ((int)(v19 * 0x4000000) < 0)
    {
        v20 = *a2 + 2;
        *a2 = v20;
        v19 = a1->field_0;
        v21 = v19;
        if (6 & v19)
            goto LABEL_8003f97;
        goto LABEL_8003f83;
    }
    else
    {
        if (!(v19 & 6))
        {
            v20 = *a2;
LABEL_8003f83:
            v21 = v19;
            if (0 < (int)(a1->field_c - v20))
                v9();
LABEL_8003f97:
            v22 = a1->field_43;
            v23 = v22 - (v22 - 1) - (1 > v22);
            if ((int)(v21 * 0x4000000) < 0)
            {
                (&a1->field_43)[v23] = 48;
                (a1->padding_44)[v23] = a1->field_45;
            }
        }
        v9();
    }
}
