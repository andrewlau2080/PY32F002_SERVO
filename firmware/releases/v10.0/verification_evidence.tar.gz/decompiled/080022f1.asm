080022f1 push     {r4, r5, r6, r7, lr}
080022f3 sub      sp, #0x1c
080022f5 str      r3, [sp, #0x14]
080022f7 add      r3, sp, #0x30
080022f9 ldrb     r5, [r3]
080022fb movs     r3, #0x26
080022fd movs     r6, r1
080022ff movs     r1, r3
08002301 lsls     r4, r0, #0x1f
08002303 muls     r1, r0, r1
08002305 ldr      r0, [pc, #0x5c]
08002307 str      r2, [sp, #0x10]
08002309 asrs     r4, r4, #0x1f
0800230b ldr      r2, [pc, #0x5c]
