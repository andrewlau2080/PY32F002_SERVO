08000925 ldr      r2, [pc, #0x124]
08000927 push     {r4, r5, r6, r7, lr}
08000929 adds     r2, r0, r2
0800092b subs     r4, r2, #1
0800092d sbcs     r2, r4
0800092f movs     r3, #0
08000931 sub      sp, #0x14
08000933 adds     r2, #1
08000935 str      r1, [sp]
08000937 str      r2, [sp, #0xc]
08000939 ldr      r2, [sp]
0800093b ldr      r2, [r2]
0800093d movs     r4, r2
0800093f lsrs     r4, r3
08000941 bne      #0x8000947
08000943 add      sp, #0x14
08000945 pop      {r4, r5, r6, r7, pc}
08000947 movs     r4, #1
08000949 lsls     r4, r3
0800094b str      r4, [sp, #4]
0800094d ldr      r1, [sp, #4]
0800094f ands     r4, r2
08000951 mov      ip, r4
08000953 tst      r2, r1
08000955 beq      #0x8000a47
08000957 ldr      r2, [sp]
08000959 movs     r4, #0x10
0800095b ldr      r2, [r2, #4]
0800095d movs     r5, r2
0800095f bics     r5, r4
08000961 str      r5, [sp, #8]
08000963 cmp      r5, #2
08000965 bne      #0x8000985
08000967 movs     r5, #7
08000969 movs     r7, #0xf
0800096b ands     r5, r3
0800096d lsls     r5, r5, #2
0800096f lsls     r7, r5
08000971 lsrs     r4, r3, #3
08000973 lsls     r4, r4, #2
08000975 adds     r4, r0, r4
08000977 ldr      r6, [r4, #0x20]
08000979 ldr      r1, [sp]
0800097b bics     r6, r7
0800097d ldr      r7, [r1, #0x10]
0800097f lsls     r7, r5
08000981 orrs     r6, r7
08000983 str      r6, [r4, #0x20]
08000985 movs     r4, #3
08000987 movs     r6, r4
08000989 lsls     r5, r3, #1
0800098b lsls     r6, r5
0800098d ldr      r1, [r0]
0800098f ands     r4, r2
08000991 bics     r1, r6
08000993 lsls     r4, r5
08000995 mvns     r7, r6
08000997 movs     r6, r1
08000999 orrs     r6, r4
0800099b ldr      r4, [sp, #8]
0800099d str      r6, [r0]
0800099f subs     r4, #1
080009a1 cmp      r4, #1
080009a3 bhi      #0x80009c3
080009a5 ldr      r1, [sp]
080009a7 ldr      r6, [r0, #8]
080009a9 ldr      r4, [r1, #0xc]
080009ab ands     r6, r7
080009ad lsls     r4, r5
080009af orrs     r4, r6
080009b1 str      r4, [r0, #8]
080009b3 lsls     r4, r2, #0x1b
080009b5 lsrs     r4, r4, #0x1f
080009b7 lsls     r4, r3
080009b9 ldr      r6, [r0, #4]
080009bb ldr      r1, [sp, #4]
080009bd bics     r6, r1
080009bf orrs     r4, r6
080009c1 str      r4, [r0, #4]
080009c3 ldr      r4, [r0, #0xc]
080009c5 ldr      r1, [sp]
080009c7 ands     r4, r7
080009c9 ldr      r7, [r1, #8]
080009cb lsls     r7, r5
080009cd orrs     r7, r4
080009cf str      r7, [r0, #0xc]
080009d1 lsls     r1, r2, #3
080009d3 bpl      #0x8000a47
080009d5 movs     r6, #3
080009d7 movs     r5, #0xf
080009d9 ldr      r1, [pc, #0x74]
080009db lsrs     r4, r3, #2
080009dd ands     r6, r3
080009df lsls     r4, r4, #2
080009e1 lsls     r6, r6, #3
080009e3 lsls     r5, r6
080009e5 adds     r4, r4, r1
080009e7 movs     r1, #0xa0
080009e9 ldr      r7, [r4, #0x60]
080009eb lsls     r1, r1, #0x17
080009ed bics     r7, r5
080009ef movs     r5, #0
080009f1 cmp      r0, r1
080009f3 beq      #0x80009f7
080009f5 ldr      r5, [sp, #0xc]
080009f7 lsls     r5, r6
080009f9 mov      r1, ip
080009fb mov      r6, ip
080009fd orrs     r7, r5
080009ff str      r7, [r4, #0x60]
08000a01 ldr      r4, [pc, #0x50]
08000a03 mvns     r5, r1
08000a05 ldr      r7, [r4, #0x7c]
08000a07 orrs     r6, r7
08000a09 lsls     r1, r2, #0xf
08000a0b bmi      #0x8000a11
08000a0d movs     r6, r7
08000a0f ands     r6, r5
08000a11 mov      r7, ip
08000a13 str      r6, [r4, #0x7c]
08000a15 ldr      r6, [pc, #0x40]
08000a17 ldr      r4, [r6, #0x7c]
08000a19 orrs     r7, r4
08000a1b lsls     r1, r2, #0xe
08000a1d bmi      #0x8000a23
08000a1f ands     r4, r5
08000a21 movs     r7, r4
08000a23 str      r7, [r6, #0x7c]
08000a25 mov      r6, ip
08000a27 ldr      r4, [pc, #0x28]
08000a29 ldr      r7, [r4]
08000a2b orrs     r6, r7
08000a2d lsls     r1, r2, #0xb
08000a2f bmi      #0x8000a35
08000a31 movs     r6, r7
08000a33 ands     r6, r5
08000a35 mov      r7, ip
08000a37 str      r6, [r4]
08000a39 ldr      r6, [r4, #4]
08000a3b orrs     r7, r6
08000a3d lsls     r2, r2, #0xa
08000a3f bmi      #0x8000a45
08000a41 ands     r6, r5
08000a43 movs     r7, r6
08000a45 str      r7, [r4, #4]
08000a47 adds     r3, #1
08000a49 b        #0x8000939
