080037e1 ldr      r1, [pc, #0x20]
080037e3 ldr      r3, [pc, #0x24]
080037e5 ldr      r2, [r1, #4]
080037e7 ldr      r3, [r3]
080037e9 lsrs     r2, r2, #0x10
080037eb lsls     r3, r3, #0x13
080037ed lsls     r2, r2, #0x10
080037ef lsrs     r3, r3, #0x13
080037f1 orrs     r3, r2
080037f3 movs     r2, #0x80
080037f5 lsls     r2, r2, #6
080037f7 orrs     r3, r2
080037f9 movs     r2, #0x80
080037fb str      r3, [r1, #4]
080037fd ldr      r3, [pc, #0xc]
080037ff lsls     r2, r2, #0x14
08003801 str      r2, [r3, #8]
08003803 bx       lr
