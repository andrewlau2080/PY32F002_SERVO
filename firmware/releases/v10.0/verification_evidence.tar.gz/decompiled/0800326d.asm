0800326d ldr      r3, [pc, #0x134]
0800326f add      r2, sp, #0x60
08003271 strh     r7, [r3, #2]
08003273 ldrh     r1, [r2, #2]
08003275 ldr      r2, [sp, #0x68]
08003277 strh     r1, [r3]
08003279 str      r2, [r3, #4]
0800327b ldr      r2, [sp, #0x24]
0800327d strh     r2, [r3, #0x1e]
