080023dd push     {r4, r5, r6, lr}
080023df movs     r5, r1
080023e1 ldr      r6, [pc, #0x24]
080023e3 movs     r4, r2
080023e5 movs     r1, r0
080023e7 movs     r2, r6
080023e9 movs     r0, #0
080023eb bl       #0x80023a9
