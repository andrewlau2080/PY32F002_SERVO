int sub_8003ff7(unsigned int a0)
{
    if (a0 == 0xffffffff)
        goto LABEL_0x8003ffb;
    return sub_8003fe7();
}
