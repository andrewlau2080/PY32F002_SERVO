void sub_80035ad(unsigned int a0, unsigned int a1, unsigned int a2, unsigned int a3)
{
    unsigned int v1;  // r2
    unsigned int v2;  // r4
    char v0;  // [bp+0x7c]

    v1 = 31;
    if (v2 != 2)
        v1 = 0xf800;
    sub_8002371(4, &v0, v1, a3); /* do not return */
}
