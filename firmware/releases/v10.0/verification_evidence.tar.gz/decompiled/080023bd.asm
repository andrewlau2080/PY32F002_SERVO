080023bd movs     r3, #1
080023bf str      r3, [sp, #8]
080023c1 ldr      r3, [pc, #0x14]
080023c3 adds     r4, #2
080023c5 str      r6, [sp, #0xc]
080023c7 str      r5, [sp, #4]
080023c9 str      r3, [sp]
080023cb movs     r2, #0x9c
080023cd movs     r3, #0x16
080023cf movs     r1, #0xf5
080023d1 uxth     r0, r4
080023d3 bl       #0x800224d
