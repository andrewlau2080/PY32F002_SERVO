extern char _binary__tmp_servo_original_v96_app_bin_start;
extern unsigned int g_40021004;
extern unsigned int g_e000ed08;

int sub_80037e1(unsigned int a0)
{
    g_40021004 = *(int *)0x1fff0f04 & 0x1fff | (g_40021004 >> 16) * 0x10000 | 0x2000;
    g_e000ed08 = &_binary__tmp_servo_original_v96_app_bin_start;
    return a0;
}
