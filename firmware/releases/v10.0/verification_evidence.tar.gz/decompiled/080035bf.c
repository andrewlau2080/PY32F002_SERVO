extern unsigned short g_20000010;
extern char g_20000013;
extern unsigned short g_20000026;
extern char g_20000028;

int sub_80035bf(unsigned int a0, unsigned int a1, unsigned int a2, unsigned int a3, unsigned int a4, unsigned int a5, unsigned int a6, unsigned int a7, unsigned int a8, unsigned int a9, unsigned int a10, unsigned int a11, unsigned short a12, unsigned int a13, char a14)
{
    char v0;  // r4
    unsigned short v1;  // r6

    g_20000013 = v0;
    g_20000026 = a12;
    g_20000010 = v1;
    g_20000028 = a14;
}
