08004947 push     {r0, lr}
08004949 movs     r0, #0
0800494b bl       #0x8004959
0800494f pop      {r1, pc}
