int sub_8004783(void)
{
    unsigned int v0;  // r0

    return v0;
}
