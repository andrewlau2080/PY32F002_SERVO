int sub_8004e7d(unsigned int a0)
{
}
