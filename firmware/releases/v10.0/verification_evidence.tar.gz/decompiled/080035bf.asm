080035bf ldr      r3, [pc, #0xa4]
080035c1 ldr      r2, [sp, #0x20]
080035c3 strb     r4, [r3, #0x13]
080035c5 strh     r2, [r3, #0x26]
080035c7 ldr      r2, [sp, #0x28]
080035c9 strh     r6, [r3, #0x10]
080035cb adds     r3, #0x28
080035cd strb     r2, [r3]
080035cf b        #0x8003399
