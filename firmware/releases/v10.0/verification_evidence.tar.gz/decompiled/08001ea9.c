typedef struct st_8001ea9_3 {
    char padding_0[8];
    unsigned int field_8;
} st_8001ea9_3;

extern char _binary__tmp_servo_original_v96_app_bin_start;
extern char g_200002a0;
extern char g_200002a1;
extern char g_200002e4;
extern unsigned int g_200002e8;
extern unsigned int g_200002ec;
extern unsigned int g_200002f0;
extern unsigned int g_200002f4;
extern unsigned int g_200002f8;
extern unsigned int g_200002fc;
extern unsigned int g_20000300;
extern unsigned int g_20000304;
extern char g_20000324;
extern char g_20000325;
extern char g_20000326;
extern unsigned int g_20000328;
extern char g_2000042c;
extern unsigned int g_4001380c;
extern unsigned int g_40013814;
extern unsigned int g_40021034;
extern unsigned int g_40021040;
extern unsigned int g_e000e100;
extern unsigned int g_e000e418;

void sub_8001ea9(unsigned int a0)
{
    unsigned int v9;  // r0
    int v10;  // r0
    unsigned int v11;  // r0
    unsigned int v12;  // r0
    int v13;  // r0
    unsigned int v15;  // r0
    st_8001ea9_3 *v0;  // [bp-0x3c], Other Possible Types: unsigned int
    unsigned int v1;  // [bp-0x38]
    unsigned int v2;  // [bp-0x34]
    unsigned int v3;  // [bp-0x30]
    unsigned int v4;  // [bp-0x2c]
    unsigned int v5;  // [bp-0x28]
    unsigned int v6;  // [bp-0x24]
    unsigned int v7;  // [bp-0x20]
    unsigned int v8;  // [bp-0x1c]

    if (g_200002e4)
    {
        g_20000325 = 36;
        *(unsigned int *)(g_200002e8 + 12) = *(int *)(g_200002e8 + 12) & 0xffffdfff;
        g_20000328 = 0;
        g_20000325 = 0;
        g_20000326 = 0;
        g_20000324 = 0;
    }
    g_200002f0 = 0;
    g_200002f4 = 0;
    g_200002f8 = 0;
    g_20000300 = 0;
    g_20000304 = 0;
    g_200002fc = 12;
    g_200002e8 = 0x40013800;
    g_200002ec = a0;
    v0 = g_20000325;
    if (!g_20000325)
    {
        g_20000324 = v0;
        g_40021034 = g_40021034 | 1;
        v3 = g_40021034 & 1;
        g_40021034 = g_40021034 | 2;
        v2 = g_40021034 & 2;
        g_40021040 = g_40021040 | 0x4000;
        v5 = 2;
        v1 = g_40021040 & 0x4000;
        v4 = 128;
        v8 = 8;
        v6 = 1;
        v7 = 2;
        sub_8000925(0x50000000, &v4);
        v4 = 4;
        v5 = 2;
        v6 = 1;
        v7 = 2;
        v8 = v0;
        sub_8000925(0x50000400, &v4);
    }
    g_20000325 = 36;
    *(unsigned int *)(g_200002e8 + 12) = *(int *)(g_200002e8 + 12) & 0xffffdfff;
    *(unsigned int *)(g_200002e8 + 16) = *(int *)(g_200002e8 + 16) & 0xffffdfff | g_200002f4;
    *(unsigned int *)(g_200002e8 + 12) = g_200002f0 | g_200002f8 | g_200002fc | *(int *)(g_200002e8 + 12) & 0xffffe9f3;
    *(unsigned int *)(g_200002e8 + 20) = *(int *)(g_200002e8 + 20) & 0xfffff7ff | g_20000304;
    *(unsigned int *)(g_200002e8 + 20) = *(int *)(g_200002e8 + 20) & 0xfffffcff | g_20000300;
    if (g_20000304 == 0x800)
    {
        v9 = sub_80008fd();
        v10 = sub_8004671(v9 * 25, g_200002ec * 2);
        sub_800477d(v10, 100);
        v11 = sub_8004671(850, 100);
        v0 = g_200002e8;
        v0->field_8 = sub_8004671(v10, 100) * 16 + (7 & v11) + (v11 * 2 & 496);
    }
    else
    {
        v12 = sub_80008fd();
        v13 = sub_8004671(v12 * 25, g_200002ec * 4);
        sub_800477d(v13, 100);
        v0 = sub_8004671(1650, 100);
        v15 = sub_8004671(v13, 100);
        *(unsigned int *)(g_200002e8 + 8) = v0 + v15 * 16;
    }
    if (*(int *)0x20000308 && *(int *)0x20000308 * 0x2000000 < 0)
    {
        *(unsigned int *)(g_200002e8 + 20) = *(int *)(g_200002e8 + 20) & 0xffffefff | *(int *)0x2000030c;
        if (*(int *)0x2000030c == 0x1000)
            *(unsigned int *)(g_200002e8 + 20) = *(int *)(g_200002e8 + 20) & 0xffff9fff | *(int *)0x20000310;
    }
    *(unsigned int *)(g_200002e8 + 16) = *(int *)(g_200002e8 + 16) & 0xfffff7ff;
    *(unsigned int *)(g_200002e8 + 20) = *(int *)(g_200002e8 + 20) & ~8;
    *(unsigned int *)(g_200002e8 + 12) = 0x2000 | *(int *)(g_200002e8 + 12);
    g_20000328 = 0;
    g_20000325 = 32;
    g_20000326 = 32;
    g_200002e4 = 1;
    g_200002a0 = 0;
    g_200002a1 = 0;
    g_2000042c = 0;
    g_4001380c = 32 | g_4001380c;
    g_40013814 = 1 | g_40013814;
    g_e000e418 = g_e000e418 & 0xffffff | 0x40000000;
    g_e000e100 = &_binary__tmp_servo_original_v96_app_bin_start;
    return;
}
