void sub_8002daf(void)
{
    unsigned int v5;  // r4
    unsigned int v6;  // r1
    char v0;  // [bp+0x38]
    char v1;  // [bp+0x7c]
    char v2[10];  // [bp+0x9c]
    char v3;  // [bp+0xa6]
    char v4;  // [bp+0xa7]

    sub_80021d5(&v1);
    if (v5 != 63)
        goto LABEL_0x8002da3;
    sub_80021d5("sendxy=1");
    v2 = 50;
    v3 = 0xff;
    v6 = "EXTPWM";
    if (*0x2000041b)
        v6 = "INTPWM";
    sub_8003aa1(&v4);
    sub_80024b1(v2, v6, &v3, &v0); /* do not return */
}
