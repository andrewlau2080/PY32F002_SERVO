0800146f ldr      r3, [pc, #0x29c]
08001471 movs     r1, #2
08001473 movs     r2, r3
08001475 adds     r2, #0x57
08001477 strb     r1, [r2]
08001479 movs     r2, #1
0800147b cmp      r6, r4
0800147d blo      #0x8001483
0800147f cmp      r4, r6
08001481 sbcs     r2, r2
08001483 movs     r1, r3
08001485 adds     r1, #0x52
08001487 strb     r2, [r1]
08001489 movs     r1, r3
0800148b adds     r1, #0x53
0800148d strb     r2, [r1]
0800148f movs     r1, r3
08001491 movs     r0, #0
08001493 adds     r1, #0x50
08001495 strh     r0, [r1]
08001497 movs     r1, r3
08001499 adds     r1, #0x56
0800149b strb     r0, [r1]
0800149d ldr      r1, [pc, #0x284]
0800149f adds     r1, #0x7e
080014a1 strb     r0, [r1]
080014a3 movs     r1, #0xaf
080014a5 lsls     r1, r1, #2
080014a7 cmp      r5, r1
080014a9 bhs      #0x80014ad
080014ab b        #0x8001699
080014ad cmp      r2, r0
080014af bne      #0x80014b3
080014b1 b        #0x8001699
080014b3 movs     r1, r3
080014b5 adds     r3, #0x36
080014b7 strb     r2, [r3]
080014b9 ldr      r3, [pc, #0x26c]
080014bb ldr      r2, [sp, #0x6c]
080014bd adds     r1, #0x35
080014bf adds     r0, #1
080014c1 strb     r0, [r1]
080014c3 str      r2, [r3]
080014c5 b        #0x8001511
08001699 bl       #0x80002d9
0800169d b        #0x8001511
