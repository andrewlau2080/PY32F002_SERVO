extern unsigned short g_20000330;
extern unsigned short g_20000332;
extern unsigned int g_20000334;
extern char g_20000338;
extern char g_20000339;
extern unsigned int g_2000033c;

int sub_8000189(unsigned int a0)
{
    g_20000330 = 0;
    g_20000332 = 0;
    g_20000338 = 1;
    g_20000339 = 1;
    g_20000334 = a0 + 900;
    g_2000033c = g_2000033c + 1;
    return a0 + 900;
}
