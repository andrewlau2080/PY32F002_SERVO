08003811 push     {r4, r5, r6, lr}
08003813 ldr      r5, [pc, #0x30]
08003815 ldr      r6, [pc, #0x30]
08003817 subs     r6, r6, r5
08003819 asrs     r6, r6, #2
0800381b beq      #0x8003829
0800381d movs     r4, #0
0800381f ldm      r5!, {r3}
08003821 adds     r4, #1
08003823 blx      r3
08003829 bl       #0x8002771
0800382d ldr      r5, [pc, #0x1c]
0800382f ldr      r6, [pc, #0x20]
08003831 subs     r6, r6, r5
08003833 asrs     r6, r6, #2
08003835 beq      #0x8003843
08003837 movs     r4, #0
08003839 ldm      r5!, {r3}
0800383b adds     r4, #1
0800383d blx      r3
08003843 pop      {r4, r5, r6, pc}
