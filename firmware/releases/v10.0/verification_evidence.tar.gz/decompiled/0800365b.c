int sub_800365b(void)
{
}
