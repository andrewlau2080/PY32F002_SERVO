void sub_8004e5d(unsigned int a0, unsigned int a1)
{
}
