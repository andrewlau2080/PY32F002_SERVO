int sub_80036bd(void)
{
    unsigned int v0;  // r0

    return v0;
}
