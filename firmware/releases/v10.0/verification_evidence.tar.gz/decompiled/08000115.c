extern unsigned int g_20000328;
extern unsigned int g_2000032c;

int sub_8000115(void)
{
    unsigned int v2;  // r0
    unsigned int v0;  // [bp-0x8]
    unsigned int v1;  // [bp-0x4]

    if (*0x200002e4)
    {
        v0 = *(int *)0x40013800;
        if (v0 * 0x10000000)
        {
            v1 = *(int *)0x40013804;
            g_20000328 = 0;
            g_2000032c = g_2000032c + 1;
        }
    }
    return v2;
}
