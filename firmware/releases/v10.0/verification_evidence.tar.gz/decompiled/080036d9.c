extern unsigned int g_4002180c;

int sub_80036d9(void)
{
    unsigned int v0;  // r0
    int v1;  // r0

    if (g_4002180c & 8)
    {
        g_4002180c = 8;
        v1 = sub_80003f5(v0, g_4002180c);
    }
    return v1;
}
