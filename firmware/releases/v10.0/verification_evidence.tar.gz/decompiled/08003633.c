int sub_8003633(void)
{
}
