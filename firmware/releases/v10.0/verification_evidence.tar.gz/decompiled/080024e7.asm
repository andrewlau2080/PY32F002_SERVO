080024e7 movs     r0, r4
080024e9 movs     r3, #0x1f
080024eb ldr      r2, [pc, #0x164]
080024ed ldr      r1, [pc, #0x164]
080024ef str      r4, [sp]
080024f1 bl       #0x80022f1
