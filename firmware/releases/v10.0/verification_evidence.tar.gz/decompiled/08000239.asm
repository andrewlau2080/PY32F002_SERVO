08000239 movs     r3, #0xfa
0800023b movs     r2, r0
0800023d lsls     r3, r3, #1
0800023f movs     r0, #1
08000241 cmp      r2, r3
08000243 blo      #0x800024f
08000245 ldr      r0, [pc, #8]
08000247 cmp      r0, r2
08000249 sbcs     r0, r0
0800024b rsbs     r0, r0, #0
0800024d lsls     r0, r0, #1
0800024f bx       lr
