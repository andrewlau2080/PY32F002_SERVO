typedef struct st_8004103_0 {
    char padding_0[12];
    unsigned int field_c;
} st_8004103_0;

int sub_8004103(unsigned int a0, unsigned int a1, unsigned int a2, unsigned int a3, unsigned int a4, unsigned int a5, unsigned int a6, unsigned int a7, unsigned int a8, unsigned int a9)
{
    st_8004103_0 *v0;  // r4
    int v1;  // r5

    if ((int)(v0->field_c - a9) <= v1 + 1)
        goto LABEL_0x8004133;
    else
        goto LABEL_0x800410f;
}
