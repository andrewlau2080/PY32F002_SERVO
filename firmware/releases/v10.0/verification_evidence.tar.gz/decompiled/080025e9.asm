080025e9 cmp      r6, #0xa
080025eb bne      #0x800259d
080025ed ldr      r2, [pc, #0xb4]
080025ef ldr      r1, [pc, #0xb8]
080025f1 ldr      r0, [pc, #0xb8]
080025f3 bl       #0x80023dd
