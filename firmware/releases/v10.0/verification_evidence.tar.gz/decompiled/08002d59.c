void sub_8002d59(void)
{
    sub_8002725(0x38400); /* do not return */
}
