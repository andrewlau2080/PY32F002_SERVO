extern void g_80049e4;

void sub_80021d5(void* a0)
{
    unsigned int i;  // r0
    unsigned int v1;  // r7
    unsigned int v2;  // r6

    i = sub_8003ab1();
    v1 = 16;
    sub_8000155();
    while (i)
    {
        v2 = i;
        if (v2 > 16)
            v2 = v1;
        sub_8000f95(a0, v2 & 0xffff);
        a0 += v2;
        i -= v2;
        sub_80010b5();
    }
    sub_8000f95(&g_80049e4, 3);
    sub_8001e1d(2);
    sub_8000155();
    return;
}
