0800400b movs     r3, #1
0800400d mov      ip, r3
0800400f mov      r3, sl
08004011 ldr      r2, [r4, #0xc]
08004013 ldr      r3, [r3]
08004015 add      r8, ip
08004017 subs     r5, r2, r3
08004019 cmp      r5, r8
0800401b ble      #0x800405f
0800405f movs     r3, #0x43
08004061 ldr      r2, [r4]
08004063 ldrb     r3, [r4, r3]
08004065 subs     r1, r3, #1
08004067 sbcs     r3, r1
08004069 lsls     r2, r2, #0x1a
0800406b bmi      #0x8003fa3
0800406d b        #0x8003fb9
