08000001 lsrs     r0, r0, #0x10
08000003 movs     r0, #0
08000005 ldr      r1, [pc, #0x174]
08000007 lsrs     r0, r0, #0x20
08000009 adds     r6, #0xbd
0800000b lsrs     r0, r0, #0x20
0800000d adds     r6, #0xbf
0800000f lsrs     r0, r0, #0x20
08000011 movs     r0, r0
08000013 movs     r0, r0
08000015 movs     r0, r0
08000017 movs     r0, r0
08000019 movs     r0, r0
0800001b movs     r0, r0
0800001d movs     r0, r0
0800001f movs     r0, r0
08000021 movs     r0, r0
08000023 movs     r0, r0
08000025 movs     r0, r0
08000027 movs     r0, r0
08000029 movs     r0, r0
0800002b movs     r0, r0
0800002d adds     r6, #0xc5
0800002f lsrs     r0, r0, #0x20
08000031 movs     r0, r0
08000033 movs     r0, r0
08000035 movs     r0, r0
08000037 movs     r0, r0
08000039 adds     r6, #0xc7
0800003b lsrs     r0, r0, #0x20
0800003d adds     r6, #0xc9
0800003f lsrs     r0, r0, #0x20
08000041 movs     r0, r0
08000043 movs     r0, r0
08000045 movs     r0, r0
08000047 movs     r0, r0
08000049 movs     r0, r0
0800004b movs     r0, r0
0800004d ldr      r1, [pc, #0x2b4]
0800004f lsrs     r0, r0, #0x20
08000051 ldr      r1, [pc, #0x2b4]
08000053 lsrs     r0, r0, #0x20
08000055 ldr      r1, [pc, #0x2b4]
08000057 lsrs     r0, r0, #0x20
08000059 adds     r6, #0xd9
0800005b lsrs     r0, r0, #0x20
0800005d adds     r6, #0xf1
0800005f lsrs     r0, r0, #0x20
08000061 movs     r0, r0
08000063 movs     r0, r0
08000065 movs     r0, r0
08000067 movs     r0, r0
08000069 movs     r0, r0
0800006b movs     r0, r0
0800006d movs     r0, r0
0800006f movs     r0, r0
08000071 ldr      r1, [pc, #0x2b4]
08000073 lsrs     r0, r0, #0x20
08000075 ldr      r1, [pc, #0x2b4]
08000077 lsrs     r0, r0, #0x20
08000079 adds     r6, #0xf3
0800007b lsrs     r0, r0, #0x20
0800007d movs     r0, r0
0800007f movs     r0, r0
08000081 movs     r0, r0
08000083 movs     r0, r0
08000085 ldr      r1, [pc, #0x2b4]
08000087 lsrs     r0, r0, #0x20
08000089 movs     r0, r0
0800008b movs     r0, r0
0800008d movs     r0, r0
0800008f movs     r0, r0
08000091 movs     r0, r0
08000093 movs     r0, r0
08000095 adds     r6, #0xfb
08000097 lsrs     r0, r0, #0x20
08000099 movs     r0, r0
0800009b movs     r0, r0
0800009d ldr      r1, [pc, #0x2b4]
0800009f lsrs     r0, r0, #0x20
080000a1 movs     r0, r0
080000a3 movs     r0, r0
080000a5 ldr      r1, [pc, #0x2b4]
080000a7 lsrs     r0, r0, #0x20
080000a9 movs     r0, r0
080000ab movs     r0, r0
080000ad adds     r7, #0xa1
080000af lsrs     r0, r0, #0x20
080000b1 movs     r0, r0
080000b3 movs     r0, r0
080000b5 movs     r0, r0
080000b7 movs     r0, r0
080000b9 movs     r0, r0
080000bb movs     r0, r0
080000bd movs     r0, r0
080000bf movs     r0, r0
