08004cf7 lsls     r7, r7, #3
08004cf9 asrs     r0, r0, #8
08004cfb lsls     r2, r7, #1
08004cfd movs     r4, r0
08004cff movs     r0, r0
08004d01 ldr      r4, [pc, #0x154]
08004d03 lsrs     r0, r0, #0x20
08004d05 ldr      r4, [pc, #0xc0]
08004d07 lsrs     r0, r0, #0x20
08004d09 lsls     r0, r4, #6
08004d0b movs     r0, r0
08004d0d lsls     r0, r7, #1
08004d0f movs     r0, r0
08004d11 lsls     r0, r4, #0xc
08004d13 movs     r0, r0
08004d15 movs     r0, r1
08004d17 movs     r0, r0
08004d19 ldr      r4, [pc, #0x168]
08004d1b lsrs     r0, r0, #0x20
08004d1d ldr      r4, [pc, #0xc0]
08004d1f lsrs     r0, r0, #0x20
08004d21 movs     r4, r4
08004d23 movs     r0, r0
08004d25 movs     r0, r1
08004d27 movs     r0, r0
08004d29 lsls     r0, r7, #1
08004d2b movs     r0, r0
08004d2d movs     r2, r0
08004d2f movs     r0, r0
08004d31 ldr      r4, [pc, #0x178]
08004d33 lsrs     r0, r0, #0x20
08004d35 ldr      r3, [pc, #0x34]
08004d37 lsrs     r0, r0, #0x20
08004d39 lsls     r0, r7, #1
08004d3b movs     r0, r0
08004d3d movs     r0, r0
08004d3f movs     r0, r0
08004d41 lsls     r0, r2, #6
08004d43 movs     r0, r0
08004d45 movs     r5, r0
08004d47 movs     r0, r0
08004d49 ldr      r4, [pc, #0x184]
08004d4b lsrs     r0, r0, #0x20
08004d4d ldr      r3, [pc, #0x34]
08004d4f lsrs     r0, r0, #0x20
08004d51 movs     r3, r0
08004d53 movs     r0, r0
08004d55 movs     r1, r0
08004d57 movs     r0, r0
08004d59 movs     r2, r1
08004d5b movs     r0, r0
08004d5d movs     r1, r0
08004d5f movs     r0, r0
08004d61 ldr      r4, [pc, #0x190]
08004d63 lsrs     r0, r0, #0x20
08004d65 ldr      r3, [pc, #0x34]
08004d67 lsrs     r0, r0, #0x20
08004d69 lsls     r0, r2, #1
08004d6b movs     r0, r0
08004d6d movs     r4, r2
08004d6f movs     r0, r0
08004d71 lsls     r0, r6, #3
08004d73 movs     r0, r0
08004d75 movs     r5, r0
08004d77 movs     r0, r0
08004d79 ldr      r4, [pc, #0x104]
08004d7b lsrs     r0, r0, #0x20
08004d7d ldr      r4, [pc, #0x9c]
08004d7f lsrs     r0, r0, #0x20
08004d81 lsls     r0, r4, #2
08004d83 movs     r0, r0
08004d85 movs     r0, r0
08004d87 movs     r0, r0
08004d89 lsls     r4, r5, #4
08004d8b movs     r0, r0
08004d8d movs     r4, r0
08004d8f movs     r0, r0
08004d91 ldr      r4, [pc, #0x118]
08004d93 lsrs     r0, r0, #0x20
08004d95 ldr      r3, [pc, #0x34]
08004d97 lsrs     r0, r0, #0x20
08004d99 movs     r3, r0
08004d9b movs     r0, r0
08004d9d movs     r0, r0
08004d9f movs     r0, r0
08004da1 movs     r2, r1
08004da3 movs     r0, r0
08004da5 movs     r1, r0
08004da7 movs     r0, r0
08004da9 ldr      r4, [pc, #0x124]
08004dab lsrs     r0, r0, #0x20
08004dad ldr      r4, [pc, #0x9c]
08004daf lsrs     r0, r0, #0x20
08004db1 lsls     r4, r5, #9
08004db3 movs     r0, r0
08004db5 movs     r0, r5
08004db7 movs     r0, r0
08004db9 lsls     r4, r7, #0xa
08004dbb movs     r0, r0
08004dbd movs     r2, r1
08004dbf movs     r0, r0
08004dc1 ldr      r4, [pc, #0x138]
08004dc3 lsrs     r0, r0, #0x20
08004dc5 ldr      r4, [pc, #0xc0]
08004dc7 lsrs     r0, r0, #0x20
