08002291 push     {r0, r1, r2, r3, r4, r5, r6, lr}
08002293 movs     r6, r0
08002295 ldr      r0, [pc, #0x50]
08002297 movs     r5, r1
08002299 bl       #0x80021d5
0800229d movs     r0, #0x1e
0800229f bl       #0x8001e1d
080022a3 movs     r4, #0x10
080022a5 movs     r1, #0
080022a7 movs     r2, #0xf0
080022a9 movs     r0, r1
080022ab movs     r3, #0x20
080022ad str      r4, [sp]
080022af lsls     r2, r2, #1
080022b1 bl       #0x8002221
