08002469 push     {r3, r4, r5, r6, r7, lr}
0800246b movs     r6, r3
0800246d add      r3, sp, #0x18
0800246f movs     r5, r2
08002471 ldrb     r7, [r3]
08002473 movs     r4, #0
08002475 bl       #0x8002291
