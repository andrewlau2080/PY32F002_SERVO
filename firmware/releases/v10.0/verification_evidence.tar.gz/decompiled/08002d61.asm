08002d61 movs     r0, #0xe1
08002d63 lsls     r0, r0, #0xa
08002d65 bl       #0x8001ea9
08002d69 ldr      r5, [pc, #0x260]
08002d6b movs     r0, r5
08002d6d bl       #0x80021d5
08002d71 movs     r0, #0x50
08002d73 bl       #0x8001e49
08002d77 movs     r0, r5
08002d79 bl       #0x80021d5
08002d7d ldr      r0, [pc, #0x250]
08002d7f bl       #0x80021d5
08002d83 ldr      r0, [pc, #0x250]
08002d85 bl       #0x80021d5
08002d89 movs     r0, #0xfa
08002d8b bl       #0x8001e49
08002d8f ldr      r5, [pc, #0x248]
08002d91 movs     r0, r5
08002d93 bl       #0x80021d5
08002d97 movs     r0, r5
08002d99 bl       #0x80021d5
08002d9d movs     r0, r5
08002d9f bl       #0x80021d5
08002da3 movs     r3, r4
08002da5 movs     r1, #0x10
08002da7 ldr      r2, [pc, #0x234]
08002da9 add      r0, sp, #0x7c
08002dab bl       #0x8003a1d
