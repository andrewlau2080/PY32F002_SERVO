080010b5 push     {r4, r5, r6, r7, lr}
080010b7 ldr      r3, [pc, #0x320]
080010b9 sub      sp, #0xac
080010bb adds     r3, #0x7a
080010bd ldrb     r3, [r3]
080010bf str      r3, [sp, #0x34]
080010c1 cmp      r3, #0
080010c3 bne      #0x80010c7
080010c5 b        #0x80012d7
080010c7 movs     r2, #4
080010c9 ldr      r3, [pc, #0x310]
080010cb str      r2, [sp, #0x7c]
080010cd ldr      r3, [r3, #0x20]
080012d7 add      sp, #0xac
080012d9 pop      {r4, r5, r6, r7, pc}
