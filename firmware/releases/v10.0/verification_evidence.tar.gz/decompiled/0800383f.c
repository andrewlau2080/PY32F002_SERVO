int sub_800383f(void)
{
    unsigned int v0;  // r6
    unsigned int v1;  // r4

    if (v0 != v1)
        goto LABEL_0x8003839;
    else
        goto LABEL_0x8003843;
}
