08004173 ldr      r3, [r4]
08004175 lsls     r0, r3, #0x18
08004177 bmi      #0x800417f
08004179 lsls     r3, r3, #0x19
0800417b bpl      #0x800417f
0800417d b        #0x80042c9
0800417f ldr      r3, [r2]
08004181 adds     r0, r3, #4
08004183 str      r0, [r2]
08004185 ldr      r6, [r3]
08004187 ldr      r3, [pc, #0x168]
08004189 mov      fp, r3
0800418b cmp      r1, #0x6f
0800418d bne      #0x8004191
0800418f b        #0x80042e1
08004191 movs     r3, #0xa
08004193 mov      sl, r3
08004195 b        #0x8004209
08004209 movs     r3, #0x43
0800420b movs     r2, #0
0800420d strb     r2, [r4, r3]
080042c9 ldr      r3, [r2]
080042cb adds     r0, r3, #4
080042cd ldrh     r6, [r3]
080042cf str      r0, [r2]
080042d1 b        #0x8004187
080042e1 movs     r3, #8
080042e3 mov      sl, r3
080042e5 b        #0x8004209
