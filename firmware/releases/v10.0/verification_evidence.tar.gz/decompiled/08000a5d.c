extern unsigned int g_40021034;
extern unsigned int g_50000018;

void sub_8000a5d(void)
{
    unsigned int v0;  // [bp-0x28]
    unsigned int v1;  // [bp-0x24]
    unsigned int v2;  // [bp-0x20]
    unsigned int v3;  // [bp-0x1c]
    char v4;  // [bp-0x18]

    sub_80038f9(&v4, 0, 8);
    g_40021034 = g_40021034 | 1;
    v0 = g_40021034 & 1;
    v2 = 1;
    v1 = 32;
    v3 = 2;
    sub_8000925(0x50000000, &v1);
    g_50000018 = 32;
    return;
}
