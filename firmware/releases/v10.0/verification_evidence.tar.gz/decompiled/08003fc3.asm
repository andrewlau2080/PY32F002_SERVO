08003fc3 adds     r3, r0, #1
08003fc5 beq      #0x8003ffb
08003fc7 movs     r3, #6
08003fc9 ldr      r2, [r4]
08003fcb ands     r3, r2
08003fcd cmp      r3, #4
08003fcf beq      #0x8004039
08003fd1 ldr      r3, [r4, #8]
08003fd3 ldr      r2, [r4, #0x10]
08003fd5 cmp      r3, r2
08003fd7 ble      #0x8004055
08003fd9 movs     r1, #0
08003fdb mov      r8, r1
08003fdd subs     r3, r3, r2
08003fdf add      r8, r3
08003fe1 movs     r5, #0
08003fe3 adds     r4, #0x1a
08003fe5 b        #0x8003fed
08003fed movs     r3, #1
08003fef movs     r2, r4
08003ff1 movs     r1, r7
08003ff3 movs     r0, r6
08003ff5 blx      sb
08003ffb movs     r0, #1
08003ffd rsbs     r0, r0, #0
08003fff pop      {r4, r5, r6, r7}
08004001 mov      fp, r7
08004003 mov      sl, r6
08004005 mov      sb, r5
08004007 mov      r8, r4
08004009 pop      {r3, r4, r5, r6, r7, pc}
08004039 mov      r3, sl
0800403b ldr      r1, [r3]
0800403d ldr      r3, [r4, #0xc]
0800403f ldr      r2, [r4, #0x10]
08004041 subs     r1, r3, r1
08004043 mvns     r3, r1
08004045 asrs     r3, r3, #0x1f
08004047 ands     r3, r1
08004049 mov      r8, r3
0800404b ldr      r3, [r4, #8]
0800404d cmp      r3, r2
0800404f bgt      #0x8003fdd
08004051 cmp      r1, #0
08004053 bgt      #0x8003fe1
08004055 movs     r0, #0
08004057 b        #0x8003fff
