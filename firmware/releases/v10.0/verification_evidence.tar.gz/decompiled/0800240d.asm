0800240d push     {r4, r5, r6, lr}
0800240f movs     r4, r2
08002411 ldr      r2, [r1, #4]
08002413 movs     r5, r0
08002415 movs     r6, r1
08002417 ldr      r3, [r1, #8]
08002419 sub      sp, #0x30
0800241b cmp      r2, #0
0800241d beq      #0x800244f
0800241f ldrb     r1, [r2]
08002421 cmp      r1, #0
08002423 beq      #0x800244f
08002425 str      r2, [sp]
08002427 movs     r1, #0x24
08002429 ldr      r2, [pc, #0x30]
0800242b add      r0, sp, #0xc
0800242d bl       #0x8003a1d
0800244f movs     r1, #0x24
08002451 ldr      r2, [pc, #0x10]
08002453 add      r0, sp, #0xc
08002455 bl       #0x8003a1d
