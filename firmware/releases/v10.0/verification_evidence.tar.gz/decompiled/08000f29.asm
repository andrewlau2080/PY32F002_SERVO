08000f29 push     {r4, r5, r6, r7, lr}
08000f2b movs     r5, #0
08000f2d sub      sp, #0x24
08000f2f movs     r7, r3
08000f31 add      r3, sp, #0x38
08000f33 movs     r6, r2
08000f35 movs     r2, #0
08000f37 ldrsh    r3, [r3, r2]
08000f39 str      r0, [sp, #0x14]
08000f3b str      r1, [sp, #0x18]
08000f3d str      r3, [sp, #0x1c]
08000f3f bl       #0x80007b9
08000f43 ldr      r4, [pc, #0x4c]
08000f45 str      r5, [r4, #0x5c]
08000f47 strh     r5, [r4, #0x3a]
08000f49 strh     r5, [r4, #0x38]
08000f4b bl       #0x80002c1
08000f4f movs     r2, r4
08000f51 movs     r3, #1
08000f53 adds     r2, #0x3c
08000f55 strb     r3, [r2]
08000f57 movs     r2, r4
08000f59 adds     r2, #0x57
08000f5b strb     r3, [r2]
08000f5d movs     r3, r4
08000f5f adds     r3, #0x55
08000f61 strb     r5, [r3]
08000f63 movs     r3, r4
08000f65 adds     r3, #0x52
08000f67 strb     r5, [r3]
08000f69 movs     r3, r4
08000f6b adds     r4, #0x56
08000f6d adds     r3, #0x53
08000f6f strb     r5, [r3]
08000f71 strb     r5, [r4]
08000f73 bl       #0x80002d9
08000f77 movs     r3, #2
08000f79 str      r3, [sp, #8]
08000f7b ldr      r3, [sp, #0x1c]
08000f7d movs     r2, r6
08000f7f str      r3, [sp]
08000f81 ldr      r1, [sp, #0x18]
08000f83 movs     r3, r7
08000f85 ldr      r0, [sp, #0x14]
08000f87 str      r5, [sp, #4]
08000f89 bl       #0x80005a1
08000f8d add      sp, #0x24
08000f8f pop      {r4, r5, r6, r7, pc}
