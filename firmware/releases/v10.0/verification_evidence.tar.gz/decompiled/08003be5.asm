08003be5 push     {r4, r5, r6, r7, lr}
08003be7 mov      r6, sb
08003be9 mov      r5, r8
08003beb mov      lr, fp
08003bed mov      r7, sl
08003bef push     {r5, r6, r7, lr}
08003bf1 ldr      r3, [r2, #8]
08003bf3 sub      sp, #0xc
08003bf5 movs     r5, r1
08003bf7 mov      sb, r2
08003bf9 str      r0, [sp, #4]
08003bfb cmp      r3, #0
08003bfd beq      #0x8003cd5
08003bff ldr      r7, [r2]
08003c01 ldr      r0, [r1]
08003c03 ldr      r4, [r1, #8]
08003c05 b        #0x8003c8f
08003c07 movs     r2, #0x90
08003c09 ldrh     r3, [r5, #0xc]
08003c0b lsls     r2, r2, #3
08003c0d tst      r3, r2
08003c0f beq      #0x8003c6f
08003c11 ldr      r1, [r5, #0x10]
08003c13 subs     r2, r0, r1
08003c15 mov      fp, r2
08003c17 ldr      r0, [r5, #0x14]
08003c19 lsls     r2, r0, #1
08003c1b adds     r2, r2, r0
08003c1d lsrs     r0, r2, #0x1f
08003c1f adds     r2, r0, r2
08003c21 adds     r0, r6, #1
08003c23 asrs     r2, r2, #1
08003c25 add      r0, fp
08003c27 mov      r8, r2
08003c29 cmp      r0, r2
08003c2b bls      #0x8003c31
08003c2d mov      r8, r0
08003c2f movs     r2, r0
08003c31 movs     r0, #0x80
08003c33 lsls     r0, r0, #3
08003c35 tst      r3, r0
08003c37 beq      #0x8003ca7
08003c39 movs     r1, r2
08003c3b ldr      r0, [sp, #4]
08003c3d bl       #0x80044d9
08003c41 subs     r4, r0, #0
08003c43 beq      #0x8003ceb
08003c45 mov      r2, fp
08003c47 ldr      r1, [r5, #0x10]
08003c49 bl       #0x8003855
08003c4d ldrh     r3, [r5, #0xc]
08003c4f ldr      r2, [pc, #0xa4]
08003c51 ands     r3, r2
08003c53 movs     r2, #0x80
08003c55 orrs     r3, r2
08003c57 strh     r3, [r5, #0xc]
08003c59 mov      r3, r8
08003c5b movs     r0, r4
08003c5d mov      r2, fp
08003c5f str      r4, [r5, #0x10]
08003c61 mov      r8, r6
08003c63 movs     r4, r6
08003c65 add      r0, fp
08003c67 str      r3, [r5, #0x14]
08003c69 subs     r3, r3, r2
08003c6b str      r0, [r5]
08003c6d str      r3, [r5, #8]
08003c6f mov      r2, r8
08003c71 mov      r1, sl
08003c73 bl       #0x800436d
08003c77 ldr      r3, [r5, #8]
08003c79 ldr      r0, [r5]
08003c7b subs     r4, r3, r4
08003c7d mov      r3, sb
08003c7f ldr      r3, [r3, #8]
08003c81 add      r0, r8
08003c83 subs     r6, r3, r6
08003c85 mov      r3, sb
08003c87 str      r4, [r5, #8]
08003c89 str      r0, [r5]
08003c8b str      r6, [r3, #8]
08003c8d beq      #0x8003cd5
08003c8f ldr      r3, [r7]
08003c91 ldr      r6, [r7, #4]
08003c93 mov      sl, r3
08003c95 adds     r7, #8
08003c97 cmp      r6, #0
08003c99 beq      #0x8003c8f
08003c9b mov      r8, r4
08003c9d cmp      r4, r6
08003c9f bls      #0x8003c07
08003ca1 movs     r4, r6
08003ca3 mov      r8, r6
08003ca5 b        #0x8003c6f
08003ca7 ldr      r0, [sp, #4]
08003ca9 bl       #0x800459d
08003cad subs     r4, r0, #0
08003caf bne      #0x8003c59
08003cb1 ldr      r4, [sp, #4]
08003cb3 ldr      r1, [r5, #0x10]
08003cb5 movs     r0, r4
08003cb7 bl       #0x8004419
08003cbb movs     r3, #0xc
08003cbd str      r3, [r4]
08003cbf movs     r2, #0x40
08003cc1 ldrh     r3, [r5, #0xc]
08003cc3 movs     r0, #1
08003cc5 orrs     r3, r2
08003cc7 strh     r3, [r5, #0xc]
08003cc9 mov      r2, sb
08003ccb movs     r3, #0
08003ccd rsbs     r0, r0, #0
08003ccf str      r3, [r2, #8]
08003cd1 str      r3, [r2, #4]
08003cd3 b        #0x8003cdd
08003cd5 movs     r3, #0
08003cd7 mov      r2, sb
08003cd9 movs     r0, #0
08003cdb str      r3, [r2, #4]
08003cdd add      sp, #0xc
08003cdf pop      {r4, r5, r6, r7}
08003ce1 mov      fp, r7
08003ce3 mov      sl, r6
08003ce5 mov      sb, r5
08003ce7 mov      r8, r4
08003ce9 pop      {r4, r5, r6, r7, pc}
08003ceb movs     r3, #0xc
08003ced ldr      r2, [sp, #4]
08003cef str      r3, [r2]
08003cf1 b        #0x8003cbf
