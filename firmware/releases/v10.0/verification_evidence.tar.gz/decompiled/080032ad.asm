080032ad ldr      r3, [pc, #0xf4]
080032af strh     r5, [r3, #0xa]
080032b1 strh     r4, [r3, #8]
