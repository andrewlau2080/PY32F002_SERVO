void sub_8004cf7(void)
{
}
