typedef struct st_8001d4d_0 {
    char padding_0[32];
    unsigned int field_20;
} st_8001d4d_0;

void sub_8001d4d(unsigned int a0, unsigned int a1, st_8001d4d_0 *a2, unsigned int a3, unsigned int a4, unsigned int a5, unsigned int a6, unsigned int a7, unsigned int a8, unsigned int a9, unsigned int a10, unsigned int a11, unsigned int a12, unsigned int a13, unsigned int a14, unsigned int a15, unsigned int a16, unsigned int a17, unsigned int a18, unsigned int a19, unsigned int a20, unsigned int a21, unsigned int a22, unsigned int a23, unsigned int a24, unsigned int a25, unsigned int a26, unsigned int a27, unsigned int a28, unsigned int a29, unsigned int a30, unsigned int a31, unsigned int a32, unsigned int a33, unsigned int a34, unsigned int a35, unsigned int a36, unsigned int a37, unsigned int a38, unsigned short a39, unsigned int a40, unsigned int a41, unsigned int a42, unsigned int a43, unsigned int a44)
{
    sub_80010cf(a0, a1, a2, a2->field_20, a4, a5, a6, a7, a8, a9, a10, a11, a12, a13, a14, a15, a16, a17, a18, a19, a20, a21, a22, a23, a24, a25, a26, a27, a28, a29, a30, a31, a32, a33, a34, a35, a36, a37, a38, a39, a40, a41, a42, a43, a44);
}
