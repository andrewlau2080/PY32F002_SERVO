int sub_8002755(unsigned int a0, unsigned int a1, unsigned int a2, unsigned int a3, char a4, unsigned int a5, unsigned int a6, unsigned int a7, unsigned int a8, unsigned int a9, unsigned int a10, unsigned int a11)
{
    sub_80021d5(&a4);
    return sub_8001e49(50, a1);
}
