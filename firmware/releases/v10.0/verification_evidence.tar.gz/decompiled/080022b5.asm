080022b5 movs     r3, #0
080022b7 movs     r2, #0xaa
080022b9 str      r6, [sp, #0xc]
080022bb ldr      r6, [pc, #0x30]
080022bd str      r3, [sp, #8]
080022bf str      r6, [sp]
080022c1 movs     r1, #3
080022c3 movs     r0, #6
080022c5 str      r4, [sp, #4]
080022c7 adds     r3, #0x1a
080022c9 lsls     r2, r2, #1
080022cb bl       #0x800224d
