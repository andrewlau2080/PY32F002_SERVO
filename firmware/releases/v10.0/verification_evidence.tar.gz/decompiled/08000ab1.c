extern unsigned short g_20000000;
extern char g_2000040c;
extern unsigned int g_20000410;
extern unsigned int g_20000414;

int sub_8000ab1(unsigned int a0, unsigned int a1)
{
    unsigned int v3;  // r2
    int v4;  // r2
    unsigned int v5;  // r3
    unsigned int v6;  // r1
    unsigned short v7;  // r0
    unsigned int v8;  // r3
    unsigned int v9;  // r2
    unsigned int v0;  // [bp-0x20]
    unsigned int i;  // [bp-0x1c]
    unsigned int v2;  // [bp-0x18]

    v0 = a0;
    i = a1;
    v2 = v3;
    if (!(*(int *)(*(int *)0x200003e0 + 8) & 4) && g_2000040c != 1)
    {
        i = *(int *)(*(int *)0x200003e0 + 8) & 4;
        g_2000040c = 1;
        if (*(int *)(*(int *)0x200003e0 + 8) & 1)
        {
LABEL_8000add:
            g_20000410 = 0x100 | 0xfffff0fe & g_20000410;
            g_20000414 = 0;
            g_2000040c = 0;
            *(unsigned int *)*(int *)0x200003e0 = 28;
            *(unsigned int *)(*(int *)0x200003e0 + 8) = 4 | *(int *)(*(int *)0x200003e0 + 8);
            v5 = *(int *)0x200003f4;
            if (*(int *)0x200003f4 != 8)
                v5 = 12;
            do
            {
                v6 = *(int *)*(int *)0x200003e0;
                if (v5 & v6)
                {
                    g_20000410 = 0x200 | g_20000410;
                    if (!(*(int *)(*(int *)0x200003e0 + 12) & 0xc00) && !*0x200003f9 && *(int *)*(int *)0x200003e0 * 0x10000000 < 0)
                    {
                        if (*(int *)(*(int *)0x200003e0 + 8) * 0x20000000 >= 0)
                        {
                            *(unsigned int *)(*(int *)0x200003e0 + 4) = *(int *)(*(int *)0x200003e0 + 4) & ~12;
                            g_20000410 = 1 | 0xfffffefe & g_20000410;
                        }
                        else
                        {
                            g_20000410 = 32 | g_20000410;
                            g_20000414 = 1 | g_20000414;
                        }
                    }
                    if (!*0x200003f8)
                        *(unsigned int *)*(int *)0x200003e0 = 12;
                    g_2000040c = 1;
                    v7 = *(int *)(*(int *)0x200003e0 + 64);
                    if (*(int *)(*(int *)0x200003e0 + 8) & 4)
                    {
                        if (*(int *)(*(int *)0x200003e0 + 8) & 4 && *(int *)(*(int *)0x200003e0 + 8) & 1)
                            *(unsigned int *)(*(int *)0x200003e0 + 8) = 16 | *(int *)(*(int *)0x200003e0 + 8);
                        while (*(int *)(*(int *)0x200003e0 + 8) & 4)
                        {
                            if ((unsigned int)(*(int *)0x20000340 - *(int *)0x20000340) > 2)
                            {
                                g_20000410 = 16 | g_20000410;
                                v8 = 1;
                                v9 = g_20000414;
                                goto LABEL_8000c2f;
                            }
                        }
                    }
                    if (!(*(int *)(*(int *)0x200003e0 + 8) & 1))
                    {
LABEL_8000b81:
                        g_20000410 = 1 | 0xfffffefe & g_20000410;
                    }
                    else
                    {
                        v8 = 5 & *(int *)(*(int *)0x200003e0 + 8);
                        if (v8 == 1)
                        {
                            *(unsigned int *)(*(int *)0x200003e0 + 8) = *(int *)(*(int *)0x200003e0 + 8) & ~1;
                            *(unsigned int *)*(int *)0x200003e0 = 2;
                            while (1)
                            {
                                if (!(*(int *)(*(int *)0x200003e0 + 8) & 1))
                                    goto LABEL_8000b81;
                                if ((unsigned int)(*(int *)0x20000340 - *(int *)0x20000340) > 2)
                                {
                                    g_20000410 = 16 | g_20000410;
                                    v9 = g_20000414;
                                    break;
                                }
                            }
LABEL_8000c2f:
                            g_20000414 = v8 | v9;
                        }
                        else
                        {
                            g_20000410 = 16 | g_20000410;
                            g_20000414 = 1 | g_20000414;
                        }
                    }
                    g_2000040c = 0;
                    return v7;
                }
            } while ((unsigned int)(*(int *)0x20000340 - *(int *)0x20000340) <= 1000);
            g_20000410 = 4 | g_20000410;
            g_2000040c = (char)v5 & (char)v6;
        }
        else if (*(int *)(*(int *)0x200003e0 + 8) & 0x80000015)
        {
            g_20000410 = 16 | g_20000410;
            g_20000414 = 1 | g_20000414;
        }
        else
        {
            v4 = *(int *)(*(int *)0x200003e0 + 8);
            *(unsigned int *)(*(int *)0x200003e0 + 8) = 1 | v4;
            for (i = sub_8004671(*0x20000038, 1000000, v4, &g_20000000); i; i -= 1);
            goto LABEL_8000add;
        }
    }
    sub_8000a9d(); /* do not return */
}
