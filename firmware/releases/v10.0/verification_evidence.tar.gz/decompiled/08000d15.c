extern char g_20000324;
extern char g_20000325;
extern char g_20000326;

unsigned int sub_8000d15(unsigned int i)
{
    unsigned int v0;  // r1
    unsigned int v1;  // r2

    while (i != (*(int *)*(int *)0x200002e8 & i))
    {
        if (*(int *)0x20000340 - v0 > v1)
        {
            *(unsigned int *)(*(int *)0x200002e8 + 12) = *(int *)(*(int *)0x200002e8 + 12) & 0xfffffe5f;
            *(unsigned int *)(*(int *)0x200002e8 + 20) = *(int *)(*(int *)0x200002e8 + 20) & ~1;
            g_20000325 = 32;
            g_20000326 = 32;
            g_20000324 = 0;
            return 3;
        }
    }
    return 0;
}
