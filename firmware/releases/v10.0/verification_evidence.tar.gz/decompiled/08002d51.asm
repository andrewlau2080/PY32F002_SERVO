08002d51 movs     r0, #0xe1
08002d53 lsls     r0, r0, #9
08002d55 bl       #0x8002725
