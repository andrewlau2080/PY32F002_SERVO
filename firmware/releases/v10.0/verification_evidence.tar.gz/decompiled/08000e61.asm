08000e61 push     {r0, r1, r2, r3, r4, lr}
08000e63 movs     r3, #0
08000e65 str      r3, [sp, #0xc]
08000e67 ldr      r3, [pc, #0x38]
08000e69 movs     r4, r0
08000e6b str      r3, [sp, #8]
08000e6d movs     r3, #4
08000e6f add      r0, sp, #4
08000e71 str      r3, [sp, #4]
08000e73 bl       #0x8000d69
08000e77 cmp      r0, #0
08000e79 beq      #0x8000e7f
08000e7b bl       #0x8000a9d
08000e7f movs     r3, #0xc
08000e81 add      r0, sp, #4
08000e83 str      r3, [sp, #4]
08000e85 bl       #0x8000d69
08000e89 cmp      r0, #0
08000e8b bne      #0x8000e7b
08000e8d movs     r3, #0x80
08000e8f add      r0, sp, #4
08000e91 lsls     r3, r3, #5
08000e93 str      r3, [sp, #8]
08000e95 str      r4, [sp, #4]
08000e97 bl       #0x8000d69
08000e9b cmp      r0, #0
08000e9d bne      #0x8000e7b
08000e9f pop      {r0, r1, r2, r3, r4, pc}
