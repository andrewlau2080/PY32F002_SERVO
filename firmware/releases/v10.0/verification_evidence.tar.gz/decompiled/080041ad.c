typedef struct st_80041ad_0 {
    int field_0;
} st_80041ad_0;

int sub_80041ad(unsigned int a0, unsigned int a1, st_80041ad_0 **a2)
{
    int *v0;  // r3
    int *v1;  // r4
    unsigned int v2;  // r0
    unsigned int v3;  // r0

    v0 = *a2;
    *a2 = v0 + 1;
    v2 = sub_80042f9(*v0, 0, v1[1], v0);
    if (!v2)
        v1[4] = v1[1];
    v3 = v2 - *v0;
    v1[1] = v3;
    v1[4] = v3;
}
