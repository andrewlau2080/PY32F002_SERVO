int sub_8004027(unsigned int a0)
{
    if (a0 != 0xffffffff)
        return sub_800400b();
}
