int sub_8003825(void)
{
    unsigned int v0;  // r6
    unsigned int v1;  // r4

    if (v0 != v1)
        goto LABEL_0x800381f;
    else
        goto LABEL_0x8003829;
}
