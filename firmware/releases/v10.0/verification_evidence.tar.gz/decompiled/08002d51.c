void sub_8002d51(void)
{
    sub_8002725(0x1c200); /* do not return */
}
