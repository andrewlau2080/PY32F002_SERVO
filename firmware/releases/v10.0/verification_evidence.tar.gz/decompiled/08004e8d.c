int sub_8004e8d(unsigned int a0)
{
}
