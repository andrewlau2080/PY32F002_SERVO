0800459d push     {r3, r4, r5, r6, r7, lr}
0800459f movs     r6, r0
080045a1 movs     r4, r1
080045a3 movs     r5, r2
080045a5 cmp      r1, #0
080045a7 beq      #0x80045e1
080045a9 cmp      r2, #0
080045ab beq      #0x80045d9
080045ad bl       #0x8004619
080045b1 movs     r7, r4
080045b3 cmp      r0, r5
080045b5 blo      #0x80045bb
080045b7 movs     r0, r7
080045b9 pop      {r3, r4, r5, r6, r7, pc}
080045bb movs     r1, r5
080045bd movs     r0, r6
080045bf bl       #0x80044d9
080045c3 subs     r7, r0, #0
080045c5 beq      #0x80045b7
080045c7 movs     r1, r4
080045c9 movs     r2, r5
080045cb bl       #0x8003855
080045cf movs     r1, r4
080045d1 movs     r0, r6
080045d3 bl       #0x8004419
080045d7 b        #0x80045b7
080045d9 bl       #0x8004419
080045dd movs     r7, #0
080045df b        #0x80045b7
080045e1 movs     r1, r2
080045e3 bl       #0x80044d9
080045e7 movs     r7, r0
080045e9 b        #0x80045b7
