080023f9 movs     r0, #0xa0
080023fb movs     r2, r6
080023fd movs     r1, r4
080023ff lsls     r0, r0, #1
08002401 bl       #0x80023a9
