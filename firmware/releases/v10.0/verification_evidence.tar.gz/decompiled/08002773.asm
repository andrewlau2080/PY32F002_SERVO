08002773 movs     r2, #0x80
08002775 push     {r4, r5, r6, r7, lr}
08002777 ldr      r3, [pc, #0x360]
08002779 lsls     r2, r2, #0x14
0800277b sub      sp, #0xcc
0800277d str      r2, [r3, #8]
0800277f dsb      sy
08002783 isb      sy
08002787 cpsie    i
08002789 movs     r2, #0x2c
0800278b movs     r1, #0
0800278d add      r0, sp, #0x9c
0800278f bl       #0x80038f9
08002793 movs     r0, #3
08002795 bl       #0x800083d
08002799 ldr      r3, [pc, #0x340]
0800279b ldr      r4, [pc, #0x344]
0800279d ldr      r2, [r3]
0800279f movs     r3, #0x80
080027a1 lsls     r2, r2, #0x13
080027a3 lsrs     r2, r2, #0x13
080027a5 lsls     r3, r3, #8
080027a7 orrs     r3, r2
080027a9 subs     r1, r3, #5
080027ab movs     r3, #0x38
080027ad ldr      r2, [r4, #8]
080027af ldr      r5, [pc, #0x334]
080027b1 tst      r2, r3
080027b3 beq      #0x80027b7
080027b5 b        #0x8002e57
080027b7 ldr      r3, [r4]
080027b9 ldr      r2, [r4, #4]
080027bb lsrs     r2, r2, #0x10
080027bd lsls     r3, r2, #0x10
080027bf movs     r2, #0x80
080027c1 orrs     r3, r1
080027c3 str      r3, [r4, #4]
080027c5 ldr      r1, [r5, #0x20]
080027c7 lsls     r2, r2, #3
080027c9 ldr      r3, [r4]
080027cb tst      r3, r2
080027cd bne      #0x80027d1
080027cf b        #0x8002e49
080027d1 ldr      r3, [r4]
080027d3 ldr      r2, [pc, #0x314]
080027d5 ands     r3, r2
080027d7 str      r3, [r4]
080027d9 bl       #0x8000899
080027dd ldr      r3, [r4, #8]
080027df ldr      r1, [pc, #0x30c]
080027e1 lsls     r3, r3, #0x14
080027e3 lsrs     r3, r3, #0x1c
080027e5 lsls     r3, r3, #2
080027e7 adds     r3, r1, r3
080027e9 movs     r1, #0x1f
080027eb ldr      r3, [r3, #0x60]
080027ed ldr      r2, [pc, #0x300]
080027ef ands     r3, r1
080027f1 lsrs     r0, r3
080027f3 str      r0, [r2, #0x38]
080027f5 ldr      r0, [r2, #0x3c]
080027f7 bl       #0x800083d
080027fb cmp      r0, #0
080027fd beq      #0x8002801
080027ff b        #0x8002e53
08002801 ldr      r3, [pc, #0x2f0]
08002803 ldr      r2, [r3]
08002805 movs     r2, #0xe0
08002807 ldr      r1, [r4, #8]
08002809 lsls     r2, r2, #7
0800280b orrs     r2, r1
0800280d str      r2, [r4, #8]
0800280f ldr      r2, [r4, #8]
08002811 ldr      r1, [pc, #0x2e4]
08002813 ands     r2, r1
08002815 str      r2, [r4, #8]
08002817 ldr      r2, [r4]
08002819 lsls     r2, r2, #0x15
0800281b bmi      #0x800281f
0800281d b        #0x8002e53
0800281f movs     r1, #7
08002821 ldr      r2, [r4, #8]
08002823 ldr      r6, [pc, #0x2d8]
08002825 bics     r2, r1
08002827 str      r2, [r4, #8]
08002829 ldr      r0, [r5, #0x20]
0800282b adds     r1, #0x31
0800282d ldr      r2, [r4, #8]
0800282f tst      r2, r1
08002831 beq      #0x8002835
08002833 b        #0x8002e8b
08002835 movs     r2, #1
08002837 ldr      r1, [r3]
08002839 tst      r1, r2
0800283b beq      #0x800283f
0800283d b        #0x8002e97
0800283f ldr      r3, [r4, #8]
08002841 ldr      r2, [pc, #0x2bc]
08002843 ands     r3, r2
08002845 str      r3, [r4, #8]
08002847 bl       #0x8000899
0800284b ldr      r3, [r4, #8]
0800284d ldr      r2, [pc, #0x29c]
0800284f lsls     r3, r3, #0x14
08002851 lsrs     r3, r3, #0x1c
08002853 lsls     r3, r3, #2
08002855 adds     r3, r2, r3
08002857 movs     r2, #0x1f
08002859 ldr      r3, [r3, #0x60]
0800285b ands     r3, r2
0800285d lsrs     r0, r3
0800285f ldr      r3, [pc, #0x290]
08002861 str      r0, [r3, #0x38]
08002863 ldr      r0, [r3, #0x3c]
08002865 bl       #0x800083d
08002869 subs     r1, r0, #0
0800286b beq      #0x800286f
0800286d b        #0x8002e53
0800286f movs     r6, #1
08002871 ldr      r3, [r4, #0x34]
08002873 movs     r2, #0xc
08002875 orrs     r3, r6
08002877 str      r3, [r4, #0x34]
08002879 ldr      r3, [r4, #0x34]
0800287b add      r0, sp, #0x84
0800287d ands     r3, r6
0800287f str      r3, [sp, #0x50]
08002881 ldr      r3, [sp, #0x50]
08002883 bl       #0x80038f9
08002887 movs     r0, #0xa0
08002889 ldr      r3, [r4, #0x34]
0800288b lsls     r0, r0, #0x17
0800288d orrs     r3, r6
0800288f str      r3, [r4, #0x34]
08002891 ldr      r3, [r4, #0x34]
08002893 add      r1, sp, #0x7c
08002895 ands     r3, r6
08002897 str      r3, [sp, #0x54]
08002899 ldr      r3, [sp, #0x54]
0800289b str      r6, [r0, #0x18]
0800289d str      r6, [sp, #0x7c]
0800289f str      r6, [sp, #0x80]
080028a1 bl       #0x8000925
080028a5 bl       #0x8000a5d
080028a9 ldr      r6, [r5, #0x20]
080028ab ldr      r3, [r5, #0x20]
080028ad subs     r3, r3, r6
080028af cmp      r3, #0xc7
080028b1 bhi      #0x80028b5
080028b3 b        #0x8002eb3
080028b5 ldr      r6, [pc, #0x24c]
080028b7 ldr      r2, [pc, #0x250]
080028b9 ldr      r3, [r6]
080028bb ldr      r7, [pc, #0x250]
080028bd cmp      r3, r2
080028bf beq      #0x80028c3
080028c1 b        #0x8002eb9
080028c3 ldr      r3, [r6, #4]
080028c5 cmp      r3, r7
080028c7 beq      #0x80028cb
080028c9 b        #0x8002eb9
080028cb ldr      r3, [r6, #0x7c]
080028cd movs     r0, r6
080028cf str      r3, [sp, #0xc]
080028d1 bl       #0x80007ed
080028d5 ldr      r3, [sp, #0xc]
080028d7 cmp      r3, r0
080028d9 beq      #0x80028dd
080028db b        #0x8002eb9
080028dd movs     r3, #0xfa
080028df ldrh     r1, [r6, #8]
080028e1 lsls     r3, r3, #1
080028e3 cmp      r1, r3
080028e5 bhs      #0x80028e9
080028e7 b        #0x8002eb9
080028e9 ldrh     r2, [r6, #0xc]
080028eb ldr      r3, [pc, #0x224]
080028ed cmp      r2, r3
080028ef bls      #0x80028f3
080028f1 b        #0x8002eb9
080028f3 ldrh     r3, [r6, #0xa]
080028f5 cmp      r1, r3
080028f7 blo      #0x80028fb
080028f9 b        #0x8002eb9
080028fb cmp      r2, r3
080028fd bhi      #0x8002901
080028ff b        #0x8002eb9
08002901 ldrh     r2, [r6, #0x10]
08002903 ldrh     r3, [r6, #0xe]
08002905 cmp      r3, r2
08002907 blo      #0x800290b
08002909 b        #0x8002eb9
0800290b ldrh     r3, [r6, #0x12]
0800290d cmp      r2, r3
0800290f blo      #0x8002913
08002911 b        #0x8002eb9
08002913 movs     r2, #0x80
08002915 lsls     r2, r2, #5
08002917 cmp      r3, r2
08002919 blo      #0x800291d
0800291b b        #0x8002eb9
0800291d movs     r0, #0xfa
0800291f ldrh     r3, [r6, #0x20]
08002921 lsls     r0, r0, #2
08002923 subs     r1, r3, #1
08002925 uxth     r1, r1
08002927 cmp      r1, r0
08002929 blo      #0x800292d
0800292b b        #0x8002eb9
0800292d ldrh     r1, [r6, #0x22]
0800292f cmp      r1, r3
08002931 bls      #0x8002935
08002933 b        #0x8002eb9
08002935 ldr      r1, [pc, #0x1dc]
08002937 ldrh     r1, [r1]
08002939 cmp      r1, r3
0800293b bls      #0x800293f
0800293d b        #0x8002eb9
0800293f ldr      r1, [pc, #0x1d8]
08002941 ldrh     r1, [r1]
08002943 cmp      r1, r3
08002945 bls      #0x8002949
08002947 b        #0x8002eb9
08002949 ldrh     r3, [r6, #0x26]
0800294b ldr      r1, [pc, #0x1d0]
0800294d subs     r3, #0x64
0800294f uxth     r3, r3
08002951 cmp      r3, r1
08002953 bls      #0x8002957
08002955 b        #0x8002eb9
08002957 ldr      r3, [pc, #0x1c8]
08002959 ldrh     r3, [r3]
0800295b subs     r3, #1
0800295d cmp      r3, #0x1f
0800295f bls      #0x8002963
08002961 b        #0x8002eb9
08002963 ldr      r3, [pc, #0x1c0]
08002965 ldrh     r3, [r3]
08002967 cmp      r3, #8
08002969 bls      #0x800296d
0800296b b        #0x8002eb9
0800296d ldr      r3, [pc, #0x1b8]
0800296f ldrh     r3, [r3]
08002971 cmp      r3, r2
08002973 blo      #0x8002977
08002975 b        #0x8002eb9
08002977 ldr      r3, [pc, #0x1b4]
08002979 ldrh     r3, [r3]
0800297b cmp      r3, #2
0800297d bls      #0x8002981
0800297f b        #0x8002eb9
08002981 movs     r3, #0x80
08002983 ldr      r2, [pc, #0x1ac]
08002985 lsls     r3, r3, #2
08002987 ldrh     r2, [r2]
08002989 cmp      r2, r3
0800298b bls      #0x800298f
0800298d b        #0x8002eb9
0800298f ldr      r3, [pc, #0x1a4]
08002991 ldrh     r2, [r3]
08002993 ldr      r3, [pc, #0x1a4]
08002995 ldrh     r3, [r3]
08002997 cmp      r3, r2
08002999 bls      #0x800299d
0800299b b        #0x8002eb9
0800299d movs     r3, #0x80
0800299f lsls     r3, r3, #4
080029a1 cmp      r2, r3
080029a3 bls      #0x80029a7
080029a5 b        #0x8002eb9
080029a7 ldr      r2, [pc, #0x194]
080029a9 ldrh     r2, [r2]
080029ab cmp      r2, r3
080029ad bls      #0x80029b1
080029af b        #0x8002eb9
080029b1 ldr      r2, [pc, #0x18c]
080029b3 ldrh     r2, [r2]
080029b5 cmp      r2, r3
080029b7 bls      #0x80029bb
080029b9 b        #0x8002eb9
080029bb ldrh     r2, [r6, #0x1e]
080029bd cmp      r2, r3
080029bf bls      #0x80029c3
080029c1 b        #0x8002eb9
080029c3 ldr      r3, [pc, #0x180]
080029c5 ldrh     r2, [r3]
080029c7 ldr      r3, [pc, #0x180]
080029c9 ldrh     r3, [r3]
080029cb cmp      r2, r3
080029cd bls      #0x80029d1
080029cf b        #0x8002eb9
080029d1 ldr      r3, [pc, #0x178]
080029d3 ldr      r2, [pc, #0x17c]
080029d5 ldrh     r3, [r3]
080029d7 adds     r3, r3, r2
080029d9 ldr      r2, [pc, #0x178]
080029db uxth     r3, r3
080029dd cmp      r3, r2
080029df bls      #0x80029e3
080029e1 b        #0x8002eb9
080029e3 movs     r3, #0xfa
080029e5 ldr      r2, [pc, #0x170]
080029e7 lsls     r3, r3, #3
080029e9 ldrh     r2, [r2]
080029eb cmp      r2, r3
080029ed bls      #0x80029f1
080029ef b        #0x8002eb9
080029f1 ldr      r2, [pc, #0x168]
080029f3 ldrh     r2, [r2]
080029f5 cmp      r2, r0
080029f7 bls      #0x80029fb
080029f9 b        #0x8002eb9
080029fb movs     r2, #0xb4
080029fd ldr      r3, [pc, #0x160]
080029ff lsls     r2, r2, #1
08002a01 ldrh     r3, [r3]
08002a03 subs     r3, #1
08002a05 uxth     r3, r3
08002a07 cmp      r3, r2
08002a09 blo      #0x8002a0d
08002a0b b        #0x8002eb9
08002a0d ldr      r3, [pc, #0x154]
08002a0f ldrh     r3, [r3]
08002a11 subs     r3, #1
08002a13 uxth     r3, r3
08002a15 cmp      r3, r2
08002a17 blo      #0x8002a1b
08002a19 b        #0x8002eb9
08002a1b movs     r3, #0x80
08002a1d ldr      r2, [pc, #0x148]
08002a1f lsls     r3, r3, #4
08002a21 ldrh     r2, [r2]
08002a23 cmp      r2, r3
08002a25 bls      #0x8002a29
08002a27 b        #0x8002eb9
08002a29 ldr      r2, [pc, #0x140]
08002a2b ldrh     r2, [r2]
08002a2d cmp      r2, r3
08002a2f bls      #0x8002a33
08002a31 b        #0x8002eb9
08002a33 movs     r2, #0x80
08002a35 movs     r1, r6
08002a37 ldr      r0, [pc, #0x138]
08002a39 bl       #0x8003855
08002a3d movs     r6, #1
08002a3f movs     r2, #0xc
08002a41 movs     r1, #0
08002a43 add      r0, sp, #0x84
08002a45 bl       #0x80038f9
08002a49 movs     r2, #0xc
08002a4b movs     r1, #0
08002a4d add      r0, sp, #0x60
08002a4f bl       #0x80038f9
08002a53 movs     r2, #0x80
08002a55 ldr      r3, [r4, #0x34]
08002a57 lsls     r2, r2, #0xd
08002a59 orrs     r3, r6
08002a5b str      r3, [r4, #0x34]
08002a5d ldr      r3, [r4, #0x34]
08002a5f ldr      r1, [pc, #0x114]
08002a61 ands     r3, r6
08002a63 str      r3, [sp, #0x4c]
08002a65 ldr      r3, [sp, #0x4c]
08002a67 ldr      r3, [r4, #0x30]
08002a69 movs     r0, #0xa0
08002a6b orrs     r3, r2
08002a6d str      r3, [r4, #0x30]
08002a6f ldr      r3, [r4, #0x30]
08002a71 lsls     r0, r0, #0x17
08002a73 ands     r3, r1
08002a75 str      r3, [r4, #0x30]
08002a77 ldr      r3, [r4, #0x40]
08002a79 add      r1, sp, #0x7c
08002a7b orrs     r3, r2
08002a7d str      r3, [r4, #0x40]
08002a7f ldr      r3, [r4, #0x40]
08002a81 ands     r3, r2
08002a83 str      r3, [sp, #0x48]
08002a85 ldr      r3, [sp, #0x48]
08002a87 movs     r3, #0x10
08002a89 str      r3, [sp, #0x7c]
08002a8b subs     r3, #0xd
08002a8d str      r3, [sp, #0x80]
08002a8f bl       #0x8000925
08002a93 ldr      r2, [pc, #0xe4]
08002a95 ldr      r3, [pc, #0xe4]
08002a97 movs     r1, r2
08002a99 str      r3, [r2, #0x40]
08002a9b adds     r1, #0x6c
08002a9d ldrb     r0, [r1]
08002a9f cmp      r0, r6
08002aa1 bne      #0x8002aa5
08002aa3 b        #0x8002e53
08002aa5 strb     r6, [r1]
08002aa7 ldr      r0, [r3, #8]
08002aa9 tst      r0, r6
08002aab beq      #0x8002aaf
08002aad b        #0x8002f61
08002aaf movs     r1, #2
08002ab1 ldr      r6, [r2, #0x70]
08002ab3 ldr      r0, [pc, #0xcc]
08002ab5 ands     r6, r0
08002ab7 orrs     r1, r6
08002ab9 str      r1, [r2, #0x70]
08002abb movs     r1, #0x80
08002abd ldr      r6, [r3, #8]
08002abf lsls     r1, r1, #0x18
08002ac1 orrs     r1, r6
08002ac3 str      r1, [r3, #8]
08002ac5 ldr      r6, [r5, #0x20]
08002ac7 ldr      r1, [r3, #8]
08002ac9 cmp      r1, #0
08002acb bge      #0x8002acf
08002acd b        #0x8002f41
08002acf ldr      r6, [pc, #0xa8]
08002ad1 movs     r1, #2
08002ad3 movs     r7, r6
08002ad5 ldr      r2, [r6, #0x70]
08002ad7 b        #0x8002b85
08002b85 adds     r7, #0x40
08002b87 bics     r2, r1
08002b89 str      r7, [sp, #0xc]
08002b8b movs     r1, r6
08002b8d movs     r7, #4
08002b8f str      r2, [r6, #0x70]
08002b91 movs     r2, #0
08002b93 adds     r1, #0x6c
08002b95 str      r7, [r6, #0x54]
08002b97 adds     r7, #0x54
08002b99 mov      ip, r7
08002b9b strb     r2, [r1]
08002b9d movs     r1, #0x80
08002b9f add      ip, r6
08002ba1 lsls     r1, r1, #0x16
08002ba3 mov      r7, ip
08002ba5 str      r1, [r6, #0x44]
08002ba7 movs     r1, #1
08002ba9 strh     r1, [r7]
08002bab ldr      r7, [sp, #0xc]
08002bad str      r2, [r6, #0x48]
08002baf strb     r2, [r7, #0x1a]
08002bb1 movs     r7, #0xc2
08002bb3 str      r2, [r6, #0x4c]
08002bb5 str      r2, [r6, #0x60]
08002bb7 str      r2, [r6, #0x64]
08002bb9 adds     r2, #5
08002bbb str      r2, [r6, #0x68]
08002bbd ldr      r2, [r6, #0x70]
08002bbf adds     r7, #0xff
08002bc1 str      r1, [r6, #0x50]
08002bc3 str      r7, [r6, #0x5c]
08002bc5 cmp      r2, #0
08002bc7 bne      #0x8002beb
08002bc9 movs     r7, #0x80
08002bcb str      r2, [r6, #0x74]
08002bcd ldr      r2, [r4, #0x40]
08002bcf lsls     r7, r7, #0xd
08002bd1 orrs     r2, r7
08002bd3 str      r2, [r4, #0x40]
08002bd5 ldr      r2, [r4, #0x40]
08002bd7 ands     r2, r7
08002bd9 str      r2, [sp, #0x5c]
08002bdb ldr      r2, [sp, #0x5c]
08002bdd ldr      r2, [r4, #0x34]
08002bdf orrs     r2, r1
08002be1 str      r2, [r4, #0x34]
08002be3 ldr      r2, [r4, #0x34]
08002be5 ands     r1, r2
08002be7 str      r1, [sp, #0x58]
08002be9 ldr      r2, [sp, #0x58]
08002beb ldr      r2, [r6, #0x70]
08002bed lsls     r2, r2, #0x1b
08002bef bpl      #0x8002bf3
08002bf1 b        #0x8002f87
08002bf3 ldr      r1, [r3, #8]
08002bf5 movs     r2, #4
08002bf7 movs     r7, r1
08002bf9 ands     r7, r2
08002bfb str      r7, [sp, #0x10]
08002bfd tst      r1, r2
08002bff beq      #0x8002c03
08002c01 b        #0x8002f87
08002c03 ldr      r2, [r6, #0x70]
08002c05 ands     r2, r0
08002c07 movs     r0, #2
08002c09 orrs     r0, r2
08002c0b str      r0, [r6, #0x70]
08002c0d ldr      r2, [r3, #8]
08002c0f lsls     r2, r2, #0x1f
08002c11 bmi      #0x8002c29
08002c13 movs     r1, #0x18
08002c15 ldr      r2, [r3, #0xc]
08002c17 bics     r2, r1
08002c19 movs     r1, #0x80
08002c1b str      r2, [r3, #0xc]
08002c1d ldr      r2, [r3, #0x10]
08002c1f lsls     r1, r1, #0x16
08002c21 lsls     r2, r2, #4
08002c23 lsrs     r2, r2, #4
08002c25 orrs     r2, r1
08002c27 str      r2, [r3, #0x10]
08002c29 ldr      r2, [r3, #0xc]
08002c2b ldr      r1, [pc, #0x370]
08002c2d movs     r0, #7
08002c2f ands     r2, r1
08002c31 movs     r1, #0xa0
08002c33 str      r2, [r3, #0xc]
08002c35 ldr      r2, [r3, #0xc]
08002c37 lsls     r1, r1, #7
08002c39 orrs     r2, r1
08002c3b str      r2, [r3, #0xc]
08002c3d ldr      r2, [r3, #0x14]
08002c3f ldr      r7, [pc, #0x360]
08002c41 bics     r2, r0
08002c43 str      r2, [r3, #0x14]
08002c45 movs     r2, #5
08002c47 ldr      r0, [r3, #0x14]
08002c49 orrs     r2, r0
08002c4b str      r2, [r3, #0x14]
08002c4d ldr      r3, [r3, #0xc]
08002c4f ldr      r2, [pc, #0x354]
08002c51 ands     r3, r2
08002c53 cmp      r3, r1
08002c55 beq      #0x8002c59
08002c57 b        #0x8002f6f
08002c59 movs     r3, #0
08002c5b movs     r2, #3
08002c5d str      r3, [r7, #0x74]
08002c5f ldr      r3, [r7, #0x70]
08002c61 add      r0, sp, #0x60
08002c63 bics     r3, r2
08002c65 subs     r2, #2
08002c67 orrs     r3, r2
08002c69 str      r3, [r7, #0x70]
08002c6b movs     r3, #0x80
08002c6d lsls     r3, r3, #5
08002c6f str      r3, [sp, #0x64]
08002c71 movs     r3, #4
08002c73 str      r3, [sp, #0x60]
08002c75 bl       #0x8000d69
08002c79 str      r0, [sp, #0xc]
08002c7b cmp      r0, #0
08002c7d beq      #0x8002c81
08002c7f b        #0x8002e53
08002c81 movs     r0, #0xc
08002c83 bl       #0x8000e61
08002c87 bl       #0x8000ab1
08002c8b ldr      r3, [r5, #0x20]
08002c8d bl       #0x8000ea5
08002c91 ldr      r3, [pc, #0x314]
08002c93 strh     r0, [r3, #0xe]
08002c95 bl       #0x800210d
08002c99 movs     r0, #0xa0
08002c9b movs     r1, #2
08002c9d lsls     r0, r0, #0x17
08002c9f bl       #0x8000c91
08002ca3 movs     r0, #0xa0
08002ca5 movs     r1, #4
08002ca7 lsls     r0, r0, #0x17
08002ca9 bl       #0x8000c91
08002cad movs     r0, #0xa0
08002caf movs     r1, #0x40
08002cb1 lsls     r0, r0, #0x17
08002cb3 bl       #0x8000c91
08002cb7 movs     r1, #1
08002cb9 ldr      r0, [pc, #0x2f0]
08002cbb bl       #0x8000c91
08002cbf bl       #0x80007b9
08002cc3 cpsid    i
08002cc5 movs     r2, #0xfa
08002cc7 ldr      r3, [pc, #0x2e8]
08002cc9 lsls     r2, r2, #2
08002ccb strh     r2, [r3, #0x28]
08002ccd ldr      r3, [sp, #0xc]
08002ccf strh     r3, [r7, #0x3c]
08002cd1 cpsie    i
08002cd3 ldr      r3, [pc, #0x2e0]
08002cd5 movs     r2, #1
08002cd7 ldr      r0, [r3, #0x38]
08002cd9 ldr      r3, [pc, #0x2dc]
08002cdb cmp      r0, r3
08002cdd bls      #0x8002ce7
08002cdf ldr      r1, [pc, #0x2dc]
08002ce1 bl       #0x8004671
08002ce5 movs     r2, r0
08002ce7 movs     r0, #0x80
08002ce9 ldr      r1, [r4, #0x40]
08002ceb lsls     r0, r0, #0xa
08002ced orrs     r1, r0
08002cef str      r1, [r4, #0x40]
08002cf1 ldr      r3, [r4, #0x40]
08002cf3 movs     r4, #0
08002cf5 ands     r3, r0
08002cf7 str      r3, [sp, #0x44]
08002cf9 ldr      r3, [sp, #0x44]
08002cfb ldr      r3, [pc, #0x2c4]
08002cfd subs     r2, #1
08002cff str      r4, [r3]
08002d01 str      r4, [r3, #0xc]
08002d03 str      r2, [r3, #0x28]
08002d05 movs     r2, #0x13
08002d07 movs     r0, #0xc5
08002d09 str      r2, [r3, #0x2c]
08002d0b subs     r2, #0x12
08002d0d str      r4, [r3, #0x24]
08002d0f str      r4, [r3, #0x10]
08002d11 str      r2, [r3, #0xc]
08002d13 str      r2, [r3, #0x14]
08002d15 str      r2, [r3]
08002d17 ldr      r3, [pc, #0x2ac]
08002d19 lsls     r0, r0, #2
08002d1b ldr      r1, [r3, r0]
08002d1d ldr      r7, [pc, #0x2a8]
08002d1f adds     r6, #0x7a
08002d21 ands     r7, r1
08002d23 movs     r1, #0x80
08002d25 lsls     r1, r1, #8
08002d27 orrs     r1, r7
08002d29 str      r1, [r3, r0]
08002d2b movs     r1, #0x80
08002d2d lsls     r1, r1, #0xe
08002d2f str      r1, [r3]
08002d31 ldr      r1, [r5, #0x20]
08002d33 ldr      r3, [pc, #0x274]
08002d35 subs     r0, #0x21
08002d37 subs     r0, #0xff
08002d39 str      r1, [r3, #4]
08002d3b strb     r2, [r6]
08002d3d bl       #0x8001e49
08002d41 movs     r0, #0x96
08002d43 lsls     r0, r0, #6
08002d45 bl       #0x8002725
08002e49 ldr      r3, [r5, #0x20]
08002e4b subs     r3, r3, r1
08002e4d cmp      r3, #2
08002e4f bhi      #0x8002e53
08002e51 b        #0x80027c9
08002e53 bl       #0x8000a9d
08002e57 ldr      r3, [r4]
08002e59 ldr      r2, [pc, #0x198]
08002e5b ands     r3, r2
08002e5d str      r3, [r4]
08002e5f movs     r3, #0x80
08002e61 ldr      r2, [r4]
08002e63 lsls     r3, r3, #1
08002e65 orrs     r3, r2
08002e67 movs     r2, #0x80
08002e69 str      r3, [r4]
08002e6b ldr      r0, [r5, #0x20]
08002e6d lsls     r2, r2, #3
08002e6f ldr      r3, [r4]
08002e71 tst      r3, r2
08002e73 beq      #0x8002e81
08002e75 ldr      r2, [r4, #4]
08002e77 lsrs     r2, r2, #0x10
08002e79 lsls     r3, r2, #0x10
08002e7b orrs     r3, r1
08002e7d str      r3, [r4, #4]
08002e7f b        #0x8002801
08002e81 ldr      r3, [r5, #0x20]
08002e83 subs     r3, r3, r0
08002e85 cmp      r3, #2
08002e87 bls      #0x8002e6f
08002e89 b        #0x8002e53
08002e8b ldr      r2, [r5, #0x20]
08002e8d subs     r2, r2, r0
08002e8f cmp      r2, r6
08002e91 bhi      #0x8002e95
08002e93 b        #0x800282d
08002e95 b        #0x8002e53
08002e97 ldr      r1, [r3]
08002e99 ldr      r6, [pc, #0x15c]
08002e9b bics     r1, r2
08002e9d str      r1, [r3]
08002e9f ldr      r0, [r5, #0x20]
08002ea1 ldr      r1, [r3]
08002ea3 tst      r1, r2
08002ea5 bne      #0x8002ea9
08002ea7 b        #0x800283f
08002ea9 ldr      r1, [r5, #0x20]
08002eab subs     r1, r1, r0
08002ead cmp      r1, r6
08002eaf bls      #0x8002ea1
08002eb1 b        #0x8002e53
08002eb3 bl       #0x80003d1
08002eb7 b        #0x80028ab
08002eb9 movs     r2, #0x80
08002ebb ldr      r6, [pc, #0x140]
08002ebd ldr      r1, [pc, #0x140]
08002ebf lsls     r2, r2, #0xa
08002ec1 str      r1, [r6, #0x2c]
08002ec3 ldr      r1, [pc, #0x140]
08002ec5 ldr      r3, [pc, #0x140]
08002ec7 str      r1, [r6, #0x30]
08002ec9 ldr      r1, [pc, #0x140]
08002ecb str      r2, [r6, #0x18]
08002ecd str      r1, [r6, #0x34]
08002ecf ldr      r1, [pc, #0x140]
08002ed1 ldr      r2, [pc, #0x140]
08002ed3 str      r1, [r6, #0x3c]
08002ed5 ldr      r1, [pc, #0x140]
08002ed7 str      r3, [r6]
08002ed9 str      r1, [r6, #0x40]
08002edb ldr      r1, [pc, #0x140]
08002edd ldr      r3, [pc, #0x140]
08002edf str      r1, [r6, #0x44]
08002ee1 ldr      r1, [pc, #0x140]
08002ee3 str      r2, [r6, #0x1c]
08002ee5 str      r1, [r6, #0x48]
08002ee7 movs     r1, #0x80
08002ee9 ldr      r2, [pc, #0x13c]
08002eeb str      r3, [r6, #8]
08002eed str      r2, [r6, #0x20]
08002eef ldr      r3, [pc, #0x13c]
08002ef1 ldr      r2, [pc, #0x13c]
08002ef3 str      r3, [r6, #0xc]
08002ef5 str      r2, [r6, #0x24]
08002ef7 ldr      r3, [pc, #0x13c]
08002ef9 ldr      r2, [pc, #0x13c]
08002efb str      r3, [r6, #0x10]
08002efd str      r2, [r6, #0x28]
08002eff movs     r3, #0
08002f01 str      r2, [r6, #0x74]
08002f03 movs     r2, #0x52
08002f05 lsls     r1, r1, #0xb
08002f07 str      r1, [r6, #0x4c]
08002f09 ldr      r1, [pc, #0x130]
08002f0b movs     r0, r6
08002f0d str      r1, [r6, #0x50]
08002f0f ldr      r1, [pc, #0x130]
08002f11 str      r3, [r6, #0x14]
08002f13 str      r1, [r6, #0x54]
08002f15 ldr      r1, [pc, #0x12c]
08002f17 str      r3, [r6, #0x38]
08002f19 str      r1, [r6, #0x58]
08002f1b ldr      r1, [pc, #0x12c]
08002f1d str      r2, [r6, #0x78]
08002f1f str      r1, [r6, #0x5c]
08002f21 ldr      r1, [pc, #0x128]
08002f23 str      r7, [r6, #4]
08002f25 str      r1, [r6, #0x60]
08002f27 ldr      r1, [pc, #0x128]
08002f29 str      r1, [r6, #0x64]
08002f2b ldr      r1, [pc, #0x128]
08002f2d str      r1, [r6, #0x68]
08002f2f ldr      r1, [pc, #0x128]
08002f31 str      r1, [r6, #0x6c]
08002f33 ldr      r1, [pc, #0x128]
08002f35 str      r1, [r6, #0x70]
08002f37 str      r3, [r6, #0x7c]
08002f39 bl       #0x80007ed
08002f3d str      r0, [r6, #0x7c]
08002f3f b        #0x8002a3d
08002f41 ldr      r1, [r5, #0x20]
08002f43 subs     r1, r1, r6
08002f45 cmp      r1, #2
08002f47 bhi      #0x8002f4b
08002f49 b        #0x8002ac7
08002f4b movs     r1, #0x12
08002f4d ldr      r3, [r2, #0x70]
08002f4f adds     r2, #0x6c
08002f51 bics     r3, r1
08002f53 movs     r1, r3
08002f55 movs     r3, #0x10
08002f57 orrs     r3, r1
08002f59 str      r3, [r2, #4]
08002f5b movs     r3, #0
08002f5d strb     r3, [r2]
08002f5f b        #0x8002e53
08002f61 movs     r3, #0x20
08002f63 ldr      r0, [r2, #0x70]
08002f65 orrs     r3, r0
08002f67 str      r3, [r2, #0x70]
08002f69 movs     r3, #0
08002f6b strb     r3, [r1]
08002f6d b        #0x8002e53
08002f6f movs     r2, #0x12
08002f71 ldr      r3, [r7, #0x70]
08002f73 bics     r3, r2
08002f75 movs     r2, r3
08002f77 movs     r3, #0x10
08002f79 orrs     r3, r2
08002f7b str      r3, [r7, #0x70]
08002f7d movs     r3, #1
08002f7f ldr      r2, [r7, #0x74]
08002f81 orrs     r3, r2
08002f83 str      r3, [r7, #0x74]
08002f85 b        #0x8002e53
08002f87 movs     r3, #0x10
08002f89 ldr      r2, [r6, #0x70]
08002f8b orrs     r3, r2
08002f8d str      r3, [r6, #0x70]
08002f8f b        #0x8002e53
