080001d1 push     {r4, r5, r6, lr}
080001d3 ldr      r3, [pc, #0x58]
080001d5 movs     r4, r0
080001d7 adds     r2, r3, #5
080001d9 ldrb     r1, [r2, #0x1f]
080001db ldr      r5, [r3, #0x20]
080001dd cmp      r1, #0
080001df bne      #0x800020f
080001e1 str      r5, [r3, #0x28]
080001e3 movs     r3, #1
080001e5 strb     r3, [r2, #0x1f]
080001e7 movs     r3, #0xfa
080001e9 lsls     r3, r3, #2
080001eb strh     r3, [r4]
080001ed strh     r3, [r4, #2]
080001ef strh     r3, [r4, #4]
080001f1 movs     r3, #0
080001f3 strb     r3, [r4, #6]
080001f5 ldr      r3, [pc, #0x38]
080001f7 movs     r0, r5
080001f9 str      r3, [r4, #8]
080001fb str      r5, [r4, #0xc]
080001fd str      r5, [r4, #0x10]
080001ff movs     r1, #0x14
08000201 bl       #0x8004671
08000205 movs     r3, #0x80
08000207 lsls     r3, r3, #1
08000209 str      r0, [r4, #0x14]
0800020b strh     r3, [r4, #0x18]
0800020d pop      {r4, r5, r6, pc}
0800020f movs     r1, #0xfa
08000211 ldr      r0, [r3, #0x28]
08000213 lsls     r1, r1, #4
08000215 subs     r0, r5, r0
08000217 bl       #0x8004671
0800021b movs     r3, #1
0800021d movs     r2, #0xfa
0800021f ands     r3, r0
08000221 ldr      r0, [pc, #0x10]
08000223 subs     r3, #1
08000225 ands     r3, r0
08000227 lsls     r2, r2, #3
08000229 adds     r3, r3, r2
0800022b b        #0x80001eb
