unsigned int sub_8000899(void)
{
    char v5;  // r1
    unsigned int v6;  // r3
    unsigned int v7;  // r0
    unsigned int v0;  // [bp-0x24]
    unsigned int v1;  // [bp-0x20]
    unsigned int v2;  // [bp-0x1c]
    unsigned int v3;  // [bp-0x18]
    unsigned int v4;  // [bp-0x14]

    v0 = 4000000;
    v1 = 8000000;
    v2 = 16000000;
    v3 = 22120000;
    v4 = 24000000;
    if (!(*(int *)0x40021008 & 56))
    {
        v5 = (unsigned int)(*(int *)0x40021000) >> 11;
        v6 = (unsigned int)(*(int *)0x40021004) >> 13 & 7;
        if (v6 > 4)
            v6 = *(int *)0x40021008 & 56;
        return (&v0)[v6] >> (v5 & 7 & 31) & (char)((v5 & 7) - 32) >> 31;
    }
    else if (((unsigned int)(*(int *)0x40021008) >> 3 & 7) != 1)
    {
        v7 = (*(int *)0x40021008 & 56) - 24;
        return (v7 + -v7 + (v7 <= 0)) * 0x8000;
    }
    else
    {
        return 24000000;
    }
}
