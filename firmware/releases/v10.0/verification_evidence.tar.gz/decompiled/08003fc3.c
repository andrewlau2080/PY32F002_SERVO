unsigned int sub_8003fc3(unsigned int a0, unsigned int a1, unsigned int a2, unsigned int a3, unsigned int a4, unsigned int a5, unsigned int a6, unsigned int a7, unsigned int a8, unsigned int a9, unsigned int a10, unsigned int a11, unsigned int a12, unsigned int a13)
{
    unsigned int *v0;  // r4
    unsigned int *v1;  // r10
    unsigned int *v2;  // r9

    if (a0 == 0xffffffff)
        return 0xfffffffe;
    if ((*v0 & 6) != 4)
    {
        if ((int)v0[2] <= (int)v0[4])
            return 0;
LABEL_8003fdd:
    }
    else
    {
        if ((int)v0[4] < (int)v0[2])
            goto LABEL_8003fdd;
        if (0 >= (int)(v0[3] - *v1))
            return 0;
    }
    v2();
}
