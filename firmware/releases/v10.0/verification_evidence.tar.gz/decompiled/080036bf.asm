080036bf push     {r4, lr}
080036c1 bl       #0x8000a9d
