void sub_80024b1(char *a0, unsigned int a1, unsigned int a2, unsigned int a3)
{
    unsigned int v6;  // r4
    unsigned int v7;  // r5
    unsigned int v16;  // r1
    unsigned int v8;  // r6
    unsigned int v9;  // r7
    unsigned int v10;  // lr
    unsigned int v12;  // r3
    unsigned int v13;  // r1
    unsigned int v14;  // r0
    unsigned int v15;  // r2
    unsigned int v0;  // [bp-0x30]
    unsigned int v1;  // [bp-0x14]
    unsigned int v2;  // [bp-0x10]
    unsigned int v3;  // [bp-0xc]
    unsigned int v4;  // [bp-0x8]
    unsigned int v5;  // [bp-0x4]

    v1 = v6;
    v2 = v7;
    v3 = v8;
    v4 = v9;
    v5 = v10;
    sub_80021d5("ref_stop");
    switch (*a0)
    {
    case 30:
        v0 = a0[1];
        v13 = "TUN";
        v12 = 5;
        v14 = "P30";
        v15 = 536870976;
        break;
    case 40:
        v15 = 536871340;
        v0 = a0[1];
        v13 = "HBR";
        v12 = 6;
        v14 = "P40";
        break;
    case 1:
        sub_8002291("P01", "SEL", a2, a3); /* do not return */
    case 70:
        v0 = a0[1];
        v13 = "HLD";
        v12 = 5;
        v14 = "P70";
        v15 = 536871216;
        break;
    case 13:
        v0 = a0[1];
        v12 = 5;
        v13 = "BRK";
        v14 = "P31";
        v15 = 536871096;
        break;
    default:
        v16 = "EXTPWM";
        if (*0x2000041b)
            v16 = "INTPWM";
        sub_8002291("P50 V9.6", v16, a2, *0x2000041b); /* do not return */
    }
    sub_8002469(v14, v13, v15, v12); /* do not return */
}
