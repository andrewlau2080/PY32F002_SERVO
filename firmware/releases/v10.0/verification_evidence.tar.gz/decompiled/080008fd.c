extern char g_80049b0;

unsigned int sub_80008fd(void)
{
    char v0;  // r3

    v0 = (char)*(int *)&(&g_80049b0)[20 + 4 * (*(int *)0x40021008 * 0x20000 >> 29)] & 31;
    return (unsigned int)(*(int *)0x20000038) >> (v0 & 31) & (char)(v0 - 32) >> 31;
}
