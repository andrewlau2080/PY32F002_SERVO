08001061 push     {r4, r5, r6, r7, lr}
08001063 movs     r7, #0
08001065 movs     r5, r2
08001067 movs     r6, r3
08001069 sub      sp, #0x2c
0800106b add      r3, sp, #0x40
0800106d movs     r2, #0
0800106f ldrsh    r3, [r3, r2]
08001071 str      r0, [sp, #0x14]
08001073 str      r3, [sp, #0x1c]
08001075 add      r3, sp, #0x44
08001077 ldrb     r3, [r3]
08001079 str      r1, [sp, #0x18]
0800107b str      r3, [sp, #0x20]
0800107d add      r3, sp, #0x48
0800107f ldrb     r3, [r3]
08001081 str      r3, [sp, #0x24]
08001083 bl       #0x80007b9
08001087 ldr      r4, [pc, #0x28]
08001089 strh     r7, [r4, #0x38]
0800108b bl       #0x80002c1
0800108f ldr      r3, [sp, #0x20]
08001091 adds     r4, #0x3c
08001093 strb     r3, [r4]
08001095 ldr      r3, [sp, #0x24]
08001097 movs     r2, r5
08001099 str      r3, [sp, #8]
0800109b ldr      r3, [sp, #0x1c]
0800109d ldr      r1, [sp, #0x18]
0800109f str      r3, [sp]
080010a1 ldr      r0, [sp, #0x14]
080010a3 movs     r3, r6
080010a5 str      r7, [sp, #4]
080010a7 bl       #0x80005a1
080010ab add      sp, #0x2c
080010ad pop      {r4, r5, r6, r7, pc}
