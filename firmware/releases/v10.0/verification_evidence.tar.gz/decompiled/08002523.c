void sub_8002523(void)
{
    unsigned int v1;  // r4
    unsigned int v0;  // [bp+0x0]

    v0 = v1;
    sub_80022f1(4, "H", "W", 0xf800);
}
