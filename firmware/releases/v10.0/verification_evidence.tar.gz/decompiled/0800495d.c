extern unsigned int g_8004cc0;
extern unsigned short g_20000000;
extern char g_200002a0;

void _start(void)
{
    unsigned int node;  // r3
    unsigned int *iter;  // r2

    sub_80037e1(0x20000c00);
    for (node = 0; node + 0x20000000 < &g_200002a0; node += 4)
    {
        *(int *)((char *)&g_20000000 + node) = *(int *)((char *)&g_8004cc0 + node);
    }
    for (iter = &g_200002a0; iter < 0x200007b8; iter += 1)
    {
        *iter = 0;
    }
    sub_8003811();
    sub_8002773(); /* do not return */
}
