08003f35 push     {r3, r4, r5, r6, r7, lr}
08003f37 mov      r7, sl
08003f39 mov      r6, sb
08003f3b mov      lr, fp
08003f3d mov      r5, r8
08003f3f push     {r5, r6, r7, lr}
08003f41 movs     r7, r3
08003f43 ldr      r3, [sp, #0x28]
08003f45 mov      sl, r2
08003f47 mov      sb, r3
08003f49 ldr      r2, [r1, #0x10]
08003f4b ldr      r3, [r1, #8]
08003f4d movs     r6, r0
08003f4f movs     r4, r1
08003f51 cmp      r2, r3
08003f53 bge      #0x8003f57
08003f55 movs     r2, r3
08003f57 mov      r3, sl
08003f59 str      r2, [r3]
08003f5b movs     r3, #0x43
08003f5d ldrb     r3, [r4, r3]
08003f5f cmp      r3, #0
08003f61 beq      #0x8003f69
08003f63 mov      r1, sl
08003f65 adds     r2, #1
08003f67 str      r2, [r1]
08003f69 ldr      r1, [r4]
08003f6b lsls     r2, r1, #0x1a
08003f6d bpl      #0x800402d
08003f6f mov      r3, sl
08003f71 mov      r2, sl
08003f73 movs     r0, #6
08003f75 ldr      r3, [r3]
08003f77 adds     r3, #2
08003f79 str      r3, [r2]
08003f7b ldr      r1, [r4]
08003f7d movs     r2, r1
08003f7f tst      r0, r1
08003f81 bne      #0x8003f97
08003f83 ldr      r2, [r4, #0xc]
08003f85 subs     r3, r2, r3
08003f87 movs     r2, #0x19
08003f89 mov      fp, r2
08003f8b movs     r2, #0
08003f8d add      fp, r4
08003f8f mov      r8, r2
08003f91 movs     r2, r1
08003f93 cmp      r3, #0
08003f95 bgt      #0x800401d
08003f97 movs     r3, #0x43
08003f99 ldrb     r3, [r4, r3]
08003f9b subs     r1, r3, #1
08003f9d sbcs     r3, r1
08003f9f lsls     r2, r2, #0x1a
08003fa1 bpl      #0x8003fb9
08003fa3 movs     r0, #0x30
08003fa5 adds     r1, r4, r3
08003fa7 adds     r1, #0x43
08003fa9 strb     r0, [r1]
08003fab movs     r1, #0x45
08003fad adds     r2, r3, #1
08003faf ldrb     r1, [r4, r1]
08003fb1 adds     r2, r4, r2
08003fb3 adds     r2, #0x43
08003fb5 adds     r3, #2
08003fb7 strb     r1, [r2]
08003fb9 movs     r2, r4
08003fbb movs     r1, r7
08003fbd movs     r0, r6
08003fbf adds     r2, #0x43
08003fc1 blx      sb
0800401d movs     r3, #1
0800401f mov      r2, fp
08004021 movs     r1, r7
08004023 movs     r0, r6
08004025 blx      sb
0800402d movs     r2, #6
0800402f tst      r2, r1
08004031 beq      #0x8004059
08004033 subs     r2, r3, #1
08004035 sbcs     r3, r2
08004037 b        #0x8003fb9
08004059 mov      r3, sl
0800405b ldr      r3, [r3]
0800405d b        #0x8003f83
