extern unsigned int g_40021800;
extern unsigned int g_40021804;
extern unsigned int g_40021860[4];
extern unsigned int g_40021880;
extern unsigned int g_40021884;

char * sub_8000925(char *a0, unsigned int *a1)
{
    unsigned int v3;  // r3
    unsigned int v4;  // r2
    unsigned int v13;  // r7
    unsigned int v14;  // r6
    unsigned int v15;  // r7
    unsigned int v5;  // r12
    unsigned int v6;  // r2
    char v7;  // r5
    unsigned int v8;  // r6
    unsigned int v9;  // r7
    unsigned int v10;  // r5
    unsigned int v11;  // r5
    unsigned int v12;  // r6
    unsigned int v0;  // [bp-0x24]
    unsigned int v1;  // [bp-0x20]
    unsigned int v2;  // [bp-0x1c]

    v3 = 0;
    v2 = a0 + 0xaffffc00 - (a0 + 0xaffffbff) - (0x1 > a0 + 0xaffffc00) + 1;
    while (1)
    {
        v4 = *a1;
        if (!(v4 >> ((char)v3 & 31) & (int)((v3 & 0xff) - 32) >> 31))
            break;
        v0 = 1 << ((char)v3 & 31) & (int)((v3 & 0xff) - 32) >> 31;
        v5 = v0 & v4;
        if (v4 & v0)
        {
            v6 = a1[1];
            v1 = v6 & ~16;
            if (v1 == 2)
                *(unsigned int *)&a0[32 + 4 * (v3 >> 3)] = *(int *)&a0[32 + 4 * (v3 >> 3)] & ~(15 << ((7 & (char)v3) * 4 & 31) & (int)(((7 & v3) * 4 & 0xff) - 32) >> 31) | a1[4] << ((7 & (char)v3) * 4 & 31) & (int)(((7 & v3) * 4 & 0xff) - 32) >> 31;
            v7 = (char)v3 * 2;
            v8 = 3 << (v7 & 31) & (char)(v7 - 32) >> 31;
            v9 = ~v8;
            *(unsigned int *)a0 = *(int *)a0 & ~v8 | (3 & v6) << (v7 & 31) & (char)(v7 - 32) >> 31;
            if (1 >= v1 - 1)
            {
                *(unsigned int *)&a0[8] = a1[3] << (v7 & 31) & (char)(v7 - 32) >> 31 | *(int *)&a0[8] & v9;
                *(unsigned int *)&a0[4] = v6 * 0x8000000 >> 31 << ((char)v3 & 31) & (int)((v3 & 0xff) - 32) >> 31 | *(int *)&a0[4] & ~v0;
            }
            *(unsigned int *)&a0[12] = a1[2] << (v7 & 31) & (char)(v7 - 32) >> 31 | *(int *)&a0[12] & v9;
            if ((int)(v6 * 8) < 0)
            {
                v10 = 0;
                if (a0 != 0x50000000)
                    v10 = v2;
                g_40021860[v3 >> 2] = g_40021860[v3 >> 2] & ~(15 << ((3 & (char)v3) * 8 & 31) & (int)(((3 & v3) * 8 & 0xff) - 32) >> 31) | v10 << ((3 & (char)v3) * 8 & 31) & (int)(((3 & v3) * 8 & 0xff) - 32) >> 31;
                v11 = ~v5;
                v12 = v5 | g_40021880;
                if ((int)(v6 * 0x8000) >= 0)
                    v12 = g_40021880 & v11;
                g_40021880 = v12;
                v13 = v5 | g_40021884;
                if ((int)(v6 * 0x4000) >= 0)
                    v13 = g_40021884 & v11;
                g_40021884 = v13;
                v14 = v5 | g_40021800;
                if ((int)(v6 * 0x800) >= 0)
                    v14 = g_40021800 & v11;
                g_40021800 = v14;
                v15 = v5 | g_40021804;
                if ((int)(v6 * 0x400) >= 0)
                    v15 = g_40021804 & v11;
                g_40021804 = v15;
            }
        }
        v3 += 1;
    }
    return a0;
}
