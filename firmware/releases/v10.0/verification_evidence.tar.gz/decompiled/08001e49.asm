08001e49 push     {r0, r1, r2, r4, r5, r6, r7, lr}
08001e4b movs     r4, #0
08001e4d movs     r6, #0x14
08001e4f movs     r7, #0x28
08001e51 str      r0, [sp, #4]
08001e53 ldr      r5, [pc, #0x4c]
08001e55 movs     r1, r4
08001e57 ldr      r3, [r5, #8]
08001e59 cmp      r3, #0
08001e5b beq      #0x8001e65
08001e5d movs     r1, #0x78
08001e5f movs     r0, r4
08001e61 bl       #0x800477d
08001e65 ldr      r3, [r5, #8]
08001e67 movs     r0, r6
08001e69 cmp      r3, #0
08001e6b bne      #0x8001e6f
08001e6d movs     r0, r7
08001e6f movs     r3, #0xa0
08001e71 movs     r2, #0x20
08001e73 lsls     r3, r3, #0x17
08001e75 cmp      r1, r0
08001e77 bhs      #0x8001e9d
08001e79 str      r2, [r3, #0x28]
08001e7b bl       #0x80010b5
08001e7f movs     r1, #0xfa
08001e81 ldr      r3, [pc, #0x20]
08001e83 lsls     r1, r1, #2
08001e85 ldr      r0, [r3, #0x38]
08001e87 bl       #0x8004671
08001e8b bl       #0x80000c1
08001e8f ldr      r3, [sp, #4]
08001e91 adds     r4, #1
08001e93 cmp      r3, r4
08001e95 bne      #0x8001e53
08001e97 bl       #0x80010b5
08001e9b pop      {r0, r1, r2, r4, r5, r6, r7, pc}
08001e9d str      r2, [r3, #0x18]
08001e9f b        #0x8001e7b
