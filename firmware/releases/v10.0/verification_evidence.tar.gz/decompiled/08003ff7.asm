08003ff7 adds     r3, r0, #1
08003ff9 bne      #0x8003fe7
