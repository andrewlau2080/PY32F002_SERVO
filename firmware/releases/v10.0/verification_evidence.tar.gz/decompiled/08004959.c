int sub_8004959(unsigned int a0)
{
    return a0;
}
