void sub_8002431(void)
{
    unsigned int v2;  // r4
    unsigned int v3;  // r5
    unsigned int *v4;  // r6
    unsigned int v0;  // [bp+0x0]
    char v1;  // [bp+0xc]

    v0 = v2;
    sub_80022f1(v3, *v4, &v1, (-(v2 - (v2 - 1) - (1 > v2)) & 63457) + 31);
}
