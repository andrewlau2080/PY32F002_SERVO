void sub_80023dd(unsigned int a0, unsigned int a1, unsigned int a2, unsigned int a3)
{
    unsigned int v4;  // r4
    unsigned int v5;  // r5
    unsigned int v6;  // r6
    unsigned int v7;  // lr
    unsigned int v0;  // [bp-0x10]
    unsigned int v1;  // [bp-0xc]
    unsigned int v2;  // [bp-0x8]
    unsigned int v3;  // [bp-0x4]

    v0 = v4;
    v1 = v5;
    v2 = v6;
    v3 = v7;
    sub_80023a9(0, a0, 16904, a3); /* do not return */
}
