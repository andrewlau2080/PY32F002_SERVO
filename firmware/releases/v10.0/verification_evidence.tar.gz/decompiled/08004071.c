typedef struct st_8003f35_0 {
    unsigned int field_0;
    char padding_4[4];
    int field_8;
    unsigned int field_c;
    int field_10;
    char padding_14[47];
    char field_43;
    char padding_44[1];
    char field_45;
} st_8003f35_0;

extern unsigned int g_8004a50[4];

void sub_8004071(unsigned int a0, st_8003f35_0 *a1, unsigned int a2, unsigned int a3)
{
    unsigned int v11;  // r4
    unsigned int v12;  // r5
    unsigned int v13;  // r6
    unsigned int v14;  // r7
    unsigned int v15;  // lr
    unsigned int v16;  // r8
    unsigned int v17;  // r9
    unsigned int v18;  // r10
    unsigned int v19;  // r1
    unsigned int v0;  // [bp-0x40]
    st_8003f35_0 *v1;  // [bp-0x34]
    int v2[2];  // [bp-0x2c]
    unsigned int v3;  // [bp-0x24]
    unsigned int v4;  // [bp-0x20]
    unsigned int v5;  // [bp-0x1c]
    unsigned int v6;  // [bp-0x14]
    unsigned int v7;  // [bp-0x10]
    unsigned int v8;  // [bp-0xc]
    unsigned int v9;  // [bp-0x8]
    unsigned int v10;  // [bp-0x4]

    v6 = v11;
    v7 = v12;
    v8 = v13;
    v9 = v14;
    v10 = v15;
    v3 = v16;
    v4 = v17;
    v5 = v18;
    v1 = &a1->field_43;
    v19 = a1->padding_14[4];
    if (!v19)
    {
        a1->field_10 = 0;
    }
    else if (32 >= (char)v19 - 88)
    {
        goto *((void *)(g_8004a50[v19 - 88 & 0xff] | 1));
    }
    else
    {
        a1->padding_14[46] = v19;
        a1->field_10 = 1;
        a1->field_43 = 0;
    }
    v0 = a3;
    sub_8003f35(a0, a1, v2, a2); /* do not return */
}
