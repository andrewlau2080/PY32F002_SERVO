08004649 push     {r1}
0800464b mov      r1, lr
0800464d lsrs     r1, r1, #1
0800464f lsls     r1, r1, #1
08004651 ldrsb    r1, [r1, r0]
08004653 lsls     r1, r1, #1
08004655 add      lr, r1
08004657 pop      {r1}
08004659 bx       lr
