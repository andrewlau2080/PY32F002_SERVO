extern unsigned int g_2000003c;
extern unsigned int g_e000e010;
extern unsigned int g_e000e014;
extern unsigned int g_e000e018;
extern unsigned int g_e000ed20;

unsigned int sub_800083d(unsigned int a0)
{
    unsigned int v0;  // r0

    v0 = sub_8004671(*0x20000038, 1000) - 1;
    if (v0 >= 0x1000000)
        return 1;
    g_e000e014 = v0;
    g_e000ed20 = g_e000ed20 & 0xffffff | 0xc0000000;
    g_e000e018 = 0;
    g_e000e010 = 7;
    if (3 >= a0)
    {
        g_e000ed20 = g_e000ed20 & 0xffffff | a0 * 0x40000000;
        g_2000003c = a0;
        return 0;
    }
    return 1;
}
