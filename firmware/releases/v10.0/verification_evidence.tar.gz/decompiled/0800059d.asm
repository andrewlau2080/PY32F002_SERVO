0800059d lsls     r0, r4, #0xc
0800059f movs     r0, #0
