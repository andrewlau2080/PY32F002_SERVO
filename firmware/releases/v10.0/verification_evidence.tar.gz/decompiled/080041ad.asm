080041ad ldr      r3, [r2]
080041af adds     r1, r3, #4
080041b1 str      r1, [r2]
080041b3 ldr      r5, [r3]
080041b5 movs     r1, #0
080041b7 movs     r0, r5
080041b9 ldr      r2, [r4, #4]
080041bb bl       #0x80042f9
080041bf cmp      r0, #0
080041c1 bne      #0x80041c5
080041c3 b        #0x80042e7
080041c5 subs     r0, r0, r5
080041c7 str      r0, [r4, #4]
080041c9 str      r0, [r4, #0x10]
080041cb b        #0x8004147
080042e7 ldr      r0, [r4, #4]
080042e9 str      r0, [r4, #0x10]
080042eb b        #0x8004147
