08002d49 movs     r0, #0x96
08002d4b lsls     r0, r0, #8
08002d4d bl       #0x8002725
