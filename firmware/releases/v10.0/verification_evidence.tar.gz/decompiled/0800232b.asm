0800232b str      r6, [sp, #0xc]
0800232d movs     r6, #0
0800232f adds     r7, #0x2a
08002331 adds     r5, #0x1f
08002333 movs     r1, r7
08002335 movs     r3, #0x24
08002337 movs     r2, #0xe6
08002339 movs     r0, #0x1a
0800233b str      r6, [sp, #8]
0800233d str      r4, [sp, #4]
0800233f str      r5, [sp]
08002341 bl       #0x800224d
