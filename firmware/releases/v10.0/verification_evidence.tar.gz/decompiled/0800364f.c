int sub_800364f(void)
{
}
