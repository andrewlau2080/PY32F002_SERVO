void sub_80023bd(void)
{
    unsigned short v0;  // r4
    unsigned short v1;  // r5
    int v2;  // r6

    sub_800224d(v0 + 2, 245, 156, 22, 0xffff, v1, 1, v2); /* do not return */
}
