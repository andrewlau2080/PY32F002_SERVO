void sub_80023a9(int a0, unsigned int a1, unsigned int a2, unsigned int a3)
{
    unsigned int v8;  // r4
    unsigned int v9;  // r5
    unsigned int v10;  // r6
    unsigned int v11;  // lr
    int v0;  // [bp-0x20], Other Possible Types: unsigned int
    unsigned int v1;  // [bp-0x1c]
    unsigned int v2;  // [bp-0x18]
    unsigned int v3;  // [bp-0x14]
    unsigned int v4;  // [bp-0x10]
    unsigned int v5;  // [bp-0xc]
    unsigned int v6;  // [bp-0x8]
    unsigned int v7;  // [bp-0x4]

    v0 = a0;
    v1 = a1;
    v2 = a2;
    v3 = a3;
    v4 = v8;
    v5 = v9;
    v6 = v10;
    v7 = v11;
    v0 = a2;
    sub_8002221(a0, 240, 160, 32); /* do not return */
}
