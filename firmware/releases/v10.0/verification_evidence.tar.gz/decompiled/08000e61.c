typedef struct st_8000d69_1 {
    unsigned int field_0;
    unsigned int field_4;
} st_8000d69_1;

st_8000d69_1 sub_8000e61(st_8000d69_1 a0, unsigned int a1)
{
    st_8000d69_1 v0;  // [bp-0x14], Other Possible Types: unsigned int
    unsigned int v1;  // [bp-0x10]
    unsigned int v2;  // [bp-0xc]

    v0 = a1;
    v2 = 0;
    v1 = 4097;
    v0 = (st_8000d69_1)4;
    if (!sub_8000d69(&v0))
    {
        v0 = (st_8000d69_1)12;
        if (!sub_8000d69(&v0))
        {
            v1 = 0x1000;
            v0 = a0;
            if (!sub_8000d69(&v0))
                return a0;
        }
    }
    sub_8000a9d(); /* do not return */
}
