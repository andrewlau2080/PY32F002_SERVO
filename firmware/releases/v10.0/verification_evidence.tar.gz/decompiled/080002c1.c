extern char g_2000034c;
extern unsigned int g_20000350;
extern char g_20000354;

int sub_80002c1(void)
{
    unsigned int v0;  // r0

    g_20000350 = 0;
    g_2000034c = 0;
    g_20000354 = 0;
    return v0;
}
