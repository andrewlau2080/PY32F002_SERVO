080007ed movs     r3, #1
080007ef push     {r4, r5, r6, r7, lr}
080007f1 movs     r2, #0
080007f3 movs     r4, #1
080007f5 movs     r7, #0x80
080007f7 ldr      r5, [pc, #0x40]
080007f9 rsbs     r3, r3, #0
080007fb movs     r1, #0x7c
080007fd cmp      r1, r2
080007ff bhi      #0x8000821
08000801 cmp      r7, r2
08000803 bls      #0x8000821
08000805 subs     r1, #0x74
08000807 movs     r6, r3
08000809 lsrs     r3, r3, #1
0800080b ands     r6, r4
0800080d beq      #0x8000811
0800080f eors     r3, r5
08000811 subs     r1, #1
08000813 cmp      r1, #0
08000815 bne      #0x8000807
08000817 adds     r2, #1
08000819 cmp      r2, #0x80
0800081b bne      #0x80007fb
0800081d mvns     r0, r3
0800081f pop      {r4, r5, r6, r7, pc}
08000821 ldrb     r1, [r0, r2]
08000823 eors     r3, r1
08000825 movs     r1, #8
08000827 movs     r6, r3
08000829 lsrs     r3, r3, #1
0800082b ands     r6, r4
0800082d beq      #0x8000831
0800082f eors     r3, r5
08000831 subs     r1, #1
08000833 cmp      r1, #0
08000835 bne      #0x8000827
08000837 b        #0x8000817
