int sub_8004a31(unsigned int a0)
{
}
