typedef struct st_8003b0d_0 {
    unsigned int field_0;
    char padding_4[4];
    int field_8;
    unsigned short field_c;
    char padding_e[2];
    unsigned int field_10;
    int field_14;
} st_8003b0d_0;

unsigned int sub_8003cf9(unsigned int *a0, st_8003b0d_0 *a1, char *a2, int *a3, char a4, unsigned int a5, unsigned int a6, unsigned short a7)
{
    unsigned int v22;  // r4
    unsigned int v23;  // r5
    unsigned int *v32;  // r9
    char *v33;  // r4
    char *v34;  // r7
    char *iter;  // r7
    unsigned int v36;  // r0
    unsigned int v37;  // r1
    int v38;  // r2
    char *iter1;  // r4
    unsigned int i;  // r0
    unsigned int v41;  // r1
    unsigned int v24;  // r6
    unsigned int v42;  // r3
    unsigned int j;  // r0
    unsigned int v44;  // r0
    unsigned int v25;  // r7
    unsigned int v26;  // r8
    unsigned int *v27;  // r9
    unsigned int v28;  // r10
    char *v29;  // r8
    unsigned int v30;  // r0
    unsigned int v31;  // r3
    int *node;  // [bp-0x8c]
    int *v2;  // [bp-0x8c]
    unsigned int v3;  // [bp-0x88]
    int v4;  // [bp-0x84], Other Possible Types: unsigned int
    unsigned int v5;  // [bp-0x80]
    int v6;  // [bp-0x7c], Other Possible Types: unsigned int
    unsigned int iter2;  // [bp-0x74]
    char v8;  // [bp-0x70]
    char v9;  // [bp-0x6f]
    char v10;  // [bp-0x6e]
    char v11;  // [bp-0x46]
    char v12;  // [bp-0x45]
    unsigned int v13;  // [bp-0x30]
    unsigned int v14;  // [bp-0x24]
    unsigned int *v15;  // [bp-0x20]
    unsigned int v16;  // [bp-0x1c]
    char *v17;  // [bp-0x18]
    unsigned int v18;  // [bp-0x14]
    unsigned int v19;  // [bp-0x10]
    unsigned int v20;  // [bp-0xc]
    unsigned int v21;  // [bp-0x8]

    v18 = v22;
    v19 = v23;
    v20 = v24;
    v21 = v25;
    v14 = v26;
    v15 = v27;
    v16 = v28;
    v17 = &a4;
    v29 = a2;
    if ((int)(a1->field_c * 0x1000000) < 0 && !a1->field_10)
    {
        v30 = sub_80044d9();
        a1->field_0 = v30;
        a1->field_10 = v30;
        if (!v30)
        {
            *a0 = 12;
            return 0xffffffff;
        }
        a1->field_14 = 64;
    }
    iter2 = 0;
    v9 = 32;
    v10 = 48;
    v31 = *v29;
    node = a3;
    if (v31)
    {
        while (1)
        {
            v33 = v29;
            do
            {
                if (v31 == 37)
                {
                    v34 = v33 - v29;
                    if (v33 == v29)
                        goto LABEL_8003d53;
                    goto LABEL_8003e43;
                }
            } while ((v31 = v33[1], v33 += 1, v31));
            v34 = v33 - v29;
            if (v33 == v29)
                break;
LABEL_8003e43:
            if (sub_8003b0d(a0, a1, v29, v34) == 0xffffffff)
                break;
            iter2 = &v34[iter2];
LABEL_8003d53:
            if (!*v33)
                break;
            v4 = 0xfffffffe;
            iter = v33 + 1;
            v3 = 0;
            v6 = 0;
            v5 = 0;
            v11 = 0;
            v13 = 0;
            while (1)
            {
                v36 = sub_80042f9("#-0+ ", *iter, 5);
                if (!v36)
                    break;
                iter += 1;
                v3 |= 1 << ((char)(char *)(v36 - 134237316) & 31) & (int)(((char *)(v36 - 134237316) & 0xff) - 32) >> 31;
            }
            if ((int)(v3 * 0x8000000) < 0)
                v12 = 32;
            if ((int)(v3 * 0x10000000) < 0)
                v12 = 43;
            v37 = *iter;
            if (v37 == 42)
            {
                v38 = *node;
                node += 1;
                if (0 <= v38)
                {
                    v6 = v38;
                }
                else
                {
                    v6 = -v38;
                    v3 |= 2;
                }
                iter1 = iter + 1;
                if (iter[1] != 46)
                    goto LABEL_8003dc1;
            }
            else
            {
                i = v37 - 48;
                if (9 >= i)
                {
                    do
                    {
                        v37 = iter[1];
                        v6 = v6 * 10 + i;
                        i = v37 - 48;
                        iter += 1;
                    } while (i <= 9);
                    v6 = v6;
                }
                iter1 = iter;
                if (v37 != 46)
                    goto LABEL_8003dc1;
            }
            v41 = iter1[1];
            if (v41 == 42)
            {
                v2 = node + 1;
                v4 = *node;
                if (0 > *node)
                    v4 = 0xfffffffe;
                iter1 += 2;
                node = v2;
            }
            else
            {
                v42 = 0;
                j = v41 - 48;
                iter1 += 1;
                v4 = 0;
                if (j <= 9)
                {
                    do
                    {
                        v42 = v42 * 10 + j;
                        j = iter1[1] - 48;
                        iter1 += 1;
                    } while (j <= 9);
                    v4 = v42;
                }
            }
LABEL_8003dc1:
            v44 = sub_80042f9("hlL");
            if (v44)
            {
                iter1 += 1;
                v3 |= 64 << ((char)(char *)(v44 - 134237324) & 31) & (int)(((char *)(v44 - 134237324) & 0xff) - 32) >> 31;
            }
            v29 = iter1 + 1;
            v8 = *iter1;
            if (!sub_80042f9("efgEFG", v8, 6, v29))
                sub_8004071(a0, &v3, a1, sub_8003b0d, &node); /* do not return */
            node = ((char *)&node[1] + 3 & ~7) + 8;
            iter2 += (char *)v32;
            v31 = *v29;
            if (!v31)
                break;
        }
    }
    return ((int)(a1->field_c * 0x2000000) >= 0 ? iter2 : 0xfffffffe);
}
