0800224d push     {r4, r5, r6, r7, lr}
0800224f sub      sp, #0x164
08002251 add      r4, sp, #0x178
08002253 ldrh     r5, [r4]
08002255 add      r4, sp, #0x17c
08002257 ldrh     r6, [r4]
08002259 add      r4, sp, #0x180
0800225b ldrb     r7, [r4]
0800225d movs     r4, #0xa0
0800225f mov      ip, r4
08002261 str      r5, [sp, #0x10]
08002263 str      r1, [sp]
08002265 movs     r5, #0
08002267 mov      r1, ip
08002269 ldr      r4, [sp, #0x184]
0800226b str      r3, [sp, #8]
0800226d str      r2, [sp, #4]
0800226f movs     r3, r0
08002271 ldr      r2, [pc, #0x18]
08002273 lsls     r1, r1, #1
08002275 str      r4, [sp, #0x1c]
08002277 str      r7, [sp, #0x18]
08002279 str      r6, [sp, #0x14]
0800227b str      r5, [sp, #0xc]
0800227d add      r0, sp, #0x20
0800227f bl       #0x8003a1d
