int sub_80034a5(void)
{
}
