typedef struct st_80001d1_0 {
    unsigned short field_0;
    unsigned short field_2;
    unsigned short field_4;
    char field_6;
    char padding_7[1];
    unsigned int field_8;
    unsigned int field_c;
    unsigned int field_10;
    unsigned int field_14;
    unsigned short field_18;
} st_80001d1_0;

extern char g_20000344;
extern unsigned int g_20000348;

void sub_80001d1(st_80001d1_0 *a0)
{
    unsigned short v0;  // r3

    if (!g_20000344)
    {
        g_20000348 = *(int *)0x20000340;
        g_20000344 = 1;
        v0 = 1000;
    }
    else
    {
        v0 = ((unsigned short)((1 & sub_8004671(*(int *)0x20000340 - g_20000348, 4000)) - 1) & 64536) + 2000;
    }
    a0->field_0 = v0;
    a0->field_2 = v0;
    a0->field_4 = v0;
    a0->field_6 = 0;
    a0->field_8 = 20000;
    a0->field_c = *(int *)0x20000340;
    a0->field_10 = *(int *)0x20000340;
    a0->field_14 = sub_8004671(*0x20000340, 20);
    a0->field_18 = 0x100;
    return;
}
