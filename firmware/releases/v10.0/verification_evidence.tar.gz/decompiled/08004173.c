typedef struct st_8004173_0 {
    unsigned int field_0;
    char padding_4[63];
    char field_43;
} st_8004173_0;

int sub_8004173(unsigned int a0, unsigned int a1, unsigned int *a2)
{
    st_8004173_0 *v0;  // r4

    if ((int)(v0->field_0 * 0x1000000) < 0 || (int)(v0->field_0 * 0x2000000) >= 0)
        *a2 = *a2 + 4;
    else
        *a2 = *a2 + 4;
    v0->field_43 = 0;
}
