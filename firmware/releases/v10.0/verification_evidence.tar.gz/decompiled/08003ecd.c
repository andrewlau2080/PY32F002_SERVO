int sub_8003ecd(unsigned int a0)
{
}
