"""Concrete Cortex-M single-control-step comparison; no hardware access.

Requires angr in the isolated reverse engineering environment. ADC and PWM
capture are supplied as test inputs. This verifies sampled software paths,
not motor dynamics, peripheral timing, or full formal equivalence.
"""
from pathlib import Path
import argparse, itertools, json, logging, struct, time
import angr
from elftools.elf.elffile import ELFFile

logging.getLogger('angr').setLevel(logging.CRITICAL)
parser=argparse.ArgumentParser()
parser.add_argument('--candidate',default='gate3_noreset')
parser.add_argument('--limit',type=int,default=0)
parser.add_argument('--extended-only',action='store_true')
args=parser.parse_args()
root=Path(__file__).resolve().parents[2]
out=Path(__file__).resolve().parent
original=root/'firmware/baselines/v9.6_original/original_v96_app.elf'
binary=root/'firmware/baselines/v9.6_original/original_v96_app.bin'
candidate=out/(args.candidate+'.elf')
STOP=0x0badf00d

class ADCInput(angr.SimProcedure):
    def run(self):
        return self.state.globals['adc_input']

class PWMInput(angr.SimProcedure):
    def run(self, pointer):
        pulse=self.state.globals['pulse_input']
        self.state.memory.store(pointer,struct.pack('<HHHBxIIII??2x',pulse,pulse,pulse,0,20000,1000,20,10,False,True))
        return pointer

with candidate.open('rb') as handle:
    elf=ELFFile(handle)
    symbols={s.name:(s['st_value'],s['st_size']) for s in elf.get_section_by_name('.symtab').iter_symbols() if s['st_size']}
    candidate_data=elf.get_section_by_name('.data').data()

projects=[]
for file in [original,candidate]:
    project=angr.Project(str(file),auto_load_libs=False,arch='ARMCortexM')
    if file==original:
        project.hook(0x08000ea5,ADCInput())
        project.hook(0x0800053d,PWMInput())
    else:
        project.hook(symbols['ADC_Feedback_ReadRaw'][0],ADCInput())
        project.hook(symbols['PWM_Input_GetSample'][0],PWMInput())
    projects.append(project)

def execute(index, case):
    project=projects[index]
    start=0x080010b5 if index==0 else symbols['lcdm_runtime_service_motor_control'][0]
    state=project.factory.call_state(start,ret_addr=STOP,add_options={angr.options.ZERO_FILL_UNCONSTRAINED_MEMORY,angr.options.ZERO_FILL_UNCONSTRAINED_REGISTERS})
    state.regs.sp=0x20000bf0
    state.memory.store(0x20000000,bytes(3072))
    state.memory.store(0x20000000,binary.read_bytes()[0x4cc0:0x4f60] if index==0 else candidate_data)
    def setvar(name,value):
        addr,size=symbols[name]
        state.memory.store(addr,(value & ((1<<(size*8))-1)).to_bytes(size,'little'))
    values={
        'uwTick':1000,'s_lcdm_runtime_last_motor_ms':999,
        's_lcdm_runtime_control_ready':1,'s_lcdm_runtime_pwm_seeded':1,
        's_lcdm_servo_ab_seeded':1,'s_lcdm_servo_pos_q4':case['feedback']*16,
        's_lcdm_servo_vel_q4':case['velocity'],
        's_lcdm_servo_latched_pulse_seeded':1,
        's_lcdm_servo_last_processed_pulse_count':9,
        's_lcdm_servo_latched_pulse_us':1503-case['pulse_delta'],
        's_lcdm_servo_last_control_pulse_us':1503-case['pulse_delta'],
        's_lcdm_servo_last_target_adc':2052,
        's_lcdm_servo_cmd_target_adc':2052,
        's_lcdm_servo_prev_target_adc':2052,
        's_lcdm_servo_prev_feedback_adc':case['feedback'],
        's_lcdm_servo_v3_phase':case['phase'],
        's_lcdm_servo_hold_deviation_count':case.get('hold_count',0),
        's_lcdm_servo_current_state':1 if case['phase']==1 else 2,
        's_lcdm_servo_motion_dir':1,
        's_lcdm_last_hbridge_frequency_hz':1000,
    }
    values.update(case.get('state_values',{}))
    for name,value in values.items():
        if name in symbols:setvar(name,value)
    state.globals['adc_input']=case.get('raw_adc',case['feedback'])
    state.globals['pulse_input']=1503
    manager=project.factory.simgr(state)
    manager.explore(find=STOP,num_find=1,n=800)
    if not manager.found:
        return {'error':str(manager.errored[:1]),'active':[hex(s.addr) for s in manager.active],'deadended':len(manager.deadended)}
    result=manager.found[0]
    names=['s_lcdm_servo_cmd_target_adc','s_lcdm_servo_current_duty','s_lcdm_servo_current_state','s_lcdm_servo_current_velocity','s_lcdm_servo_v3_phase','s_lcdm_servo_pos_q4','s_lcdm_servo_vel_q4','s_lcdm_servo_hold_deviation_count','s_lcdm_servo_customer_active','s_lcdm_servo_overshoot_adc','s_lcdm_servo_dir_alarm']
    return {name:result.solver.eval(result.memory.load(symbols[name][0],symbols[name][1],endness=project.arch.memory_endness)) for name in names if name in symbols}

cases=[dict(pulse_delta=delta,feedback=feedback,velocity=velocity,phase=phase) for delta,feedback,velocity,phase in itertools.product([0,1,2,3,500],[1700,1812,2036,2052,2068,2292,2400],[0,128,-128],[1,2,6])]
if args.extended_only:
    cases=[]
    for elapsed,feedback,direction in itertools.product([0,11,12,15,16,18,19,42,43,100],[1700,2052,2400],[-1,1]):
        cases.append(dict(pulse_delta=0,feedback=feedback,velocity=128*direction,phase=2,state_values={'s_lcdm_servo_customer_active':1,'s_lcdm_servo_customer_dir':direction,'s_lcdm_servo_customer_start_ms':1000-elapsed}))
    for feedback,velocity,phase in itertools.product([1700,2400],[-128,0,128],[1,6]):
        cases.append(dict(pulse_delta=0,feedback=feedback,velocity=velocity,phase=phase,hold_count=7))
    for raw in [0,29,4066,4095]:
        cases.append(dict(pulse_delta=0,feedback=2052,raw_adc=raw,velocity=0,phase=1))
    for feedback in [1700,2052,2400]:
        cases.append(dict(pulse_delta=500,feedback=feedback,velocity=0,phase=1,state_values={'s_lcdm_servo_last_target_adc':65535,'s_lcdm_servo_last_control_pulse_us':65535}))
if args.limit:cases=cases[:args.limit]
results=[];started=time.time()
for i,case in enumerate(cases):
    a,b=execute(0,case),execute(1,case)
    results.append(dict(case=case,equal=a==b and 'error' not in a,original=a,candidate=b))
    if i%20==0:print('case',i,'/',len(cases),'equal',results[-1]['equal'],'elapsed',round(time.time()-started,1),flush=True)
    if 'error' in a or 'error' in b:
        print(results[-1],flush=True)
        break
report=dict(candidate=args.candidate,attempted=len(results),equal=sum(x['equal'] for x in results),results=results,limitations=__doc__)
(out/(args.candidate+('_extended' if args.extended_only else '')+'_emulation.json')).write_text(json.dumps(report,indent=2)+'\n')
print('Result',report['equal'],'/',report['attempted'],flush=True)
